from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]

def read(rel): return (ROOT/rel).read_text(errors='replace')

manager=read('app/src/main/java/pro/babasitaram/vault/data/backup/AutoBackupManager.kt')
repo=read('app/src/main/java/pro/babasitaram/vault/data/repository/VaultRepositoryImpl.kt')
contract=read('app/src/main/java/pro/babasitaram/vault/domain/repository/VaultRepository.kt')
drawer=read('app/src/main/java/pro/babasitaram/vault/presentation/navigation/DrawerCountsViewModel.kt')
activity=read('app/src/main/java/pro/babasitaram/vault/core/security/ActivityLogStore.kt')
activity_dao=read('app/src/main/java/pro/babasitaram/vault/data/local/db/ActivityLogDao.kt')
activity_entity=read('app/src/main/java/pro/babasitaram/vault/data/local/db/ActivityLogEntity.kt')
activity_screen=read('app/src/main/java/pro/babasitaram/vault/presentation/activitylog/ActivityLogScreen.kt')
notes=read('app/src/main/java/pro/babasitaram/vault/presentation/notes/NotesScreen.kt')
mobiles=read('app/src/main/java/pro/babasitaram/vault/presentation/mobiles/MobilesScreen.kt')
mobile_vm=read('app/src/main/java/pro/babasitaram/vault/presentation/mobiles/MobilesViewModel.kt')
contacts=read('app/src/main/java/pro/babasitaram/vault/presentation/contacts/ContactsImportScreen.kt')
theme_app=read('app/src/main/java/pro/babasitaram/vault/BsrApplication.kt')
theme_main=read('app/src/main/java/pro/babasitaram/vault/MainActivity.kt')
theme_store=read('app/src/main/java/pro/babasitaram/vault/data/local/preferences/SettingsDataStore.kt')
health=read('app/src/main/java/pro/babasitaram/vault/presentation/vaulthealth/VaultHealthCalculator.kt')
health_vm=read('app/src/main/java/pro/babasitaram/vault/presentation/vaulthealth/VaultHealthViewModel.kt')
health_screen=read('app/src/main/java/pro/babasitaram/vault/presentation/vaulthealth/VaultHealthScreen.kt')
entity=read('app/src/main/java/pro/babasitaram/vault/data/local/db/VaultEntity.kt')
vault_dao=read('app/src/main/java/pro/babasitaram/vault/data/local/db/VaultDao.kt')
vault_vm=read('app/src/main/java/pro/babasitaram/vault/presentation/vault/VaultListViewModel.kt')
vault_screen=read('app/src/main/java/pro/babasitaram/vault/presentation/vault/VaultListScreen.kt')

checks=[]
def c(label, ok): checks.append((label, bool(ok)))

# FIX1 backup
c('FIX1 exact canonical filename', 'const val FINAL_NAME = "BSRPRO.Vault"' in manager)
c('FIX1 MediaStore pending staging', 'MediaStore.MediaColumns.IS_PENDING, 1' in manager and 'put(MediaStore.MediaColumns.IS_PENDING, 0)' in manager)
c('FIX1 no in-place truncate', 'overwriteInPlace' not in manager)
c('FIX1 selected SAF URI persisted', 'backupFolderUri' in manager and 'KEY_LAST_SAF_URI' in manager)
c('FIX1 app-launch verified duplicate cleanup', 'cleanupExistingVerifiedDuplicates()' in manager and 'runPendingOrDue' in manager and manager.index('cleanupExistingVerifiedDuplicates()') < manager.index('val pending ='))
backup_block=manager[manager.index('suspend fun backupNow()'):manager.index('private suspend fun write(')]
c('FIX1 cleanup only after verify', backup_block.index('verifyPersistedBackup()') < backup_block.index('cleanupOldBackups()'))
c('FIX1 duplicate patterns managed', 'isNumberedDuplicate' in manager and 'isLegacyDated' in manager and 'isSafRecovery' in manager and 'isQuarantine' in manager)
c('FIX1 cleanup cannot silently claim incomplete', 'cleanupIncomplete' not in manager and 'cleanupIncomplete' not in manager and 'cleanup incomplete' in manager.lower())

# FIX2 activity log
c('FIX2 Room activity_log entity', 'tableName = "activity_log"' in activity_entity and 'id: Long' in activity_entity and 'timestamp: Long' in activity_entity and 'action: String' in activity_entity and 'details: String' in activity_entity)
c('FIX2 chronological newest first', 'ORDER BY timestamp DESC, id DESC' in activity_dao)
c('FIX2 durable logger', 'dao.insert' in activity and 'Dispatchers.IO' in activity)
# explicit source-wide event checks
source='\n'.join(p.read_text(errors='replace') for p in (ROOT/'app/src/main/java').rglob('*.kt'))
for action in ['Vault unlocked','Backup created','Export completed','Import completed','Restore backup','Create secure share','Share link revoked','Settings changed','Biometric enabled','Master password changed','Emergency setup','Hidden vault PIN set']:
    c(f'FIX2 event present: {action}', action in source)
c('FIX2 screen filters', all(x in activity_screen for x in ['"All" to R.string.p15_all','"Security" to R.string.p15_security','"Data" to R.string.activity_log_data','"Settings" to R.string.p15_settings']))

# FIX3 mobile count
c('FIX3 canonical mobile StateFlow', 'val mobileCount: StateFlow<Int>' in contract)
c('FIX3 nonblank mobile/phone only', '(mobile.isNotBlank() || phone.isNotBlank())' in repo)
c('FIX3 hidden excluded', '!isHiddenVault' in repo)
c('FIX3 trashed excluded', 'deletedAt == 0L' in repo)
c('FIX3 exact/999+ formatting', 'count <= 0 -> null' in drawer and 'count >= 1000 -> "999+"' in drawer)
c('FIX3 MobilesViewModel same filter', '!it.isHiddenVault' in mobile_vm and 'it.mobile.isNotBlank() || it.phone.isNotBlank()' in mobile_vm)
c('FIX3 large import dialog', 'contacts_large_import_title' in contacts and 'selected.size >= 1000' in contacts)

# FIX4 theme
c('FIX4 synchronous cached startup theme', 'getSharedPreferences("bsrpro_prefs"' in theme_app and 'cached_theme' in theme_app)
c('FIX4 cache mirrored on setting change', 'putString("cached_theme"' in theme_store and 'AppThemeCache.update' in theme_store)
c('FIX4 MainActivity consumes cached theme', 'AppThemeCache.initialTheme' in theme_main)

# FIX5 context menu
c('FIX5 Notes row anchor', 'Box(Modifier.fillMaxWidth())' in notes and 'DropdownMenu(expanded = menu' in notes)
c('FIX5 Mobiles row anchor', 'Box(Modifier.fillMaxWidth())' in mobiles and 'DropdownMenu(expanded = menu' in mobiles)
c('FIX5 menu actions', all(s in notes for s in ['p15_edit','p15_copy','p15_share','p15_delete']))
c('FIX5 mobiles menu actions', all(s in mobiles for s in ['p15_edit','p15_copy','p15_share','p15_delete']))

# FIX6 notes truncation
c('FIX6/Fix.md 3.1 notes list shows title only (no content preview)', 'maxLines = 3' not in notes)
c('FIX6 full note scrollable', 'verticalScroll(rememberScrollState())' in notes and 'maxLines = Int.MAX_VALUE' in notes)

# FIX7 localization affected surfaces
c('FIX7 resource coverage', 'stringResource(R.string' in notes and 'stringResource(R.string' in mobiles and 'stringResource(R.string' in activity_screen and 'stringResource(R.string' in vault_screen)
c('FIX7 no obvious hardcoded UI copy in Notes/Mobiles', not any(x in notes for x in ['Text("Copy','Text("Edit','Text("Share','Text("Delete']) and not any(x in mobiles for x in ['Text("Copy','Text("Edit','Text("Share','Text("Delete']))

# FIX8 health
c('FIX8 categories', all(x in health for x in ['weakPasswords','reusedPasswords','duplicateLogins','oldPasswords','missingUsernames']))
c('FIX8 unique issue count by id', 'map { it.id }.toSet().size' in health)
c('FIX8 Drawer uses uniqueIssueCount', 'health.uniqueIssueCount' in drawer)
c('FIX8 breakdown UI', 'health_breakdown' in health_screen)

# FIX9 performance / DB / Compose
c('FIX9 metadata indices', all(x in entity for x in ['Index("url")','Index("username")','Index("category")','Index("deleted_at")','Index("record_type")','Index("app_package")']))
c('FIX9 Room query layer', '@Query' in vault_dao and 'Flow<' in vault_dao)
c('FIX9 IO persistence', 'withContext(Dispatchers.IO) { dao.replaceAll' in repo)
c('FIX9 heavy list work Default', 'flowOn(Dispatchers.Default)' in vault_vm)
c('FIX9 StateFlow WhileSubscribed', 'SharingStarted.WhileSubscribed(5_000)' in vault_vm and 'SharingStarted.WhileSubscribed(5_000)' in health_vm and 'SharingStarted.WhileSubscribed(5_000)' in mobile_vm)
c('FIX9 stable LazyColumn key/contentType', 'key = { row ->' in vault_screen and 'contentType = { row ->' in vault_screen)
c('FIX9 remembered row computation', 'remember(state.entries, state.grouped, expanded)' in vault_screen)

# Python simulation of badge contract and 10 backup cycles (names only; actual Android provider requires device runtime).
def badge(n): return None if n<=0 else '999+' if n>=1000 else str(n)
for n, expected in [(0,None),(1,'1'),(378,'378'),(999,'999'),(1000,'999+')]: c(f'badge {n}', badge(n)==expected)
files={'BSRPRO.Vault'}
for i in range(1,11):
    files.add(f'BSRPRO ({i}).Vault')
    files={name for name in files if name=='BSRPRO.Vault'}
for i in range(10): c(f'backup cycle {i+1} leaves one canonical name', files=={'BSRPRO.Vault'})

# ---- Phase 16D: duplicate backup files / import-export routing / direct share / suggestions default ----
saf_cleanup=manager[manager.index('private suspend fun cleanupSafTree'):manager.index('private fun deleteDocumentSafely')]
saf_write=manager[manager.index('private suspend fun writeSafTree'):manager.index('private suspend fun verifySafDocument')]
c('16D SAF delete uses DocumentsContract.deleteDocument', 'DocumentsContract.deleteDocument' in manager)
c('16D SAF cleanup never calls resolver.delete directly', 'resolver.delete(' not in saf_cleanup)
c('16D SAF write removes superseded recovery copy after publish', 'deleteDocumentSafely(resolver, oldUri!!)' in saf_write and 'resolver.delete(' not in saf_write)
c('16D unverifiable leftovers do not fail a verified backup', 'throw java.io.IOException("BSRPRO backup cleanup incomplete' not in manager)
settings_screen=read('app/src/main/java/pro/babasitaram/vault/presentation/settings/SettingsScreen.kt')
backup_screen=read('app/src/main/java/pro/babasitaram/vault/presentation/backup/BackupScreen.kt')
c('16D Settings backup/import rows no longer all call onOpenBackup()', settings_screen.count(') { onOpenBackup() }')==0 and 'BackupTarget.PICK_CSV' in settings_screen and 'BackupTarget.EXPORT' in settings_screen)
c('16D import options use different file-type filters', 'PICK_CSV_TYPES' in backup_screen and 'PICK_JSON_TYPES' in backup_screen and 'PICK_VAULT_TYPES' in backup_screen)
c('16D export has one button per format', all(k in backup_screen for k in ('openExportOptionsFor(ExportKind.VAULT)','openExportOptionsFor(ExportKind.CSV)','openExportOptionsFor(ExportKind.JSON)')))
vault_settings=read('app/src/main/java/pro/babasitaram/vault/core/model/VaultSettings.kt')
c('16D autofill inline suggestions default ON', 'val autofillInline: Boolean = true' in vault_settings)
sharing=read('app/src/main/java/pro/babasitaram/vault/presentation/sharing/SharingScreen.kt')
c('16D single-item share skips the Sharing page', 'val directMode = initialEntryIds.size == 1' in sharing and 'if (directMode) onBack()' in sharing)

fails=[label for label,ok in checks if not ok]
for label,ok in checks: print(('PASS' if ok else 'FAIL')+': '+label)
print(f'\n{len(checks)-len(fails)}/{len(checks)} checks passed.')
if fails:
    print('\nFailures:')
    for f in fails: print('-',f)
    raise SystemExit(1)
print('All source-level FIX1-FIX9 regression checks passed. This is not an Android compile/device runtime test.')
