import re,glob,os,collections,sys
root='app/src'
files=glob.glob(root+'/**/*.kt',recursive=True)
def strip(t):
    t=re.sub(r'/\*.*?\*/','',t,flags=re.S)
    out=[]
    for line in t.split('\n'):
        # remove // comments not in strings (crude)
        res='';instr=False;i=0
        while i<len(line):
            c=line[i]
            if c=='"' and (i==0 or line[i-1]!='\\'): instr=not instr
            if not instr and line.startswith('//',i): break
            res+=c;i+=1
        out.append(res)
    t='\n'.join(out)
    t=re.sub(r'"""(.*?)"""','""',t,flags=re.S)
    # string templates may contain code; crude: remove string contents
    t=re.sub(r'"(?:\\.|[^"\\\n])*"','""',t)
    t=re.sub(r"'(?:\\.|[^'\\\n])'","''",t)
    return t
pkgdecl=collections.defaultdict(set)
filedecl={}
for f in files:
    raw=open(f,encoding='utf8').read()
    t=strip(raw)
    pkg=re.search(r'^package\s+([\w.]+)',raw,re.M).group(1)
    names=set(re.findall(r'\b(?:class|object|interface|typealias)\s+([A-Z]\w*)',t))
    names|=set(re.findall(r'\bfun\s+(?:<[^>]*>\s*)?(?:[\w.<>?]+\.)?([A-Z]\w*)\s*\(',t))
    names|=set(re.findall(r'\benum class\s+\w+[^{]*\{([^}]*)\}',t) and [])
    pkgdecl[pkg]|=names
    filedecl[f]=(pkg,raw,t,names)
STD=set('''String Int Long Boolean Float Double Char Byte Short Unit Any Nothing List MutableList Map MutableMap Set MutableSet Collection Iterable Sequence Array IntArray LongArray ByteArray CharArray BooleanArray FloatArray DoubleArray Pair Triple Result Throwable Exception RuntimeException IllegalStateException IllegalArgumentException UnsupportedOperationException NumberFormatException IndexOutOfBoundsException NullPointerException ArithmeticException Error AssertionError Comparable Comparator Number CharSequence StringBuilder Regex Lazy Function Suppress OptIn Deprecated JvmStatic JvmField JvmOverloads JvmName Volatile Synchronized Throws Retention Target Repeatable MustBeDocumented Override Math System Thread Runnable Class Object Enum Iterator ListIterator ArrayList HashMap HashSet LinkedHashMap LinkedHashSet Cloneable Process Runtime ClassCastException InterruptedException CharacterCodingException NoSuchElementException ConcurrentModificationException StackOverflowError OutOfMemoryError Void Character Integer Appendable Readable AutoCloseable Closeable Annotation AnnotationRetention AnnotationTarget Strictfp Transient Strictfp ReplaceWith Experimental LinkedList Iterable CharProgression IntRange LongRange CharRange ClosedRange Entry Cloneable ByteArray UByteArray ULong UInt UShort UByte UIntArray ULongArray Duration Companion Int Short DslMarker PublishedApi SafeVarargs FunctionalInterface'''.split())
unres=collections.defaultdict(set)
for f,(pkg,raw,t,names) in filedecl.items():
    imports=set();wild=False
    for m in re.finditer(r'^import\s+([\w.]+)(?:\s+as\s+(\w+))?(\.\*)?',raw,re.M):
        if m.group(3): wild=True
        else: imports.add(m.group(2) or m.group(1).split('.')[-1])
    body=re.sub(r'^(import|package)\s.*$','',t,flags=re.M)
    # type params
    tparams=set(re.findall(r'<\s*(?:reified\s+|in\s+|out\s+)?([A-Z]\w*)\s*(?::[^>,]*)?[,>]',body))
    tparams|=set(re.findall(r'[<,]\s*(?:reified\s+|in\s+|out\s+)?([A-Z]\w*)\s*(?::|,|>)',body) and [])
    # enum entries in file
    enum_entries=set()
    for m in re.finditer(r'enum class \w+(?:\([^)]*\))?\s*\{(.*?)(?:;|\n\}|\Z)',body,re.S):
        enum_entries|=set(re.findall(r'\b([A-Z][A-Za-z0-9_]*)\b',m.group(1)))
    sealed=set()
    for m in re.finditer(r'(?<![\w.@])([A-Z][A-Za-z0-9]*)\b',body):
        n=m.group(1)
        start=m.start()
        prev=body[max(0,start-1):start]
        if re.fullmatch(r'[A-Z0-9_]+',n) and len(n)>1: continue
        if n in imports or n in names or n in pkgdecl[pkg] or n in STD or n in tparams or n in enum_entries: continue
        if len(n)==1: continue
        unres[f].add(n)
# remove names that resolve via wildcard import of known project packages
for f,s in sorted(unres.items()):
    raw=filedecl[f][1]
    wilds=re.findall(r'^import\s+([\w.]+)\.\*',raw,re.M)
    s2={n for n in s if not any(n in pkgdecl.get(w,set()) for w in wilds)}
    if wilds and not s2: continue
    if s2: print(f.replace('app/src/',''),sorted(s2)[:20], 'WILDCARD' if wilds else '')
