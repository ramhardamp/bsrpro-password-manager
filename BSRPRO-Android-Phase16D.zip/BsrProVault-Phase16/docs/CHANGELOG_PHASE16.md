# Changelog — Phase 16A to 16D

Format: Issue -> Fix -> Logic (Fix.md style). Sab badlav source-level hain: Gradle build aur device test abhi baaki hai.

## 16A — backup incident + follow-up
| Issue | Fix | Logic |
|---|---|---|
| Raw `BSRZ1:` payload CSV path me jaakar fail hota tha | `ImportParser.detectKind()` ab `BSRZ1:` pehchanta hai (BOM/whitespace ke saath bhi) | Pehle koi bhi non-JSON text CSV maana jaata tha |
| Backup/import me failure ki jagah pata nahi chalti thi | Metadata-only `BSRPROBackup` log (size, marker, counts, exception class; password/records kabhi nahi) | Device logcat se failure stage pakadna |
| CI me unit-test failure chhup jaata tha | `testDebugUnitTest` ab required step | Test fail = build fail |
| Quick Settings tile (API 34+) | `startActivityAndCollapse(PendingIntent)` | Purane Android par Intent overload |

## 16B — setup par backup folder
| Issue | Fix | Logic |
|---|---|---|
| Naye phone par backup folder chunna / folder se restore nahi hota tha | Setup screen: SAF folder picker + "Restore from backup folder" (exact `BSRPRO.Vault` dhoondh kar purane V3 restore flow me) | Persistable permission `backupFolderUri` me save; galat password par dialog khula rehta hai |

## 16C — UI polish
| Issue | Fix | Logic |
|---|---|---|
| Light theme me primary button par white text 2.7:1 | Light primary `#6D4AE8` (5.5:1) | WCAG AA 4.5:1 |
| Android 15 (targetSdk 35) me keyboard fields dhak deta tha | `MainActivity` me `imePadding()` | Edge-to-edge me `adjustResize` kaam nahi karta |
| Keyboard Done/Enter kuch nahi karta tha | `PasswordField` me `imeAction` / `onImeAction`; Lock = Unlock, Setup confirm = Create | Purane callers unchanged (defaults) |
| LockScreen scroll nahi hoti thi | `verticalScroll` | Chhoti screen / bada font |
| Setup: restore upar, form neeche; hardcoded strings | Form pehle, restore/folder neeche; strings en + hi me | Primary flow pehle |
| Avatar initial amber/mint par unreadable; EmptyState left-aligned; off-grid 6/10/14/18dp | Contrast-aware initial; centered text; 4/8dp grid | 11 jagah |

## 16D — duplicate backup files, import/export, suggestions, direct share
| Issue | Fix | Logic |
|---|---|---|
| Folder me 8+ `BSRPRO-Recovery-*.Vault` | SAF delete `DocumentsContract.deleteDocument` se; publish ke baad purani file turant delete | `ContentResolver.delete()` DocumentsProvider par kaam nahi karta, isliye cleanup fail hoke har retry par nayi copy bani |
| Ek unreadable purani file poore backup ko fail karti thi | Ab sirf log; backup success | Jo file is vault ke password se decrypt nahi hoti use jaanbujh kar nahi hatate |
| Settings ki 6 rows ek hi page kholti thin | `BackupDeepLink`: har row sahi tab / picker par | One-shot, rotation par dobara trigger nahi |
| Export me ek hi button + radio list | 4 buttons: .Vault, CSV, JSON, generated-password backup | Dialog me format pehle se chuna |
| Import me sab `*/*` | .Vault / CSV / JSON / Contacts alag; CSV aur JSON ke file-type filters | .Vault ka MIME standard nahi |
| Suggestions default OFF | `autofillInline = true`, DataStore key `autofill_inline_v2` | Purane installs par bhi default ON; user OFF kar sakta hai |
| Vault/Notes/Mobiles se share par beech ka page | Ek item = sirf auth, phir seedha OS share sheet | Multi-select aur drawer ka Sharing page pehle jaisa |
| `VaultJson.copy { }` compile error (`EntryExporter.kt`) | `Json(from = VaultJson) { prettyPrint = true }` | `Json` me `copy` nahi hota; ye 16A follow-up me aaya tha |

## Device par dekhna
1. Gradle build + `testDebugUnitTest`.
2. Ek backup ke baad purani Recovery files hat rahi hain; folder me sirf ek `BSRPRO.Vault`.
3. Settings ki har row sahi jagah; keyboard suggestions (Android 11+).
4. Light theme, Hindi font scale, chhoti screen par Setup/Lock.
