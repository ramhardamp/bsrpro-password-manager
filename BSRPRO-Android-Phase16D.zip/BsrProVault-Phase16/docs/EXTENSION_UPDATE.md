# BSRPRO Extension — App ke hisaab se update list

Format: Issue -> Fix -> Logic (Fix.md style). Yeh list app (Phase 16, versionCode 30) ke code se banayi gayi hai.
Extension ka ZIP milte hi isi file ko upar se neeche follow karna hai; user ko dobara kuch batana nahi padega.
Rule (Fix.md 5.3): koi naya feature ya schema change nahi; sab backward compatible; extension sirf *padhte waqt* filter kare, data hataye nahi.

## Rollout order (zaroori)
1. E1 (compressed reader) + E3 (round-trip safety) pehle extension me.
2. Extension release hone ke BAAD app me `VaultPlaintext.COMPRESS_EXPORT = true` (file: `core/crypto/VaultPlaintext.kt`).
3. Warna naya compressed backup purana extension nahi padh payega.

---

## E1. Compressed payload reader (`BSRZ1:`)
- **Issue:** App ab payload ko encrypt se pehle gzip kar sakta hai; extension is form ko nahi padhta.
- **Fix:** V3 decrypt ke baad plaintext check karo: agar `BSRZ1:` se shuru ho to baaki hissa base64 decode -> gunzip -> UTF-8 -> `JSON.parse`. Warna pehle jaisa `JSON.parse`.
- **Logic:** Browser me `DecompressionStream('gzip')` (ya pako). 64 MB se bada output reject karo. Marker na ho to koi badlav nahi, isliye purani files bina badlav khulti hain.
- **Optional writer:** extension chahe to wahi format likh sakta hai (`"BSRZ1:" + base64(gzip(json))`), sirf jab json 16 KB se bada ho aur packed chhota nikle (app ka rule: `VaultPlaintext.pack`).
- **Acceptance:** (a) purana plain `.Vault` khulta hai; (b) app ka compressed `.Vault` khulta hai; (c) kharab base64/gzip par saaf error, crash nahi.

## E2. `type` field: website vs app (Fix.md 1.1)
- **Issue:** App login aur website password mix hone se autofill fail hota tha.
- **Fix:** Extension me entry ko "app" tab maano jab: `type == "app"` (case-insensitive), YA `type` khali ho AUR `appPackage` bhara ho AUR `url` khali ho. (Yehi rule app me `VaultEntry.isAppLogin` ka hai.)
- **Logic:** App entries ko extension ke autofill, URL match, aur website list se hatao (sirf dikhane me). `url` agar `androidapp://<package>` form me ho to bhi website match nahi karna.
- **Zaroori:** Import/export/merge me app entries DELETE mat karo. Extension se dobara export karne par app ki entries waisi hi wapas jaani chahiye.
- **Acceptance:** app entry web autofill me nahi dikhti; extension se re-export ke baad entry maujood aur unchanged.

## E3. Round-trip safety (koi field mat girao)
- **Issue:** Extension purani field-list ke saath export kare to app ke naye fields kho sakte hain.
- **Fix:** Extension entry object ko as-is rakhe aur export me unknown/naye fields bhi likhe. App ke fields: `id,title,url,username,password,mobile,notes,totp,category,categoryLocked,isNote,recordType,folderId,folder,type,appPackage,appName,isPrimaryAppLogin,starred,tags,customFields,cardNumber,cardholder,cardExpiry,cardCvv,fullName,email,phone,address,idNumber,idExpiry,strength,createdAt,updatedAt,deletedAt,lastUsedAt,passwordHistory,editHistory,_metaType,appPin`.
- **Logic:** Khaas dhyan: `appPin` (per-login Entry PIN), `lastUsedAt`, `appName`, `isPrimaryAppLogin`, `tags` (includes `hidden-vault`), `customFields`, `_metaType: "folder"` (folder marker entries), `deletedAt`.
- **Acceptance:** app export -> extension import -> extension export -> app import: har entry ka har field barabar.

## E4. Trash aur folder markers
- **Issue:** App me `deletedAt > 0` wali entries Bin me hoti hain; `_metaType == "folder"` entries folder marker hain.
- **Fix:** Extension in dono ko autofill/list me na dikhaye (agar abhi nahi karta), lekin export me preserve kare.
- **Logic:** Bin ki entries 30 din tak restore hoti hain, isliye hataani nahi.

## E5. Record types
- **Issue:** App `recordType` ki ye values use karta hai: `login` (default), `note`, `mobile`, `card`, `identity`, `personal`, `totp`, `file`.
- **Fix:** Extension unknown `recordType` par crash na kare; sirf `login` ko autofill me use kare; baaki ko list me chhup/ignore kare ya jaisa abhi karta hai, par preserve zaroor kare.

## E6. V3 container header (BADALNA NAHI)
- **Issue:** Header byte-identical hona zaroori hai (wahi GCM AAD hai).
- **Fix:** Kuch nahi badalna. Format: `{"header":{"format":"BSRPRO.Vault","version":3,"kdf":"PBKDF2-HMAC-SHA256","iterations":600000,"salt":"..","iv":"..","cipher":"AES-256-GCM","tagBits":128},"ciphertext":".."}`.
- **Logic:** `crypto.js` ke `canonicalHeader()` aur app ke `VaultCrypto.canonicalHeader()` ka output barabar rehna chahiye. Shared test vectors: `tools/golden/vectors.json` (generator `tools/golden/gen.js`) — extension update ke baad inhe dono taraf chalao.

## E7. Backup file ka naam aur folder
- **Issue:** App ek hi file rakhta hai: `BSRPRO.Vault` (default `Downloads/BSRPRO_Backups`, ya user ka chuna folder). Extension folder ka naam app me `BSRPRO Vault Password_Backups` hai.
- **Fix:** Extension bhi hamesha wahi ek naam likhe aur overwrite kare (`BSRPRO.Vault`), `BSRPRO (1).Vault` jaise numbered copies na banaye. Padhte waqt numbered copies ko ignore ya latest-by-time maane.
- **Logic:** Duplicate files se app/extension confuse hote the (Fix.md 1.3).

## E8. Missing-field tolerance (hardening)
- **Issue:** App abhi saare fields likhta hai, par future me khali defaults skip kar sakta hai.
- **Fix:** Extension padhte waqt har missing field ko default maane: strings `""`, booleans `false`, numbers `0`, arrays `[]`, `category` = `"other"`, `recordType` = `"login"`.
- **Logic:** App (kotlinx, `coerceInputValues`) already aisa karta hai.

## E9. Hidden vault tag (DECISION CHAHIYE — Fix.md me nahi hai)
- **Issue:** App me entry par tag `hidden-vault` ho to wo PIN-protected Hidden Vault me hoti hai aur normal Vault list me nahi dikhti.
- **Fix:** Fix.md me extension ke liye koi rule nahi. Fix.md section 6 ke hisaab se sawaal likha hai: extension in entries ko autofill/list me dikhaye ya chhupaye? Tab tak: sirf preserve kare (E3), behavior na badle.

## E10. App-side jo extension se jude hain (reference)
- Entry PIN (`appPin`) sirf Android autofill ke liye hai; extension ise web password field me kabhi fill na kare.
- App PIN (sharing + hidden vault) vault data me save nahi hota; extension ka isse koi lena-dena nahi.
- Secure share links app ka alag feature hain; extension me change nahi.

## E11. Auto-import (app side, Fix.md 1.3) — extension ko kya dhyan rakhna hai
- **Issue:** App ab unlock par (sirf khali vault me, ek baar) `BSRPRO.Vault` ko apne aap merge karta hai; wo file extension ne bhi likhi ho sakti hai (`BSRPRO Vault Password_Backups` folder bhi dekha jata hai).
- **Fix:** Extension ki likhi file me: (a) wahi V3 header (E6); (b) har entry ki `id` stable rahe (re-export par naye id mat banao); (c) password wahi master password jo app me hai, warna app file ko chhod deta hai.
- **Logic:** App sirf merge (upsert by `id`) karta hai, kuch replace/delete nahi. Id badalne par duplicates banenge.
- **Acceptance:** extension backup -> naya app vault (same master password) -> sab entries ek-ek baar aati hain, duplicate nahi.

## E12. Naye logins par `type` likho (Fix.md 1.1)
- **Issue:** App ab login save par `type` = `"website"` ya `"app"` likhta hai; extension ke naye logins me `type` khali rahta hai.
- **Fix:** Extension jab naya login banaye (url ke saath) to `type: "website"` likhe. `appPackage` wali entries ko kabhi `website` na bana de.
- **Logic:** Khali `type` app me phir bhi derive hota hai (`isAppLogin`), isliye ye sirf consistency hai; purani entries ka `type` kabhi overwrite mat karo.

## E13. Export me app logins gayab ho sakte hain
- **Issue:** App ke Export dialog me "App logins" checkbox hai (`includeAppLogins`); band hone par exported file me app entries nahi hongi.
- **Fix:** Extension import ko **merge** rakhe, replace nahi: file me jo entries nahi hain unhe extension ke vault se mat hatao.
- **Logic:** Warna app export (bina app logins) import karne par extension apne app-entries kho sakta hai.

## E14. App ke Saved / Used timestamps
- **Issue:** App list me app login ke `createdAt` ("Saved") aur `lastUsedAt` ("Used") dikhata hai.
- **Fix:** Extension in dono ko preserve kare (E3). `lastUsedAt` sirf tab badle jab extension khud us entry ko autofill kare.

## Status table (extension ZIP aate hi yahan tick karna)
| ID | Kaam | Extension me hua? |
|---|---|---|
| E1 | `BSRZ1:` reader | [x] src/vault-plaintext.js + decryptBackup/setup |
| E2 | `type`/app filter (sirf padhte waqt) | [x] background `_isAppLogin` + index (UI lists me abhi dikhte) |
| E3 | Round-trip, koi field nahi girna | [x] import/setup passthrough |
| E4 | Trash + folder markers preserve | [x] markers + deletedAt import me skip, index me skip |
| E5 | Unknown `recordType` safe | [x] pehle se safe |
| E6 | V3 header same, golden vectors | [x] golden vectors byte-identical |
| E7 | Ek file `BSRPRO.Vault`, numbered copies nahi | [x] auto-backup overwrite pehle se |
| E8 | Missing-field defaults | [x] pehle se defaults |
| E9 | Hidden-vault tag: DECISION baaki | [ ] DECISION baaki (sirf preserve) |
| E11 | Stable ids + merge-only | [x] id preserve + id se dup |
| E12 | Naye logins par `type: "website"` | [x] type:"website" naye logins par |
| E13 | Import = merge, delete nahi | [x] merge-only pehle se |
| E14 | `createdAt`/`lastUsedAt` preserve | [x] createdAt/lastUsedAt preserve |
| App | `COMPRESS_EXPORT = true` (extension 5.42.0 install hone ke BAAD) | [ ] |

## Extension ZIP milne par kya karunga (checklist)
1. `crypto.js`/decrypt wali file: E1 reader + E6 header test.
2. Entry model/normalize wali file: E3, E5, E8, E12, E14.
3. Autofill/list/matching: E2, E4.
4. Import/export/merge: E2 (delete nahi), E3, E7, E11, E13.
5. Tests: app <-> extension round-trip (E3), golden vectors (E6), compressed file (E1).
6. Report `EXTENSION-Report.md` isi Issue -> Fix -> Logic format me; phir app me `COMPRESS_EXPORT = true` ka alag patch.

## Extension v5.42.0 — hua (details: `EXTENSION-Report.md` extension ke root me)
E1-E8, E11-E14 lag gaye; E9 aapka faisla. Pata chala par badla nahi: extension ka manual export (`version 2.0`) uska apna V3 validator reject karta hai; UI lists me app logins dikhte hain.
