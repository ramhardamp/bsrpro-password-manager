package pro.babasitaram.vault.data.transfer

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class CompressedBackupDetectionTest {
    @Test fun `BSRZ1 payload is routed to compressed payload parser instead of CSV`() {
        assertEquals(SourceKind.COMPRESSED_PAYLOAD, ImportParser.detectKind("BSRZ1:SGVsbG8="))
    }

    @Test fun `BOM and whitespace before compressed marker are accepted`() {
        assertEquals(SourceKind.COMPRESSED_PAYLOAD, ImportParser.detectKind("\uFEFF  \nBSRZ1:SGVsbG8="))
    }
}
