package pro.babasitaram.vault.core.model

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.presentation.editor.EditorForm
import pro.babasitaram.vault.presentation.editor.toEntry

/** Fix.md 1.1: website vs app separation, and old vaults (empty type) keep working. */
class AppLoginTypeTest {
    @Test fun `legacy entry with package and no url is an app login`() {
        assertTrue(VaultEntry(appPackage = "com.jio.jpp1").isAppLogin)
    }

    @Test fun `legacy website entry is not an app login`() {
        assertFalse(VaultEntry(url = "https://site.com").isAppLogin)
        assertFalse(VaultEntry(url = "https://site.com", appPackage = "com.x").isAppLogin)
    }

    @Test fun `explicit type wins`() {
        assertTrue(VaultEntry(type = "app").isAppLogin)
        assertFalse(VaultEntry(type = "website", appPackage = "com.x").isAppLogin)
    }

    @Test fun `saving tags logins and never overwrites an existing type`() {
        assertEquals("app", EditorForm(appPackage = "com.x").toEntry(null).type)
        assertEquals("website", EditorForm(url = "https://a.com").toEntry(null).type)
        assertEquals("custom", EditorForm(url = "https://a.com").toEntry(VaultEntry(type = "custom")).type)
    }

    @Test fun `non login records keep an empty type`() {
        assertEquals("", EditorForm(recordType = "card").toEntry(null).type)
    }

    @Test fun `unknown type value falls back to the data`() {
        assertTrue(VaultEntry(type = "login", appPackage = "com.x").isAppLogin)
        assertFalse(VaultEntry(type = "login", url = "https://a.com", appPackage = "com.x").isAppLogin)
        assertFalse(VaultEntry(type = "login").isAppLogin)
    }
}
