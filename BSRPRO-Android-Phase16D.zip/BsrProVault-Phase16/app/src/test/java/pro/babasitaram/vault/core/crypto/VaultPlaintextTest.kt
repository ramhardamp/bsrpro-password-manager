package pro.babasitaram.vault.core.crypto

import java.io.File
import java.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.data.local.blob.FileVaultBlobStore

class VaultPlaintextTest {
    @TempDir
    lateinit var dir: File

    private val bigJson = """{"entries":[""" + (1..400).joinToString(",") { """{"id":"id$it","title":"Entry $it","notes":""}""" } + "]}"

    @Test fun `small payload stays plain json`() {
        val small = """{"entries":[]}"""
        assertEquals(small, VaultPlaintext.pack(small))
    }

    @Test fun `large payload is compressed smaller and round trips`() {
        val packed = VaultPlaintext.pack(bigJson)
        assertTrue(packed.startsWith(VaultPlaintext.MARKER))
        assertTrue(packed.length < bigJson.length / 2)
        assertEquals(bigJson, VaultPlaintext.unpack(packed))
    }

    @Test fun `plain json is returned unchanged by unpack`() {
        assertEquals(bigJson, VaultPlaintext.unpack(bigJson))
    }

    @Test fun `damaged compressed payload is an InvalidFormat error`() {
        assertThrows<VaultError.InvalidFormat> { VaultPlaintext.unpack(VaultPlaintext.MARKER + "not-base64!!") }
        val notGzip = Base64.getEncoder().encodeToString("hello".toByteArray())
        assertThrows<VaultError.InvalidFormat> { VaultPlaintext.unpack(VaultPlaintext.MARKER + notGzip) }
    }

    @Test fun `export stays uncompressed until the extension supports it`() {
        assertFalse(VaultPlaintext.COMPRESS_EXPORT)
        assertEquals(bigJson, VaultPlaintext.packForExport(bigJson))
    }

    @Test fun `parser reads a compressed payload`() {
        val parsed = V3PayloadParser.parse(VaultPlaintext.pack(bigJson))
        assertEquals(400, parsed.entries.size)
    }

    @Test fun `blob store writes a compressed vault and reads it back`() = runTest {
        val pw = "Master#Pass123456".toCharArray()
        val store = FileVaultBlobStore(dir, Dispatchers.IO)
        val entries = (1..300).map { VaultEntry(id = "id$it", title = "Entry $it", username = "user$it", password = "pw$it") }
        store.write(VaultData(entries, emptyList()), pw)
        val plain = VaultCrypto.decryptBlocking(File(dir, "vault.blob").readText().trim(), pw)
        assertTrue(plain.startsWith(VaultPlaintext.MARKER))
        assertEquals(300, store.read(pw).entries.size)
    }
}
