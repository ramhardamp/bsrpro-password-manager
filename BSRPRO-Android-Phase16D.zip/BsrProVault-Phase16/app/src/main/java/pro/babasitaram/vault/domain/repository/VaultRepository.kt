package pro.babasitaram.vault.domain.repository

import kotlinx.coroutines.flow.StateFlow
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultResult

interface VaultRepository {
    /** Visible entries (folder marker records are hidden but preserved on disk). */
    val entries: StateFlow<List<VaultEntry>>
    val folders: StateFlow<List<Folder>>
    /** Entries currently in the encrypted trash. */
    val trashedEntries: StateFlow<List<VaultEntry>>
    /** Visible mobile count: active, non-hidden entries with a non-blank mobile or phone field. */
    val mobileCount: StateFlow<Int>

    fun entry(id: String): VaultEntry?
    fun findDuplicate(candidate: VaultEntry): VaultEntry?

    /** Replace the in-memory vault after unlock/create/restore (does not write to disk). */
    suspend fun setData(data: VaultData)

    suspend fun upsert(entry: VaultEntry)

    /** Create or update a folder in one encrypted vault write. */
    suspend fun upsertFolder(folder: Folder): VaultResult<Unit>

    /** Remove a folder while preserving its entries by clearing their folder reference. */
    suspend fun deleteFolder(id: String): VaultResult<Unit>

    /** One disk write for many entries (import). Folders that are not present yet are added. */
    suspend fun upsertAll(entries: List<VaultEntry>, folders: List<Folder> = emptyList()) {
        entries.forEach { upsert(it) }
    }
    /** Move an entry to trash without losing its encrypted record. */
    suspend fun softDelete(id: String)

    /** Move many entries to trash with ONE encrypted vault write (bulk delete of hundreds of entries). */
    suspend fun softDeleteAll(ids: Collection<String>) {
        ids.forEach { softDelete(it) }
    }

    /** Restore a trashed entry to the active vault. */
    suspend fun restore(id: String)

    /** Restore every trashed entry with one encrypted write. */
    suspend fun restoreAll()

    /** Permanently remove every trashed entry. */
    suspend fun emptyTrash()

    /** Permanently remove entries deleted at least [retentionMs] ago. */
    suspend fun cleanupExpiredTrash(
        now: Long = System.currentTimeMillis(),
        retentionMs: Long = TRASH_RETENTION_MS
    )

    /** Backwards-compatible delete API: delete means move to trash. */
    suspend fun delete(id: String) = softDelete(id)

    /** Drop everything from memory + metadata DB (called on lock). */
    suspend fun clear()

    companion object {
        const val TRASH_RETENTION_DAYS: Long = 30
        const val TRASH_RETENTION_MS: Long = TRASH_RETENTION_DAYS * 24L * 60L * 60L * 1000L
    }
}
