package pro.babasitaram.vault.presentation.hidden

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import javax.inject.Named
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.core.util.HiddenVault
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.isHiddenVault
import pro.babasitaram.vault.domain.usecase.VerifyMasterPasswordUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage
import pro.babasitaram.vault.data.local.preferences.SensitiveActionPinStore
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L

enum class HiddenStage { LOADING, SETUP, LOCKED, OPEN }

@Stable
data class HiddenUiState(
    val stage: HiddenStage = HiddenStage.LOADING,
    val error: String? = null,
    val lockedForMs: Long = 0L,
    val message: String? = null
)

@HiltViewModel
class HiddenVaultViewModel @Inject constructor(
    private val repository: VaultRepository,
    @Named("hiddenPin") private val pinStore: SensitiveActionPinStore,
    private val saveEntry: SaveEntryUseCase,
    private val verifyMaster: VerifyMasterPasswordUseCase,
    private val activityLog: ActivityLogStore
) : ViewModel() {

    private val _state = MutableStateFlow(HiddenUiState())
    val state: StateFlow<HiddenUiState> = _state.asStateFlow()

    /** Entries only become visible once the PIN has been accepted in this screen session. */
    val entries: StateFlow<List<VaultEntry>> = repository.entries
        .map { all -> all.filter { it.deletedAt == 0L && it.isHiddenVault }.sortedBy { it.title.lowercase() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private var failures = 0
    private var lockedUntil = 0L

    init {
        launchCatching {
            _state.update { it.copy(stage = if (pinStore.isConfigured()) HiddenStage.LOCKED else HiddenStage.SETUP) }
        }
    }

    /** The App PIN is shared with secure sharing, so it is always set / changed with the master password. */
    private suspend fun checkMaster(master: String): String? {
        if (master.isEmpty()) return L.s(R.string.p19_enter_master)
        val pw = master.toCharArray()
        return try {
            when (val r = verifyMaster(pw)) {
                is VaultResult.Success -> null
                is VaultResult.Failure -> r.error.toUserMessage()
                VaultResult.Loading -> L.s(R.string.p19_try_again)
            }
        } finally {
            pw.fill('\u0000')
        }
    }

    fun setupPin(master: String, pin: String, confirm: String) {
        val clean = pin.filter(Char::isDigit)
        when {
            clean.length !in 4..6 -> _state.update { it.copy(error = L.s(R.string.p18_hidden_vault_pin_must_be_4_to)) }
            clean != confirm.filter(Char::isDigit) -> _state.update { it.copy(error = L.s(R.string.p18_hidden_vault_pins_do_not_match)) }
            else -> launchCatching {
                val problem = checkMaster(master)
                if (problem != null) {
                    _state.update { it.copy(error = problem) }
                    return@launchCatching
                }
                pinStore.save(clean.toCharArray())
                activityLog.record("Hidden vault PIN set", "Hidden vault PIN configured (App PIN)")
                _state.update { it.copy(stage = HiddenStage.OPEN, error = null, message = L.s(R.string.p18_hidden_vault_app_pin_saved)) }
            }
        }
    }

    /** 5 wrong PINs → 30 s wait (in memory; the vault itself is already behind the master password). */
    fun unlock(pin: String) {
        val now = System.currentTimeMillis()
        if (now < lockedUntil) {
            _state.update { it.copy(error = L.s(R.string.p18_hidden_vault_too_many_attempts_try_again, ((lockedUntil - now) / 1000) + 1), lockedForMs = lockedUntil - now) }
            return
        }
        launchCatching {
            if (pinStore.verify(pin.filter(Char::isDigit).take(6).toCharArray())) {
                failures = 0
                _state.update { it.copy(stage = HiddenStage.OPEN, error = null) }
            } else {
                failures++
                if (failures >= 5) {
                    failures = 0
                    lockedUntil = System.currentTimeMillis() + 30_000L
                    _state.update { it.copy(error = L.s(R.string.p18_hidden_vault_too_many_attempts_try_again_2), lockedForMs = 30_000L) }
                } else {
                    _state.update { it.copy(error = L.s(R.string.p18_hidden_vault_wrong_pin_attempts_left, 5 - failures)) }
                }
            }
        }
    }

    fun lock() = _state.update { it.copy(stage = HiddenStage.LOCKED, error = null, message = null) }

    fun unhide(entry: VaultEntry) {
        launchCatching {
            val updated = entry.copy(tags = entry.tags.filterNot { it.equals(HiddenVault.TAG, ignoreCase = true) })
            saveEntry(updated, entry)
            _state.update { it.copy(message = L.s(R.string.p18_hidden_moved_back, entry.title.ifBlank { L.s(R.string.p17_secure_entry) })) }
        }
    }

    /** Returns null on success, otherwise the message for the dialog. */
    suspend fun changePin(master: String, newPin: String): String? {
        val clean = newPin.filter(Char::isDigit)
        if (clean.length !in 4..6) return L.s(R.string.p19_pin_4_6)
        val problem = checkMaster(master)
        if (problem != null) return problem
        pinStore.save(clean.toCharArray())
        activityLog.record("Hidden vault PIN changed", "Hidden vault PIN updated (App PIN)")
        _state.update { it.copy(error = null, message = L.s(R.string.p18_hidden_vault_app_pin_changed)) }
        return null
    }

    /** Removing the PIN is only allowed when nothing is hidden, so entries can never become unreachable. */
    suspend fun removePin(master: String): String? {
        if (entries.value.isNotEmpty()) return L.s(R.string.p19_hidden_not_empty)
        val problem = checkMaster(master)
        if (problem != null) return problem
        pinStore.clear()
        activityLog.record("Hidden vault PIN removed", "Hidden vault PIN removed (App PIN)")
        _state.update { it.copy(stage = HiddenStage.SETUP, error = null, message = L.s(R.string.p18_hidden_vault_app_pin_removed)) }
        return null
    }

    fun clearMessage() = _state.update { it.copy(message = null, error = null) }
}
