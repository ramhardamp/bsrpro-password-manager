package pro.babasitaram.vault.presentation.setup

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.domain.usecase.CreateVaultUseCase
import pro.babasitaram.vault.domain.usecase.RestoreBackupUseCase
import pro.babasitaram.vault.domain.usecase.RecoveryKeyUseCase
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.presentation.util.toUserMessage

import androidx.compose.foundation.layout.*
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L

@Stable
data class SetupUiState(
    val busy: Boolean = false,
    val error: String? = null,
    val awaitingBackupPassword: Boolean = false,
    val recoveryKey: String? = null,
    val backupFolderUri: String = ""
)

@HiltViewModel
class SetupViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val createVault: CreateVaultUseCase,
    private val restoreBackup: RestoreBackupUseCase,
    private val recoveryKey: RecoveryKeyUseCase,
    private val clipboard: pro.babasitaram.vault.presentation.util.ClipboardActions,
    private val activityLog: ActivityLogStore,
    private val settings: SettingsRepository
) : ViewModel() {

    /** Copies a secret through the vault clipboard manager (sensitive flag + auto-clear). */
    fun copySecret(text: String, label: String) {
        launchCatching { clipboard.copy(text, label) }
    }

    private val _state = MutableStateFlow(SetupUiState())
    val state: StateFlow<SetupUiState> = _state.asStateFlow()

    private var pendingBackup: String? = null

    init {
        launchCatching { settings.settings.collect { cfg -> _state.update { it.copy(backupFolderUri = cfg.backupFolderUri) } } }
    }

    fun onBackupFolderSelected(uri: Uri) {
        launchCatching {
            settings.update { it.copy(backupFolderUri = uri.toString()) }
            _state.update { it.copy(error = null, backupFolderUri = uri.toString()) }
        }
    }

    fun onBackupTreeSelected(treeUri: Uri) {
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            try {
                val treeId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
                val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeId)
                var found: Uri? = null
                context.contentResolver.query(children, arrayOf(
                    android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME
                ), null, null, null)?.use { c ->
                    val idCol = c.getColumnIndexOrThrow(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    val nameCol = c.getColumnIndexOrThrow(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    while (c.moveToNext()) if (c.getString(nameCol).equals("BSRPRO.Vault", true)) {
                        found = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, c.getString(idCol)); break
                    }
                } ?: throw java.io.IOException("Cannot read selected folder")
                val fileUri = found ?: throw java.io.FileNotFoundException(L.s(R.string.setup_backup_not_found))
                val text = withContext(Dispatchers.IO) {
                    val bytes = context.contentResolver.openInputStream(fileUri)?.use { it.readBytes() } ?: throw java.io.IOException("Backup cannot be opened")
                    require(bytes.size in 1..MAX_BACKUP_BYTES) { "Backup size is invalid" }
                    String(bytes, Charsets.UTF_8)
                }
                pendingBackup = text
                settings.update { it.copy(backupFolderUri = treeUri.toString()) }
                _state.update { it.copy(busy = false, backupFolderUri = treeUri.toString(), awaitingBackupPassword = true) }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, error = e.message ?: "Backup folder could not be read") }
            }
        }
    }

    fun create(password: String, confirm: String) {
        val pw = password.toCharArray()
        val cf = confirm.toCharArray()
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            val r = createVault(pw, cf)
            pw.fill('\u0000')
            cf.fill('\u0000')
            if (r is VaultResult.Success) {
                activityLog.record("Vault created", "Initial vault setup completed")
                when (val recovery = recoveryKey.ensureCreated()) {
                    is VaultResult.Success -> _state.update { it.copy(busy = false, recoveryKey = recovery.value) }
                    is VaultResult.Failure -> _state.update { it.copy(busy = false, error = recovery.error.toUserMessage()) }
                    VaultResult.Loading -> Unit
                }
            } else {
                _state.update { it.copy(busy = false, error = (r as? VaultResult.Failure)?.error?.toUserMessage()) }
            }
            // On success the session unlocks and RootViewModel switches to the vault screens.
        }
    }

    fun dismissRecoveryKey() {
        _state.update { it.copy(recoveryKey = null) }
    }

    fun onBackupPicked(uri: Uri) {
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            val text = try {
                withContext(Dispatchers.IO) {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw java.io.IOException("Cannot open file")
                    require(bytes.size <= MAX_BACKUP_BYTES) { "File too large" }
                    String(bytes, Charsets.UTF_8)
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, error = L.s(R.string.p18_setup_could_not_read_the_selected)) }
                return@launchCatching
            }
            pendingBackup = text
            _state.update { it.copy(busy = false, awaitingBackupPassword = true) }
        }
    }

    fun restore(backupPassword: String) {
        val text = pendingBackup ?: return
        val pw = backupPassword.toCharArray()
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            val r = restoreBackup(text, pw)
            pw.fill('\u0000')
            if (r is VaultResult.Failure) {
                _state.update { it.copy(busy = false, error = r.error.toUserMessage(), awaitingBackupPassword = true) }
            } else {
                activityLog.record("Restore completed", "Backup restored during setup")
                pendingBackup = null
                _state.update { it.copy(busy = false, awaitingBackupPassword = false) }
            }
        }
    }

    fun cancelRestore() {
        pendingBackup = null
        _state.update { it.copy(awaitingBackupPassword = false) }
    }

    private companion object {
        const val MAX_BACKUP_BYTES = 50_000_000
    }
}
