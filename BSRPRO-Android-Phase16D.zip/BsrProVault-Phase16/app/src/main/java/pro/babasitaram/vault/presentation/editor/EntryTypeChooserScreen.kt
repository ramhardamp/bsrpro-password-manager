@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.editor

import androidx.activity.compose.BackHandler
import androidx.annotation.StringRes
import androidx.compose.ui.res.stringResource
import pro.babasitaram.vault.R
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Note
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

enum class NewEntryType(@StringRes val label: Int, @StringRes val hint: Int, val icon: ImageVector, val color: Color) {
    PASSWORD(R.string.type_password, R.string.type_password_hint, Icons.Default.Lock, Color(0xFF3B82F6)),
    NOTE(R.string.type_note, R.string.type_note_hint, Icons.Default.Note, Color(0xFFF59E0B)),
    TOTP(R.string.type_totp, R.string.type_totp_hint, Icons.Default.Pin, Color(0xFFA78BFA)),
    CARD(R.string.type_card, R.string.type_card_hint, Icons.Default.CreditCard, Color(0xFFEC4899)),
    IDENTITY(R.string.type_identity, R.string.type_identity_hint, Icons.Default.Badge, Color(0xFF10B981)),
    APP_LOGIN(R.string.type_app_login, R.string.type_app_login_hint, Icons.Default.PhoneAndroid, Color(0xFF6366F1)),
    MOBILE(R.string.type_mobile, R.string.type_mobile_hint, Icons.Default.Smartphone, Color(0xFF06B6D4))
}

/** Step 1 of New Entry: pick the type, then the type-specific form opens. */
@Composable
fun EntryTypeChooserScreen(onBack: () -> Unit, onPick: (NewEntryType) -> Unit) {
    BackHandler { onBack() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.new_entry_title), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { Text(stringResource(R.string.new_entry_prompt), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 4.dp)) }
            items(NewEntryType.values().toList(), key = { it.name  }, contentType = { "item" }) { type ->
                Card(Modifier.fillMaxWidth().clickable { onPick(type) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Box(
                            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(type.color.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) { Icon(type.icon, null, tint = type.color, modifier = Modifier.size(20.dp)) }
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(type.label), style = MaterialTheme.typography.titleMedium)
                            Text(stringResource(type.hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
