package pro.babasitaram.vault.core.util

import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources
import androidx.annotation.PluralsRes
import androidx.annotation.StringRes
import java.util.Locale

/**
 * Localised strings for code that has no Compose context: ViewModels, use cases, Services, the autofill
 * UI, notifications, the widget and BiometricPrompt text. Composables should use `stringResource(...)`.
 *
 * The language is the in-app choice stored by [LocaleHelper] (English / हिन्दी / system), so text produced
 * here always matches what the Activity shows. Strings must be resolved at *use* time and never cached in
 * `val`s that outlive a language switch.
 *
 * In JVM unit tests no Android provider exists; [install] lets a test supply one. Without any provider
 * [s] returns a visible placeholder instead of throwing, so logic tests that only check error types
 * stay independent of resources.
 */
object L {
    interface Provider {
        fun string(@StringRes id: Int, args: Array<out Any?>): String
        fun plural(@PluralsRes id: Int, quantity: Int, args: Array<out Any?>): String
    }

    @Volatile
    private var provider: Provider? = null

    fun install(p: Provider?) {
        provider = p
    }

    /** Installs the Android-backed provider (idempotent). Called from Application.onCreate. */
    fun init(app: Context) {
        if (provider == null) provider = AndroidProvider(app.applicationContext)
    }

    fun s(@StringRes id: Int): String = s(id, *NO_ARGS)

    fun s(@StringRes id: Int, vararg args: Any?): String =
        provider?.string(id, args) ?: "#$id"

    fun p(@PluralsRes id: Int, quantity: Int, vararg args: Any?): String =
        provider?.plural(id, quantity, args) ?: "#$id"

    /** Called by [LocaleHelper.save] so the next lookup rebuilds its localised resources. */
    fun onLanguageChanged() {
        (provider as? AndroidProvider)?.reset()
    }

    /** Resources forced to English (used so Settings search matches both the shown language and English). */
    fun englishResources(context: Context): Resources {
        val cfg = Configuration(context.resources.configuration)
        cfg.setLocale(Locale.ENGLISH)
        return context.createConfigurationContext(cfg).resources
    }

    private val NO_ARGS = emptyArray<Any?>()

    private class AndroidProvider(private val app: Context) : Provider {
        @Volatile private var cachedCode: String? = null
        @Volatile private var cachedRes: Resources? = null

        fun reset() {
            cachedCode = null
            cachedRes = null
        }

        private fun res(): Resources {
            val code = LocaleHelper.read(app)
            val cur = cachedRes
            if (cur != null && cachedCode == code) return cur
            val built = if (code == LocaleHelper.SYSTEM) {
                app.resources
            } else {
                val cfg = Configuration(app.resources.configuration)
                cfg.setLocale(Locale.forLanguageTag(code))
                app.createConfigurationContext(cfg).resources
            }
            cachedRes = built
            cachedCode = code
            return built
        }

        override fun string(id: Int, args: Array<out Any?>): String =
            if (args.isEmpty()) res().getString(id) else res().getString(id, *args)

        override fun plural(id: Int, quantity: Int, args: Array<out Any?>): String =
            res().getQuantityString(id, quantity, *args)
    }
}
