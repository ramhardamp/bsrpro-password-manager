@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.generator

import androidx.activity.compose.BackHandler

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.presentation.components.PasswordField
import pro.babasitaram.vault.presentation.components.StrengthMeter
import pro.babasitaram.vault.presentation.util.CollectMessages
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import pro.babasitaram.vault.R
import androidx.compose.ui.res.stringResource

@Composable
fun GeneratorScreen(onBack: () -> Unit, vm: GeneratorViewModel = hiltViewModel()) {
    BackHandler { onBack() }
    val state by vm.state.collectAsStateWithLifecycle()
    CollectMessages(vm.messages)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_143), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = state.mode.ordinal) {
                GeneratorMode.values().forEach { m ->
                    Tab(selected = state.mode == m, onClick = { vm.setMode(m) }, text = { Text(m.label) })
                }
            }
            // Scrollable body; the action button below is pinned so it is always visible.
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (state.mode != GeneratorMode.MANUAL) {
                    // Big password, copy + regenerate right beside it
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                state.generated,
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.headlineSmall,
                                modifier = Modifier.weight(1f)
                            )
                            Column {
                                IconButton(onClick = vm::copy, enabled = state.output.isNotEmpty()) {
                                    Icon(Icons.Default.ContentCopy, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_142))
                                }
                                IconButton(onClick = vm::regenerate) { Icon(Icons.Default.Refresh, "Regenerate") }
                            }
                        }
                    }
                }
                StrengthMeter(state.output)
                when (state.mode) {
                    GeneratorMode.RANDOM -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_generator_length, state.options.length), style = MaterialTheme.typography.labelLarge, modifier = Modifier.width(96.dp))
                            Slider(
                                value = state.options.length.toFloat(),
                                onValueChange = { v -> vm.setOptions { it.copy(length = v.toInt()) } },
                                valueRange = 8f..256f,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        // options in a 2x2 grid
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OptionCell("a-z", state.options.lower, Modifier.weight(1f)) { v -> vm.setOptions { it.copy(lower = v) } }
                            OptionCell("A-Z", state.options.upper, Modifier.weight(1f)) { v -> vm.setOptions { it.copy(upper = v) } }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OptionCell("0-9", state.options.digits, Modifier.weight(1f)) { v -> vm.setOptions { it.copy(digits = v) } }
                            OptionCell("!@#…", state.options.symbols, Modifier.weight(1f)) { v -> vm.setOptions { it.copy(symbols = v) } }
                        }
                        ToggleRow("Avoid look-alikes (I l 1 O 0)", state.options.excludeAmbiguous) { v -> vm.setOptions { it.copy(excludeAmbiguous = v) } }
                        OutlinedTextField(
                            value = state.options.keyword,
                            onValueChange = { v -> vm.setOptions { it.copy(keyword = v.take(32)) } },
                            label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_144)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    GeneratorMode.PASSPHRASE -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_generator_words, state.words), style = MaterialTheme.typography.labelLarge, modifier = Modifier.width(96.dp))
                            Slider(
                                value = state.words.toFloat(),
                                onValueChange = { vm.setWords(it.toInt()) },
                                valueRange = 3f..10f,
                                steps = 6,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        OutlinedTextField(
                            value = state.separator,
                            onValueChange = vm::setSeparator,
                            label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_145)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    GeneratorMode.PIN -> {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_generator_pin_length, state.pinLength), style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            (4..6).forEach { length ->
                                androidx.compose.material3.FilterChip(
                                    selected = state.pinLength == length,
                                    onClick = { vm.setPinLength(length) },
                                    label = { Text(length.toString()) }
                                )
                            }
                        }
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_146), style = MaterialTheme.typography.bodySmall)
                    }
                    GeneratorMode.MANUAL -> {
                        PasswordField(state.manual, vm::setManual, stringResource(R.string.p18_generator_type_a_password_to_check))
                    }
                }
            }
            // sticky bottom action
            Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { vm.copy(); onBack() },
                    enabled = state.output.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_147)) }
            }
        }
    }
}

@Composable
private fun OptionCell(label: String, checked: Boolean, modifier: Modifier = Modifier, onChange: (Boolean) -> Unit) {
    FilterChip(
        selected = checked,
        onClick = { onChange(!checked) },
        label = { Text(label, modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.bodyLarge) },
        modifier = modifier.height(40.dp)
    )
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
