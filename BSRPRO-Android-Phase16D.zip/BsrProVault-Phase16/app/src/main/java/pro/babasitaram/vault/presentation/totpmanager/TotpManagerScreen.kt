@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
package pro.babasitaram.vault.presentation.totpmanager

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.Totp
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.components.AppDimens

@Composable
fun TotpManagerScreen(
    onBack: () -> Unit = {},
    onAdd: () -> Unit = {},
    onOpen: (String) -> Unit = {},
    onEdit: (String) -> Unit = {},
    onShare: (String) -> Unit = {},
    vm: TotpManagerViewModel = hiltViewModel()
) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    val query by vm.queryState.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    BackHandler { onBack() }
    CollectMessages(vm.messages)
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1_000L)
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.p15_totp_manager), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onAdd, icon = { Icon(Icons.Default.Add, null) }, text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_156)) })
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (entries.size > 1 || query.isNotBlank()) {
                OutlinedTextField(
                    value = query,
                    onValueChange = vm::setQuery,
                    placeholder = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_157)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(12.dp)
                )
            }
            if (entries.isEmpty()) {
                EmptyState(
                    stringResource(R.string.p15_no_totp_entries),
                    stringResource(R.string.totp_empty_message),
                    Modifier.fillMaxSize(),
                    actionLabel = stringResource(R.string.p15_add),
                    onAction = onAdd
                )
            } else {
                LazyColumn(
                    Modifier.fillMaxSize().padding(horizontal = AppDimens.ScreenHorizontal),
                    verticalArrangement = Arrangement.spacedBy(AppDimens.ItemSpacing)
                ) {
                    items(entries, key = { it.id  }, contentType = { "item" }) { entry ->
                        TotpItem(
                            entry = entry,
                            now = now,
                            onOpen = { onOpen(entry.id) },
                            onEdit = { onEdit(entry.id) },
                            onShare = { onShare(entry.id) },
                            onCopy = vm::copyCode,
                            onDelete = { vm.delete(entry.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TotpItem(
    entry: VaultEntry,
    now: Long,
    onOpen: () -> Unit,
    onEdit: () -> Unit,
    onShare: () -> Unit,
    onCopy: (String) -> Unit,
    onDelete: () -> Unit
) {
    val result = Totp.current(entry.totp, now)
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    Card(
        Modifier.fillMaxWidth().combinedClickable(onClick = onOpen, onLongClick = { menu = true })
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(entry.title.ifBlank { stringResource(pro.babasitaram.vault.R.string.p17_untitled) }, style = MaterialTheme.typography.titleMedium)
                    if (entry.username.isNotBlank()) Text(entry.username, style = MaterialTheme.typography.bodyMedium)
                }
                BoxMenu(
                    expanded = menu,
                    onToggle = { menu = !menu },
                    onDismiss = { menu = false },
                    onEdit = { menu = false; onEdit() },
                    onShare = { menu = false; onShare() },
                    onDelete = { menu = false; confirmDelete = true }
                )
            }
            if (result == null) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_158), color = MaterialTheme.colorScheme.error)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(AppDimens.ItemSpacing)) {
                    CircularProgressIndicator(
                        progress = { result.secondsRemaining.coerceAtLeast(0) / 30f },
                        modifier = Modifier.size(42.dp),
                        strokeWidth = 4.dp
                    )
                    Text(result.code, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
                    IconButton(onClick = { onCopy(result.code) }) { Icon(Icons.Default.ContentCopy, "Copy code") }
                }
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_totp_expires, result.secondsRemaining))
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_159)) },
            text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_totp_bin_restore, entry.title.ifBlank { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_totp_default_entry) })) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_033)) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}

@Composable
private fun BoxMenu(
    expanded: Boolean,
    onToggle: () -> Unit,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    Box {
        IconButton(onClick = onToggle) { Icon(Icons.Default.MoreVert, "More") }
        DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
            DropdownMenuItem(text = { Text(stringResource(R.string.p15_edit)) }, onClick = onEdit)
            DropdownMenuItem(text = { Text(stringResource(R.string.p15_share)) }, onClick = onShare)
            DropdownMenuItem(text = { Text(stringResource(R.string.p15_delete)) }, onClick = onDelete)
        }
    }
}
