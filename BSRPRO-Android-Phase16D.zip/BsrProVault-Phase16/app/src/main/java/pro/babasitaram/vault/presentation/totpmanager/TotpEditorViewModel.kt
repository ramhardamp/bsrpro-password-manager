package pro.babasitaram.vault.presentation.totpmanager

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.Totp
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L

@Stable
data class TotpEditorState(
    val title: String = "",
    val username: String = "",
    val secret: String = "",
    val algorithm: String = "SHA1",
    val digits: Int = 6,
    val period: Int = 30,
    val backupCodes: String = "",
    val saving: Boolean = false,
    val saved: Boolean = false,
    val error: String? = null,
    val existing: VaultEntry? = null
)

/** TOTP-only editor: Title, Username, Secret (base32), Algorithm, Digits, Period, Backup codes. */
@HiltViewModel
class TotpEditorViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    repository: VaultRepository,
    private val saveEntry: SaveEntryUseCase
) : ViewModel() {
    private val id = savedStateHandle.get<String>("id").orEmpty()
    private val existing = id.takeIf { it.isNotBlank() }?.let(repository::entry)
    private val parsed = existing?.totp?.let { Totp.parse(it) }

    private val _state = MutableStateFlow(
        TotpEditorState(
            title = existing?.title.orEmpty(),
            username = existing?.username.orEmpty().ifEmpty { existing?.email.orEmpty() },
            secret = parsed?.secret.orEmpty(),
            algorithm = parsed?.algorithm ?: "SHA1",
            digits = parsed?.digits ?: 6,
            period = parsed?.periodSeconds ?: 30,
            backupCodes = existing?.notes.orEmpty(),
            existing = existing
        )
    )
    val state: StateFlow<TotpEditorState> = _state.asStateFlow()

    fun setTitle(v: String) = _state.update { it.copy(title = v, error = null) }
    fun setUsername(v: String) = _state.update { it.copy(username = v, error = null) }
    fun setSecret(v: String) = _state.update { it.copy(secret = v, error = null) }
    fun setAlgorithm(v: String) = _state.update { it.copy(algorithm = v) }
    fun setDigits(v: Int) = _state.update { it.copy(digits = v) }
    fun setPeriod(v: Int) = _state.update { it.copy(period = v) }
    fun setBackupCodes(v: String) = _state.update { it.copy(backupCodes = v) }

    fun save() {
        val s = _state.value
        val cleanSecret = s.secret.trim().let { raw ->
            // accept a pasted otpauth:// link as well as a bare secret
            if (raw.startsWith("otpauth://", true)) Totp.parse(raw)?.secret.orEmpty() else raw
        }.filterNot { it.isWhitespace() || it == '-' }.uppercase()
        if (s.title.isBlank()) { _state.update { it.copy(error = L.s(R.string.p18_totp_editor_enter_a_service_name)) }; return }
        if (cleanSecret.isEmpty() || Totp.base32Decode(cleanSecret) == null) {
            _state.update { it.copy(error = L.s(R.string.p18_totp_editor_secret_must_be_a_valid)) }
            return
        }
        launchCatching {
            _state.update { it.copy(saving = true, error = null) }
            val uri = Totp.buildUri(cleanSecret, s.title.trim(), s.username.trim(), s.algorithm, s.digits, s.period)
            val entry = (s.existing ?: VaultEntry()).copy(
                title = s.title.trim(),
                username = s.username.trim(),
                totp = uri,
                notes = s.backupCodes,
                recordType = "totp",
                isNote = false
            )
            when (val r = saveEntry(entry, s.existing)) {
                is VaultResult.Success -> _state.update { it.copy(saving = false, saved = true) }
                is VaultResult.Failure -> _state.update { it.copy(saving = false, error = r.error.toUserMessage()) }
                VaultResult.Loading -> Unit
            }
        }
    }
}
