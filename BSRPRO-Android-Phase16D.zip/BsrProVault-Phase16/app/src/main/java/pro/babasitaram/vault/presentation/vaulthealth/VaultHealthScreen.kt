package pro.babasitaram.vault.presentation.vaulthealth

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Row

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry

@Composable
fun VaultHealthScreen(
    onBack: () -> Unit = {},
    onOpenEntry: (String) -> Unit = {},
    vm: VaultHealthViewModel = hiltViewModel()
) {
    BackHandler { onBack() }
    val state by vm.state.collectAsStateWithLifecycle()
    val breach by vm.breach.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.p15_vault_health), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.p15_back))
                    }
                }
            )
        }
    ) { padding ->
        if (state.total == 0) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                HealthScoreCard(state)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.health_no_entries), style = MaterialTheme.typography.titleMedium)
                        Text(stringResource(R.string.health_no_entries_message))
                    }
                }
            }
        } else {
            LazyColumn(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { HealthScoreCard(state) }
                if (state.weakPasswords.isNotEmpty()) {
                    item {
                        BreachIssueCard(stringResource(R.string.p15_weak_passwords), state.weakPasswords, breach, vm, onOpenEntry)
                    }
                }
                if (state.reusedPasswords.isNotEmpty()) {
                    item { IssueCard(stringResource(R.string.p15_reused_passwords), state.reusedPasswords) }
                }
                if (state.duplicateLogins.isNotEmpty()) {
                    item { IssueCard(stringResource(R.string.health_duplicate_logins), state.duplicateLogins) }
                }
                if (state.oldPasswords.isNotEmpty()) {
                    item { IssueCard(stringResource(R.string.health_old_passwords), state.oldPasswords, onOpenEntry, stringResource(R.string.health_review_rotate)) }
                }
                if (state.missingUsernames.isNotEmpty()) {
                    item { IssueCard(stringResource(R.string.health_missing_usernames), state.missingUsernames) }
                }
                if (
                    state.weakPasswords.isEmpty() &&
                    state.reusedPasswords.isEmpty() &&
                    state.duplicateLogins.isEmpty() &&
                    state.oldPasswords.isEmpty() &&
                    state.missingUsernames.isEmpty()
                ) {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.health_no_findings), modifier = Modifier.padding(20.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HealthScoreCard(state: VaultHealthState) {
    Card(Modifier.fillMaxWidth()) {
        Column(
            Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Default.Shield, contentDescription = null)
            Text(stringResource(R.string.health_score), style = MaterialTheme.typography.titleMedium)
            Text(
                "${state.score}/100",
                style = MaterialTheme.typography.displaySmall
            )
            LinearProgressIndicator(
                progress = { state.score / 100f },
                modifier = Modifier.fillMaxWidth()
            )
            Text(stringResource(R.string.health_total_entries, state.total))
            Text(stringResource(R.string.health_total_unique_issues, state.uniqueIssueCount))
            Text(
                stringResource(R.string.health_breakdown, state.weakPasswords.size, state.reusedPasswords.size, state.oldPasswords.size, state.duplicateLogins.size, state.missingUsernames.size),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun IssueCard(
    title: String,
    entries: List<VaultEntry>,
    onOpenEntry: (String) -> Unit = {},
    actionLabel: String? = null
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            entries.take(20).forEach { entry ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(entry.title.ifBlank { stringResource(R.string.health_untitled) }, modifier = Modifier.weight(1f))
                    TextButton(onClick = { onOpenEntry(entry.id) }) {
                        Text(actionLabel ?: stringResource(R.string.health_view))
                    }
                }
            }
            if (entries.size > 20) Text(stringResource(R.string.health_more, entries.size - 20))
        }
    }
}


@Composable
private fun BreachIssueCard(
    title: String,
    entries: List<VaultEntry>,
    breach: Map<String, String>,
    vm: VaultHealthViewModel,
    onOpenEntry: (String) -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            entries.take(20).forEach { entry ->
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(entry.title.ifBlank { stringResource(R.string.health_untitled) }, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onOpenEntry(entry.id) }) { Text(stringResource(R.string.health_view)) }
                    }
                    TextButton(onClick = { vm.checkBreach(entry) }) {
                        Text(breach[entry.id] ?: stringResource(R.string.health_check_breach))
                    }
                }
            }
            if (entries.size > 20) Text(stringResource(R.string.health_more, entries.size - 20))
        }
    }
}
