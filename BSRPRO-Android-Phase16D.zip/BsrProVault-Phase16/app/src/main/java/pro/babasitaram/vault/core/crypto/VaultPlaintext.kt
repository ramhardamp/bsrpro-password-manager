package pro.babasitaram.vault.core.crypto

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.Base64
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import pro.babasitaram.vault.core.util.VaultError

/**
 * Size optimisation for the vault payload (Fix.md 5.2). Compression happens BEFORE encryption, so the encryption itself
 * is unchanged.
 *
 * Wire format of a compressed payload (this is the spec the browser extension has to implement later):
 *   "BSRZ1:" + Base64( gzip( UTF-8 JSON ) )
 * A payload that does not start with the marker is plain JSON and is read exactly as before, so every existing vault,
 * backup and extension file keeps working. [unpack] is called from V3PayloadParser.parse(), so every reader accepts both.
 */
object VaultPlaintext {
    const val MARKER = "BSRZ1:"

    /** Below this size compression gains almost nothing, so small vaults stay plain JSON. */
    internal const val MIN_CHARS = 16 * 1024

    /** Decompression cap (zip-bomb guard); the app already rejects vaults above 100k entries. */
    private const val MAX_BYTES = 64 * 1024 * 1024

    /**
     * Whether the exported/backed-up .Vault file (the one the extension reads) is compressed too.
     * Keep FALSE until the extension understands [MARKER]; the internal on-device vault is compressed regardless.
     */
    const val COMPRESS_EXPORT = false

    fun pack(json: String): String {
        if (json.length < MIN_CHARS) return json
        val gz = ByteArrayOutputStream().also { buf ->
            GZIPOutputStream(buf).use { it.write(json.toByteArray(Charsets.UTF_8)) }
        }.toByteArray()
        val packed = MARKER + Base64.getEncoder().encodeToString(gz)
        return if (packed.length < json.length) packed else json
    }

    fun unpack(plain: String): String {
        if (!plain.startsWith(MARKER)) return plain
        try {
            val gz = Base64.getDecoder().decode(plain.substring(MARKER.length))
            GZIPInputStream(ByteArrayInputStream(gz)).use { input ->
                val out = ByteArrayOutputStream()
                val chunk = ByteArray(16 * 1024)
                while (true) {
                    val n = input.read(chunk)
                    if (n < 0) break
                    if (out.size() + n > MAX_BYTES) throw VaultError.InvalidFormat("Vault payload is too large")
                    out.write(chunk, 0, n)
                }
                return out.toString(Charsets.UTF_8.name())
            }
        } catch (e: VaultError) {
            throw e
        } catch (e: IOException) {
            throw VaultError.InvalidFormat("Vault payload is damaged")
        } catch (e: IllegalArgumentException) {
            throw VaultError.InvalidFormat("Vault payload is damaged")
        }
    }

    /** Used by exports: compressed only once [COMPRESS_EXPORT] is switched on. */
    fun packForExport(json: String): String = if (COMPRESS_EXPORT) pack(json) else json
}
