@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.contacts

import pro.babasitaram.vault.R

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.res.stringResource
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.core.util.L

@Composable
fun ContactsImportScreen(onBack: () -> Unit, vm: ContactsImportViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val state by vm.state.collectAsStateWithLifecycle()
    fun hasPermission() = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(hasPermission()) }
    var denied by remember { mutableStateOf(false) }
    var confirmLargeImport by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        denied = !ok
        if (ok) vm.load()
    }
    BackHandler { onBack() }
    CollectMessages(vm.messages)
    LaunchedEffect(granted) { if (granted && !state.loaded) vm.load() }
    LaunchedEffect(vm) { for (e in vm.finished) onBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.contacts_import_title)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.p15_back)) } }
            )
        },
        bottomBar = {
            if (granted && state.loaded) {
                Surface(tonalElevation = 3.dp) {
                    Button(
                        onClick = { if (state.selected.size >= 1000) confirmLargeImport = true else vm.importSelected() },
                        enabled = state.selected.isNotEmpty() && !state.importing,
                        modifier = Modifier.fillMaxWidth().padding(16.dp)
                    ) { Text(stringResource(R.string.contacts_import_selected, state.selected.size)) }
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                !granted -> PermissionPane(
                    denied = denied,
                    onAllow = { launcher.launch(Manifest.permission.READ_CONTACTS) },
                    onSettings = {
                        runCatching {
                            context.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                            )
                        }
                    },
                    onRecheck = { granted = hasPermission(); if (granted) vm.load() }
                )
                state.loading && !state.loaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                state.error != null && !state.loaded -> Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(state.error.orEmpty(), color = MaterialTheme.colorScheme.error)
                    OutlinedButton(onClick = vm::load) { Text(stringResource(R.string.p15_try_again)) }
                }
                else -> ContactsList(state, vm)
            }
        }
    }
    if (confirmLargeImport) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmLargeImport = false },
            title = { Text(stringResource(R.string.contacts_large_import_title)) },
            text = { Text(stringResource(R.string.contacts_large_import_text, state.selected.size)) },
            confirmButton = { androidx.compose.material3.TextButton(onClick = { confirmLargeImport = false; vm.importSelected() }) { Text(stringResource(R.string.contacts_import_anyway)) } },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { confirmLargeImport = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}

@Composable
private fun PermissionPane(denied: Boolean, onAllow: () -> Unit, onSettings: () -> Unit, onRecheck: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.contacts_access), style = MaterialTheme.typography.titleMedium)
                Text(
                    stringResource(R.string.p18_contacts_import_bsrpro_reads_your_phone_s) +
                        stringResource(R.string.p18_contacts_import_encrypted_in_the_vault_as),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        if (denied) {
            Text(
                stringResource(R.string.p18_contacts_import_permission_was_denied_so_contacts) +
                    stringResource(R.string.p18_contacts_import_to_allow_access_open_the),
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium
            )
            Button(onClick = onSettings, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.contacts_open_settings)) }
            OutlinedButton(onClick = onRecheck, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.contacts_recheck)) }
        } else {
            Button(onClick = onAllow, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.contacts_allow)) }
        }
    }
}

@Composable
private fun ContactsList(state: ContactsUiState, vm: ContactsImportViewModel) {
    val visible = remember(state.items, state.query) { vm.visible(state) }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = state.query,
            onValueChange = vm::setQuery,
            placeholder = { Text(stringResource(R.string.contacts_search)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = vm::selectAll) { Text(stringResource(R.string.contacts_select_all)) }
            TextButton(onClick = vm::deselectAll) { Text(stringResource(R.string.contacts_deselect_all)) }
            Text(
                L.s(R.string.p18_contacts_import_contacts_already_saved, visible.size, state.items.count { it.duplicate }),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        HorizontalDivider()
        if (visible.isEmpty()) {
            Text(stringResource(R.string.contacts_none), modifier = Modifier.padding(24.dp))
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(visible, key = { it.id  }, contentType = { "item" }) { c ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.toggle(c.id) }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = c.id in state.selected, onCheckedChange = null)
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(c.name.ifBlank { c.primary }, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                c.phones.joinToString(" · ") + if (c.duplicate) stringResource(R.string.p18_contacts_import_already_saved) else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (c.duplicate) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
