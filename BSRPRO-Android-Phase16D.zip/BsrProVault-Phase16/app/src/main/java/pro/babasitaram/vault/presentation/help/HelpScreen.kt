@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.help

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import pro.babasitaram.vault.core.constants.AppLinks

data class HelpFaq(val question: String, val answer: String)

private val faqs = listOf(
    HelpFaq("How do I get started?", "Create a strong master password, unlock the vault, then add your first login using +."),
    HelpFaq("How do I add a password?", "Open Vault and tap +, choose the entry type (Password, Card, Identity...), fill the form and Save."),
    HelpFaq("How do I edit an entry?", "Tap an entry to open its details, then tap Edit. Long-pressing a list item also shows Edit."),
    HelpFaq("How does Autofill work?", "Enable BSRPRO Vault in Android Autofill settings. Android then offers saved credentials on supported forms."),
    HelpFaq("How do I copy a password?", "Use the copy button on an entry detail page or the entry context menu in Vault."),
    HelpFaq("How do I add TOTP?", "Open TOTP Manager, tap Add TOTP, then enter the service, username and Base32 secret (or paste an otpauth:// link)."),
    HelpFaq("How do I copy a TOTP code?", "Open TOTP Manager and tap the copy icon beside the live code."),
    HelpFaq("How do I make a secure note?", "Open Notes and tap New Note. Enter a title, content and category, then save."),
    HelpFaq("How does Bin work?", "Delete moves an entry to Bin instead of immediately removing it. Restore it anytime before the 30-day retention limit."),
    HelpFaq("How do I empty Bin?", "Open Bin and choose Empty Bin. Confirm the permanent deletion count before continuing."),
    HelpFaq("How do I back up the vault?", "Open Backup & Import and create an encrypted BSRPRO.Vault backup. Automatic backups also use that encrypted format."),
    HelpFaq("How do I import from another manager?", "Open Backup & Import, choose the source format, select the file and review duplicates before committing."),
    HelpFaq("What is Travel Mode?", "Travel Mode suppresses automatic Autofill suggestions while leaving manual access available."),
    HelpFaq("What does Health check?", "Vault Health checks weak passwords, reused passwords, duplicate logins, old passwords and missing usernames."),
    HelpFaq("What is Emergency Access?", "Emergency Access uses a 24-character recovery key and a mandatory 72-hour waiting period before recovery is allowed."),
    HelpFaq("How is my vault protected?", "The vault is encrypted locally. Your master password is not stored in plaintext, and sensitive clipboard values can be cleared automatically.")
)

@Composable
fun HelpScreen(onBack: () -> Unit = {}) {
    val context = LocalContext.current
    BackHandler { onBack() }
    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.p15_help), style = MaterialTheme.typography.titleLarge) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(Icons.Default.HelpOutline, null); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_126), style = MaterialTheme.typography.titleMedium); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_127)) } } }
            item { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_128), style = MaterialTheme.typography.titleLarge) }
            items(faqs, key = { it.question  }, contentType = { "item" }) { faq -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(faq.question, style = MaterialTheme.typography.titleMedium); Text(faq.answer) } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_129), style = MaterialTheme.typography.titleMedium); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_130)) } } }
            item { OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AppLinks.WEBSITE))) } }, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_131)) } }
            item { OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AppLinks.GITHUB_ISSUES))) } }, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_132)) } }
            item { OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${AppLinks.EMAIL}"))) } }, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_email_support, AppLinks.EMAIL)) } }
        }
    }
}
