package pro.babasitaram.vault.presentation.theme

import androidx.compose.ui.graphics.Color

val AccentPurple = Color(0xFFA78BFA)
// Light theme: white text on A78BFA sirf 2.7:1 tha (WCAG AA = 4.5:1). Ye shade 5.5:1 deta hai.
val AccentPurpleLight = Color(0xFF6D4AE8)
val AccentOrange = Color(0xFFF59E0B)
val DarkBackground = Color(0xFF14121F)
val DarkSurface = Color(0xFF1E1B2E)
val LightBackground = Color(0xFFFAF9FF)
val LightSurface = Color(0xFFFFFFFF)
