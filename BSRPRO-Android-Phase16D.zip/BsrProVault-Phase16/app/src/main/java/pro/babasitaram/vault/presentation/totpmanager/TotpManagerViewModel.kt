package pro.babasitaram.vault.presentation.totpmanager

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.receiveAsFlow
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.DeleteEntryUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions
import pro.babasitaram.vault.presentation.util.launchCatching
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L

@HiltViewModel
class TotpManagerViewModel @Inject constructor(
    repository: VaultRepository,
    private val deleteEntry: DeleteEntryUseCase,
    private val clipboard: ClipboardActions
) : ViewModel() {
    private val query = MutableStateFlow("")
    val queryState: StateFlow<String> = query.asStateFlow()
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    val entries: StateFlow<List<VaultEntry>> = combine(repository.entries, query) { values, queryText ->
        val q = queryText.trim()
        values.filter { it.deletedAt == 0L && it.totp.isNotBlank() }
            .filter {
                q.isBlank() || it.title.contains(q, true) || it.username.contains(q, true) || it.url.contains(q, true)
            }
    }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setQuery(value: String) { query.value = value }

    fun copyCode(code: String) {
        launchCatching { _messages.send(clipboard.copy(code, L.s(R.string.p18_common_totp_code))) }
    }

    fun delete(id: String) {
        launchCatching {
            when (val result = deleteEntry(id)) {
                is pro.babasitaram.vault.core.util.VaultResult.Success -> _messages.send(L.s(R.string.p20_moved_to_bin))
                is pro.babasitaram.vault.core.util.VaultResult.Failure -> _messages.send(result.error.message ?: L.s(R.string.p20_could_not_delete))
                pro.babasitaram.vault.core.util.VaultResult.Loading -> Unit
            }
        }
    }
}
