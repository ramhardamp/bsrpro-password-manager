package pro.babasitaram.vault.data.backup

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.nio.file.AtomicMoveNotSupportedException
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.crypto.V3PayloadParser
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.core.model.VaultPayload
import pro.babasitaram.vault.core.model.VaultJson
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.data.transfer.ExportFormat
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.BuildExportUseCase
import timber.log.Timber

/**
 * V3 backup to Downloads/BSRPRO_Backups/BSRPRO.Vault. Legacy dated backups are removed only after a new backup is safely written.
 *
 * A V3 file is encrypted with the master password, which only exists in memory while the vault is unlocked.
 * So the daily worker backs up when the vault is unlocked and otherwise does nothing; [runIfDue] is also
 * called whenever the vault is unlocked, so a missed day is caught up at the next unlock.
 */
@Singleton
class AutoBackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settings: SettingsRepository,
    private val session: SessionKeyStore,
    private val buildExport: BuildExportUseCase,
    private val repository: VaultRepository,
    private val activityLog: ActivityLogStore
) {
    internal var clock: () -> Long = { System.currentTimeMillis() }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var debounceJob: Job? = null
    private val pendingPrefs by lazy { context.getSharedPreferences(PENDING_PREFS, Context.MODE_PRIVATE) }

    /** Persist the request first, then coalesce rapid changes into one encrypted V3 write. */
    fun requestBackup() {
        // Persist first, so process death or a lock during the debounce cannot silently drop the request.
        pendingPrefs.edit().putBoolean(KEY_PENDING, true).apply()
        if (!session.isUnlocked.value) return
        debounceJob?.cancel()
        debounceJob = scope.launch {
            runCatching {
                delay(DEBOUNCE_MS)
                backupNow()
            }.onSuccess { result ->
                if (result is VaultResult.Success) {
                    pendingPrefs.edit().remove(KEY_PENDING).apply()
                } else {
                    Timber.w("backup remains pending for next unlock/retry")
                }
            }.onFailure { error ->
                Timber.w(error, "automatic backup attempt failed; request remains pending")
            }
        }
    }

    suspend fun runPendingOrDue(): Boolean {
        if (!session.isUnlocked.value) return false
        // Repair leftovers from an interrupted previous publish as soon as the vault is unlocked.
        // Cleanup is allowed only after the exact canonical file is independently validated.
        cleanupExistingVerifiedDuplicates()
        val pending = pendingPrefs.getBoolean(KEY_PENDING, false)
        val done = if (pending) backupNow() is VaultResult.Success else runIfDue()
        if (done) pendingPrefs.edit().remove(KEY_PENDING).apply()
        return done
    }

    /** On unlock, remove only BSRPRO-managed duplicates when the canonical backup is valid. */
    private suspend fun cleanupExistingVerifiedDuplicates() {
        if (!session.isUnlocked.value) return
        try {
            val selected = settings.current().backupFolderUri
            if (selected.isNotBlank()) {
                val tree = android.net.Uri.parse(selected)
                val exact = findSafExact(tree, FINAL_NAME) ?: return
                verifySafDocument(exact)
                withContext(Dispatchers.IO) { cleanupSafTree(tree) }
                pendingPrefs.edit().putString(KEY_LAST_SAF_URI, exact.toString()).apply()
                return
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val relative = "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/"
                val exact = findExactRow(context.contentResolver, MediaStore.Downloads.EXTERNAL_CONTENT_URI, relative, FINAL_NAME)
                    ?: return
                verifyMediaStoreRow(exact)
                withContext(Dispatchers.IO) { cleanupOldBackups() }
                return
            }
            val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), FOLDER)
            val exact = File(dir, FINAL_NAME)
            if (!exact.isFile || exact.length() == 0L) return
            val text = withContext(Dispatchers.IO) { exact.readText(Charsets.UTF_8).trim() }
            session.withPassword { password -> VaultCrypto.decryptV3(text, password) }
            withContext(Dispatchers.IO) { cleanupOldBackups() }
        } catch (e: SecurityException) {
            Timber.w("backup duplicate repair skipped: permission/provider rejected access")
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            // Never delete anything on an unverified canonical backup. The next unlock retries.
            Timber.w("backup duplicate repair skipped: %s", e.javaClass.simpleName)
        }
    }

    private fun findSafExact(treeUri: android.net.Uri, name: String): android.net.Uri? {
        val resolver = context.contentResolver
        val treeId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeId)
        resolver.query(children, arrayOf(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID, android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndexOrThrow(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            while (cursor.moveToNext()) {
                if (cursor.getString(nameCol).orEmpty().equals(name, true)) {
                    return android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, cursor.getString(idCol))
                }
            }
        }
        return null
    }

    fun hasPendingBackup(): Boolean = pendingPrefs.getBoolean(KEY_PENDING, false)

    /** Locate the current automatic backup. On Android 10+ MediaStore content is copied to a
     * private cache file because a content:// row cannot be represented as a filesystem File.
     * On Android 8-9, check the public Downloads folder first, then this app's legacy app-scoped
     * Downloads location. Permission/provider failures are treated as not found. */
    fun findBackupFile(): File? = BackupFileDiscovery.safelyFind {
        val selectedUri = pendingPrefs.getString(KEY_LAST_SAF_URI, null)?.let { android.net.Uri.parse(it) }
        if (selectedUri != null) {
            copyContentUriToCache(selectedUri)?.let { return@safelyFind it }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            findMediaStoreBackup()
        } else {
            val publicRoot = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val appRoot = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            val candidates = DISCOVERY_FOLDERS.flatMap { folder ->
                buildList {
                    addAll(BackupFileDiscovery.canonicalCandidates(File(publicRoot, folder), FINAL_NAME))
                    if (appRoot != null) addAll(BackupFileDiscovery.canonicalCandidates(File(appRoot, folder), FINAL_NAME))
                }
            }
            BackupFileDiscovery.firstExisting(candidates)?.let { copyToCache(it) }
        }
    }

    private fun copyContentUriToCache(source: android.net.Uri): File? {
        val destination = File(context.cacheDir, "discovered-${UUID.randomUUID()}.vault")
        return try {
            context.contentResolver.openInputStream(source)?.use { input ->
                destination.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            if (destination.length() <= 0L) { destination.delete(); null } else destination
        } catch (ce: CancellationException) { throw ce } catch (_: Exception) {
            destination.delete(); null
        }
    }

    private fun copyToCache(source: File): File? {
        if (!source.isFile || source.length() <= 0L) return null
        val destination = File(context.cacheDir, "discovered-${UUID.randomUUID()}.vault")
        return try {
            source.inputStream().use { input ->
                destination.outputStream().use { output -> input.copyTo(output) }
            }
            if (!destination.isFile || destination.length() == 0L) {
                destination.delete()
                null
            } else destination
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            destination.delete()
            throw e
        }
    }

    private fun findMediaStoreBackup(): File? {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        runBlockingRecovery()
        val uri = findMediaStoreBackupUriNewest(FOLDER)
            ?: findMediaStoreBackupUriNewest(EXTENSION_FOLDER)
            ?: return null
        val destination = File(context.cacheDir, "discovered-${UUID.randomUUID()}.vault")
        return try {
            resolver.openInputStream(uri)?.use { input ->
                destination.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            if (!destination.isFile || destination.length() == 0L) {
                destination.delete()
                return null
            }
            destination
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            destination.delete()
            throw e
        }
    }

    private fun runBlockingRecovery() {
        kotlinx.coroutines.runBlocking(Dispatchers.IO) { recoverQuarantinedBackup() }
    }

    private fun findMediaStoreBackupUriNewest(folder: String): android.net.Uri? {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val relative = "${Environment.DIRECTORY_DOWNLOADS}/$folder/"
        val rows = mutableListOf<Pair<String, android.net.Uri>>()
        resolver.query(
            collection,
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
            "${MediaStore.MediaColumns.RELATIVE_PATH}=?",
            arrayOf(relative),
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            while (c.moveToNext()) {
                val name = c.getString(nameCol).orEmpty()
                if (AutoBackupNames.isCanonicalFamily(name, FINAL_NAME)) {
                    rows += name to android.content.ContentUris.withAppendedId(
                        collection, c.getLong(idCol)
                    )
                }
            }
        }
        return rows.firstOrNull { it.first.equals(FINAL_NAME, ignoreCase = true) }?.second
            ?: rows.firstOrNull()?.second
    }

    private suspend fun recoverQuarantinedBackup() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val relative = "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/"
        var exactUri: android.net.Uri? = null
        val quarantine = mutableListOf<android.net.Uri>()
        resolver.query(
            collection,
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.IS_PENDING),
            "${MediaStore.MediaColumns.RELATIVE_PATH}=?",
            arrayOf(relative),
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameCol).orEmpty()
                val row = android.content.ContentUris.withAppendedId(collection, cursor.getLong(idCol))
                if (name.equals(FINAL_NAME, ignoreCase = true)) exactUri = row
                if (AutoBackupNames.isQuarantine(name)) quarantine += row
            }
        }
        if (exactUri != null || quarantine.isEmpty()) return

        // If a process died after quarantining the last known-good backup but before publishing
        // the staged row, recover a verified quarantine copy rather than leaving a second
        // recovery file behind. Never promote an unverified encrypted blob.
        for (row in quarantine) {
            val verified = runCatching { verifyMediaStoreRow(row); true }.getOrDefault(false)
            if (!verified) continue
            val published = runCatching {
                resolver.update(row, ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, FINAL_NAME)
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }, null, null) > 0
            }.getOrDefault(false)
            if (published) break
        }
    }

    fun schedule() {
        val req = PeriodicWorkRequestBuilder<AutoBackupWorker>(1, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiresStorageNotLow(true).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun cancel() {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }

    /** True once a calendar day has passed since the last successful backup. */
    suspend fun isDue(): Boolean {
        val s = settings.current()
        return s.autoBackupEnabled && dayKey(clock()) != dayKey(s.lastAutoBackupAt)
    }

    /** @return true if a backup file was written. */
    suspend fun runIfDue(): Boolean {
        if (!isDue() || !session.isUnlocked.value) return false
        val success = backupNow() is VaultResult.Success
        if (success) pendingPrefs.edit().remove(KEY_PENDING).apply()
        return success
    }

    suspend fun backupNow(): VaultResult<String> {
        if (!session.isUnlocked.value) return VaultResult.Failure(VaultError.VaultLocked)
        val text = when (val r = buildExport(ExportFormat.V3)) {
            is VaultResult.Success -> r.value
            is VaultResult.Failure -> return r
            VaultResult.Loading -> return VaultResult.Loading
        }
        return try {
            val where = withContext(Dispatchers.IO) { write(FINAL_NAME, text) }
            verifyPersistedBackup()
            withContext(Dispatchers.IO) { cleanupOldBackups() }
            settings.update { it.copy(lastAutoBackupAt = clock()) }
            activityLog.record("Backup created", "Automatic encrypted backup written and verified")
            Timber.i("auto-backup written and verified")
            VaultResult.Success(where)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Timber.w("auto-backup failed: %s", e.javaClass.simpleName)
            VaultResult.Failure(VaultError.IOError(e))
        }
    }

    private suspend fun write(name: String, text: String): String {
        val chosenTree = settings.current().backupFolderUri
        if (chosenTree.isNotBlank()) {
            try {
                return writeSafTree(android.net.Uri.parse(chosenTree), name, text)
            } catch (e: SecurityException) {
                Timber.w("selected backup folder permission revoked; clearing stale grant and using app backup destination")
                settings.update { it.copy(backupFolderUri = "") }
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val relative = "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/"
            // Never truncate the last known-good backup in place. Some MediaStore providers can
            // partially write or fail after "wt" has already destroyed the old bytes. Write and
            // validate a pending row first, then use the quarantine/publish transaction below.
            val stagedName = ".BSRPRO-${UUID.randomUUID()}.pending"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, stagedName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                put(MediaStore.MediaColumns.RELATIVE_PATH, relative)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val staged = resolver.insert(collection, values) ?: throw java.io.IOException("MediaStore insert failed")
            try {
                resolver.openOutputStream(staged, "w")?.use { output ->
                    output.write(text.toByteArray(Charsets.UTF_8))
                    output.flush()
                } ?: throw java.io.IOException("open failed")

                // Verify the pending row before touching the existing canonical backup. This
                // prevents a failed write from destroying the previous valid backup.
                verifyMediaStoreRow(staged)

                // Move all app-managed prior backup names out of the visible canonical family
                // only after the new staged bytes have passed V3 decryption. Keep their row IDs
                // available for rollback until the new row is published.
                val quarantined = quarantineExistingCanonicalRows(resolver, collection, relative, name)
                try {
                    val published = resolver.update(staged, ContentValues().apply {
                        put(MediaStore.MediaColumns.IS_PENDING, 0)
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    }, null, null)
                    if (published <= 0) throw java.io.IOException("backup publish failed")
                } catch (e: Exception) {
                    restoreQuarantinedRows(resolver, quarantined)
                    throw e
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                runCatching { resolver.delete(staged, null, null) }
                throw ce
            } catch (e: Exception) {
                runCatching { resolver.delete(staged, null, null) }
                throw e
            }
            return "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/$name"
        }
        // Android 8/9: use app-scoped external Downloads; no broad storage permission is requested.
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), FOLDER).apply { mkdirs() }
        val target = File(dir, name)
        val temp = File(dir, ".$name.pending")
        FileOutputStream(temp).use { out ->
            out.write(text.toByteArray(Charsets.UTF_8))
            out.fd.sync()
        }
        try {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
        return target.absolutePath
    }


    /** Transactional SAF publish: write/validate a sibling staging document before renaming the old canonical file. */
    private suspend fun writeSafTree(treeUri: android.net.Uri, name: String, text: String): String {
        val resolver = context.contentResolver
        val treeId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
        val parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, treeId)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeId)
        val docs = mutableListOf<Pair<String, android.net.Uri>>()
        resolver.query(children, arrayOf(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = c.getColumnIndexOrThrow(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            while (c.moveToNext()) {
                val display = c.getString(nameCol).orEmpty()
                val id = c.getString(idCol)
                docs += display to android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
            }
        } ?: throw java.io.IOException("Cannot list selected backup folder")

        val stagingName = ".BSRPRO-${UUID.randomUUID()}.pending"
        val staged = android.provider.DocumentsContract.createDocument(resolver, parent,
            "application/octet-stream", stagingName) ?: throw java.io.IOException("Cannot create staging backup")
        var oldUri: android.net.Uri? = null
        var oldName: String? = null
        var oldRenamed = false
        try {
            resolver.openOutputStream(staged, "w")?.use { out ->
                out.write(text.toByteArray(Charsets.UTF_8)); out.flush()
            } ?: throw java.io.IOException("Cannot write staging backup")
            verifySafDocument(staged)

            val old = docs.firstOrNull { it.first.equals(name, true) }
            if (old != null) {
                oldUri = old.second
                oldName = old.first
                val safeOldName = "BSRPRO-Recovery-${clock()}-${UUID.randomUUID().toString().take(8)}.Vault"
                val renamed = android.provider.DocumentsContract.renameDocument(resolver, old.second, safeOldName)
                    ?: throw java.io.IOException("Provider cannot safely preserve existing backup")
                oldUri = renamed
                oldRenamed = true
            }
            val published = android.provider.DocumentsContract.renameDocument(resolver, staged, name)
                ?: throw java.io.IOException("Provider cannot publish backup name")
            pendingPrefs.edit().putString(KEY_LAST_SAF_URI, published.toString()).apply()
            return published.toString()
        } catch (ce: CancellationException) {
            if (oldRenamed && oldUri != null && oldName != null) {
                runCatching { android.provider.DocumentsContract.renameDocument(resolver, oldUri!!, oldName!!) }
            }
            runCatching { resolver.delete(staged, null, null) }
            throw ce
        } catch (e: Exception) {
            if (oldRenamed && oldUri != null && oldName != null) {
                runCatching { android.provider.DocumentsContract.renameDocument(resolver, oldUri!!, oldName!!) }
            }
            runCatching { resolver.delete(staged, null, null) }
            throw e
        }
    }

    private suspend fun verifySafDocument(uri: android.net.Uri) {
        val text = context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8).trim() }
            ?: throw java.io.IOException("Cannot read staged SAF backup")
        if (text.isBlank()) throw java.io.IOException("Staged SAF backup is empty")
        session.withPassword { password -> VaultCrypto.decryptV3(text, password) }
    }

    /** Finds the app-visible row named exactly [name] in [relative]; newest first. */
    private fun findExactRow(
        resolver: android.content.ContentResolver,
        collection: android.net.Uri,
        relative: String,
        name: String
    ): android.net.Uri? {
        resolver.query(
            collection,
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
            "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.IS_PENDING}=0",
            arrayOf(relative),
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            while (c.moveToNext()) {
                if (c.getString(nameCol).orEmpty().equals(name, ignoreCase = true)) {
                    return android.content.ContentUris.withAppendedId(collection, c.getLong(idCol))
                }
            }
        }
        return null
    }

    private suspend fun verifyMediaStoreRow(uri: android.net.Uri) {
        val resolver = context.contentResolver
        val persisted = resolver.openInputStream(uri)?.use { input ->
            input.readBytes().toString(Charsets.UTF_8).trim()
        } ?: throw java.io.IOException("Backup staging read failed")
        if (persisted.isEmpty()) throw java.io.IOException("Backup staging file is empty")
        // We only need to prove that the staged bytes are a valid V3 container here.
        // Full payload equality is performed again after publication by verifyPersistedBackup().
        session.withPassword { password ->
            VaultCrypto.decryptV3(persisted, password)
        }
    }

    private data class QuarantinedRow(
        val uri: android.net.Uri,
        val originalName: String
    )

    private fun quarantineExistingCanonicalRows(
        resolver: android.content.ContentResolver,
        collection: android.net.Uri,
        relativePath: String,
        finalName: String
    ): List<QuarantinedRow> {
        val rows = mutableListOf<QuarantinedRow>()
        resolver.query(
            collection,
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
            "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.IS_PENDING}=0",
            arrayOf(relativePath),
            null
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val displayName = cursor.getString(nameCol).orEmpty()
                if (AutoBackupNames.isCanonicalFamily(displayName, finalName)) {
                    rows += QuarantinedRow(
                        android.content.ContentUris.withAppendedId(collection, cursor.getLong(idCol)),
                        displayName
                    )
                }
            }
        }

        val changed = mutableListOf<QuarantinedRow>()
        try {
            rows.forEachIndexed { index, row ->
                val quarantineName = ".bsrpro-old-${UUID.randomUUID()}-$index.vault"
                val updated = resolver.update(
                    row.uri,
                    ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, quarantineName) },
                    null,
                    null
                )
                if (updated <= 0) throw java.io.IOException("could not quarantine existing backup")
                changed += row
            }
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            restoreQuarantinedRows(resolver, changed)
            throw e
        }
        return changed
    }

    private fun restoreQuarantinedRows(
        resolver: android.content.ContentResolver,
        rows: List<QuarantinedRow>
    ) {
        rows.forEach { row ->
            runCatching {
                resolver.update(
                    row.uri,
                    ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, row.originalName) },
                    null,
                    null
                )
            }
        }
    }

    /** Read the newly published backup, decrypt it with the active session password and compare the canonical payload. */
    private suspend fun verifyPersistedBackup() {
        val file = findBackupFile() ?: throw java.io.IOException("Backup read-back file not found")
        try {
            val persisted = withContext(Dispatchers.IO) { file.readText(Charsets.UTF_8).trim() }
            if (persisted.isEmpty()) throw java.io.IOException("Backup read-back file is empty")
            val plaintext = session.withPassword { password -> VaultCrypto.decryptV3(persisted, password) }
            val actual = V3PayloadParser.parse(plaintext)
            val expected = canonical(VaultData(repository.entries.value, repository.folders.value))
            val actualCanonical = VaultJson.encodeToString(
                VaultPayload.serializer(), VaultPayload(entries = actual.entries, folders = actual.folders)
            )
            val expectedDigest = MessageDigest.getInstance("SHA-256").digest(expected.toByteArray(Charsets.UTF_8))
            val actualDigest = MessageDigest.getInstance("SHA-256").digest(actualCanonical.toByteArray(Charsets.UTF_8))
            if (!MessageDigest.isEqual(expectedDigest, actualDigest)) {
                throw java.io.IOException("Backup read-back payload mismatch")
            }
        } finally {
            file.delete()
        }
    }

    private fun canonical(data: VaultData): String {
        val folderIds = data.folders.map { it.id }.toSet()
        val validPackage = Regex("^[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+$")
        val entries = data.entries.map { e ->
            e.copy(
                folderId = if (e.folderId.isNotBlank() && e.folderId !in folderIds) "" else e.folderId,
                appPackage = if (e.appPackage.isNotBlank() && !validPackage.matches(e.appPackage.trim())) "" else e.appPackage
            )
        }
        return VaultJson.encodeToString(
            VaultPayload.serializer(), VaultPayload(entries = entries, folders = data.folders)
        )
    }

    /** Remove only BSRPRO-managed duplicate/recovery files, never unrelated user files.
     * This runs only after the newly published BSRPRO.Vault has been read back, decrypted, and
     * compared byte-for-byte at the canonical payload level. If cleanup cannot prove that only one
     * managed backup remains, the operation fails instead of silently claiming success. */
    private fun cleanupOldBackups() {
        val selectedTree = settings.current().backupFolderUri
        if (selectedTree.isNotBlank()) {
            cleanupSafTree(android.net.Uri.parse(selectedTree))
            Timber.i("verified SAF backup duplicate cleanup completed; canonical filename retained")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val relative = "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/"
            val remove = mutableListOf<android.net.Uri>()
            resolver.query(collection,
                arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
                "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.IS_PENDING}=0",
                arrayOf(relative), null)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val name = cursor.getString(nameCol).orEmpty()
                    if (AutoBackupNames.isQuarantine(name) ||
                        (AutoBackupNames.isCanonicalFamily(name, FINAL_NAME) && !name.equals(FINAL_NAME, true))) {
                        remove += android.content.ContentUris.withAppendedId(collection, cursor.getLong(idCol))
                    }
                }
            } ?: throw java.io.IOException("Cannot enumerate managed backup files for duplicate cleanup")
            remove.forEach { uri ->
                if (resolver.delete(uri, null, null) <= 0) {
                    throw java.io.IOException("Could not remove an older BSRPRO backup copy")
                }
            }
            return
        }

        // Android 8/9 writes to an app-scoped external directory. Remove only BSRPRO-managed
        // duplicate/recovery names there; never scan or mutate unrelated public storage.
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), FOLDER)
        dir.listFiles()?.forEach { file ->
            if (!file.isFile || file.name.equals(FINAL_NAME, true)) return@forEach
            if (AutoBackupNames.isManagedOldName(file.name, FINAL_NAME)) {
                if (!file.delete() && file.exists()) {
                    throw java.io.IOException("Could not remove an older BSRPRO backup copy")
                }
            }
        }
    }

    /** Remove BSRPRO-owned old canonical/recovery documents from a user-selected SAF tree. */
    private fun cleanupSafTree(treeUri: android.net.Uri) {
        val resolver = context.contentResolver
        val treeId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeId)
        val remove = mutableListOf<android.net.Uri>()
        resolver.query(children,
            arrayOf(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndexOrThrow(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameCol).orEmpty()
                if (!name.equals(FINAL_NAME, true) && AutoBackupNames.isManagedOldName(name, FINAL_NAME)) {
                    remove += android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, cursor.getString(idCol))
                }
            }
        } ?: throw java.io.IOException("Cannot enumerate selected backup folder for duplicate cleanup")

        remove.forEach { uri ->
            if (resolver.delete(uri, null, null) <= 0 && documentStillExists(resolver, uri)) {
                throw java.io.IOException("Could not remove an older BSRPRO backup copy from selected folder")
            }
        }

        val remaining = mutableListOf<String>()
        resolver.query(children, arrayOf(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null)?.use { cursor ->
            val nameCol = cursor.getColumnIndexOrThrow(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameCol).orEmpty()
                if (AutoBackupNames.isManagedOldName(name, FINAL_NAME)) remaining += name
            }
        } ?: throw java.io.IOException("Cannot verify selected backup folder after duplicate cleanup")
        if (remaining.isNotEmpty()) {
            throw java.io.IOException("BSRPRO backup cleanup incomplete: ${remaining.joinToString(", ")}")
        }
    }

    private fun documentStillExists(resolver: android.content.ContentResolver, uri: android.net.Uri): Boolean =
        runCatching {
            resolver.query(uri, arrayOf(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null)?.use { it.moveToFirst() } ?: false
        }.getOrDefault(false)

    private fun dayKey(ms: Long): String = if (ms <= 0) "" else SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ms))

    companion object {
        const val WORK_NAME = "bsrpro_auto_backup"
        const val FOLDER = "BSRPRO_Backups"
        const val EXTENSION_FOLDER = "BSRPRO Vault Password_Backups"
        const val FINAL_NAME = "BSRPRO.Vault"
        private val DISCOVERY_FOLDERS = listOf(FOLDER, EXTENSION_FOLDER)
        const val DEBOUNCE_MS = 2_500L
        private const val PENDING_PREFS = "bsrpro_backup_state"
        private const val KEY_PENDING = "pending_backup_v1"
        private const val KEY_LAST_SAF_URI = "last_saf_backup_uri_v1"
    }
}

/** Naming/migration rules kept pure so legacy cleanup is unit-testable. */
internal object BackupFileDiscovery {
    fun firstExisting(candidates: List<File>): File? = candidates.firstOrNull { it.isFile && it.name == AutoBackupManager.FINAL_NAME }

    fun canonicalCandidates(dir: File, finalName: String): List<File> {
        if (!dir.isDirectory) return emptyList()
        return dir.listFiles()
            ?.filter { it.isFile && AutoBackupNames.isCanonicalFamily(it.name, finalName) }
            ?.sortedWith(compareByDescending<File> { it.name.equals(finalName, ignoreCase = true) }.thenByDescending { it.lastModified() })
            ?: emptyList()
    }

    fun safelyFind(block: () -> File?): File? = try { block() } catch (_: SecurityException) { null } catch (_: java.io.IOException) { null }
}

internal object AutoBackupNames {
    private val legacy = Regex("vault_[0-9]{8}\\.Vault", RegexOption.IGNORE_CASE)
    fun isLegacyDated(name: String): Boolean = legacy.matches(name)
    fun isNumberedDuplicate(name: String, finalName: String): Boolean {
        val base = Regex.escape(finalName.substringBeforeLast('.'))
        val ext = Regex.escape(finalName.substringAfterLast('.', ""))
        return Regex("^$base \\(\\d+\\)\\.$ext$", RegexOption.IGNORE_CASE).matches(name)
    }
    fun isQuarantine(name: String): Boolean = name.startsWith(".bsrpro-old-", ignoreCase = true) && name.endsWith(".vault", ignoreCase = true)
    fun isSafRecovery(name: String): Boolean = name.startsWith("BSRPRO-Recovery-", ignoreCase = true) && name.endsWith(".Vault", ignoreCase = true)
    fun isStaging(name: String): Boolean = name.startsWith(".BSRPRO-", ignoreCase = true) && name.endsWith(".pending", ignoreCase = true)
    fun isCanonicalFamily(name: String, finalName: String): Boolean =
        name.equals(finalName, ignoreCase = true) ||
            isNumberedDuplicate(name, finalName) ||
            isLegacyDated(name)
    fun isManagedOldName(name: String, finalName: String): Boolean =
        isQuarantine(name) || isSafRecovery(name) || isStaging(name) || isCanonicalFamily(name, finalName)
}

@EntryPoint
@InstallIn(SingletonComponent::class)
interface AutoBackupEntryPoint {
    fun autoBackupManager(): AutoBackupManager
}

class AutoBackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val manager = EntryPointAccessors.fromApplication(applicationContext, AutoBackupEntryPoint::class.java).autoBackupManager()
        manager.runIfDue()          // no-op while the vault is locked; caught up at the next unlock
        return Result.success()
    }
}
