@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.setup

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Card
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.ui.Alignment
import androidx.activity.result.contract.ActivityResultContracts.CreateDocument
import pro.babasitaram.vault.presentation.settings.RecoveryKeyPdf
import pro.babasitaram.vault.presentation.settings.printRecoveryKey
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.presentation.components.PasswordField
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*

@Composable
fun SetupScreen(vm: SetupViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var backupPassword by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current
    val recoveryPdf = rememberLauncherForActivityResult(CreateDocument("application/pdf")) { uri ->
        val key = state.recoveryKey
        if (uri != null && key != null) {
            runCatching { RecoveryKeyPdf.write(context, uri, key) }
                .onFailure {
                    android.widget.Toast.makeText(context, stringResource(pro.babasitaram.vault.R.string.p17_recovery_save_failed), android.widget.Toast.LENGTH_LONG).show()
                }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.onBackupPicked(uri)
    }

    Scaffold { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(pro.babasitaram.vault.R.drawable.brand_logo),
                contentDescription = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_brand_accessibility),
                modifier = Modifier.size(80.dp)
            )
            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_148), style = MaterialTheme.typography.headlineMedium)
            Text(
                "Your master password encrypts everything on this device. A 24-character recovery key is created automatically; store it safely so you can reset the password if you forget it.",
                style = MaterialTheme.typography.bodyMedium
            )
            PasswordField(password, { password = it }, "Master password", showStrength = true, enabled = !state.busy)
            PasswordField(confirm, { confirm = it }, "Confirm master password", enabled = !state.busy)
            Text(
                "Minimum ${PasswordStrength.MIN_MASTER_LENGTH} characters, with upper & lower case plus digits or symbols.",
                style = MaterialTheme.typography.labelSmall
            )
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = { vm.create(password, confirm) },
                enabled = !state.busy && password.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (state.busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_149))
            }
            OutlinedButton(
                onClick = { picker.launch(arrayOf("*/*")) },
                enabled = !state.busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_150)) }
        }
    }

    state.recoveryKey?.let { key ->
        AlertDialog(
            onDismissRequest = { vm.dismissRecoveryKey() },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_151), style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_152))
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                key.chunked(4).joinToString(" "),
                                modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.titleMedium
                            )
                            IconButton(
                                onClick = {
                                    vm.copySecret(key, "Recovery key")
                                }
                            ) { Icon(Icons.Default.ContentCopy, "Copy recovery key") }
                        }
                    }
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_153), color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton(onClick = { recoveryPdf.launch(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_018)) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_019)) }
            },
            dismissButton = {
                TextButton(onClick = { printRecoveryKey(context, key) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_020)) }
            }
        )
    }

    if (state.awaitingBackupPassword) {
        AlertDialog(
            onDismissRequest = { vm.cancelRestore(); backupPassword = "" },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_154), style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_155))
                    PasswordField(backupPassword, { backupPassword = it }, "Backup password")
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { vm.restore(backupPassword); backupPassword = "" },
                    enabled = backupPassword.isNotEmpty() && !state.busy
                ) { Text(stringResource(R.string.p15_restore)) }
            },
            dismissButton = { TextButton(onClick = { vm.cancelRestore(); backupPassword = "" }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}
