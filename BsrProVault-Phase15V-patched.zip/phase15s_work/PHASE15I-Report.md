# Phase 15I patch — STATIC VERIFICATION ONLY (not compiled)

Input: bsrpro-vault-1_0_0-phase15h-patched.zip

## Build-blockers (re-checked on this tree)
- TotpCard.kt: not present, no references anywhere.
- `import pro.babasitaram.vault.R`: 0 files use R.* without it.
- AutofillAuthActivity.kt (line ~263): no stray backslash; only valid \u escapes remain.
- strings.xml (values + values-b+hi): 0 duplicate keys; 0 undefined R.string references.

## Fixes applied
- #13: `catch (ce: kotlinx.coroutines.CancellationException) { throw ce }` added before 28 broad catch sites (suspend/coroutine paths).
- #8: SharingScreen "Link protection" card now states that a sent link cannot be recalled and revoke only updates this device.
- #5: CI smoke test moved to tools/ci_smoke.sh (Status: ok check, resumed-activity check, crash scan); logs uploaded with `if: always()`.

## Not applied
- #7: see chat. Applying setUserAuthenticationRequired(true) to the shared wrap key would break lockout/PIN stores and the biometric load path.
