# Phase 14 — Round 1 Report (static review; not compiled)

Status: DIRTY (bugs found and fixed). Clean-audit counter: 0 of 3.

| # | File | Category | Severity | Fix |
|---|------|----------|----------|-----|
| 1 | SetupScreen, SettingsScreen, BackupScreen, SharingScreen | Security | High | Secrets copied via ClipboardActions (sensitive flag + auto-clear) through new `copySecret()` in 4 ViewModels |
| 2 | SecureShareActivity | Security | High | ScreenshotGuard.enable in onCreate |
| 3 | SetupScreen | UI/UX | Medium | Toast on recovery-PDF save failure |
| 4 | VaultCrypto.verifyMaster | Runtime | Low | Empty password returns false |
| 5 | 42 files | Dead code | Low | Unused imports removed |
| 6 | AndroidManifest.xml.tmp | Dead code | Low | Deleted |
| 7 | AndroidManifest.xml | Android | Low | INTERNET comment corrected (INTERNET is declared) |

Open: brace-count mismatch in 4 files (same as original; verify by compiling), verifyMaster has no callers.
Not yet audited: TOTP window, import/export field loss, restore journal, auto-lock, navigation, state screens, main-thread I/O.

## Round 2 — fixes from the first real CI build (kspDebugKotlin parse errors)

| # | File | Category | Severity | Fix |
|---|------|----------|----------|-----|
| 8 | SettingsScreen.kt:407 | Compile | Critical | Leaked placeholder `$marker(` replaced by `@Composable private fun ChangePasswordDialog(` (matches call site) |
| 9 | AutoBackupManager.kt:466 | Compile | Critical | Missing `)` in `if (... && (A || B)) {` condition |
| 10 | AutoBackupManager.kt | Dead code | Low | Removed unused outer `relative` that was shadowed inside the loop |
| 11 | SharingScreen.kt | Dead code | Low | Removed ClipData/ClipboardManager imports left unused by Round 1 |

Note: #8 and #9 existed in the Phase 13 upload. The Round 1 brace-count check had flagged AutoBackupManager.kt, and it was wrongly written off as a likely false positive. A string-aware bracket checker now reports 0 errors across all 180 Kotlin files (the other 3 flagged files were string-literal false positives).
Clean-audit counter: still 0 of 3.

## Round 3 — fixes from the first full compile (compileDebugKotlin)

All of these existed in Phase 13; the code had never been compiled before.

| File | Error | Fix |
|------|-------|-----|
| MainActivity.kt | `Density.copy` does not exist | `Density(density, fontScale * x)` + import |
| NoteEditorScreen, VaultHealthScreen | `Row` not imported | import added |
| SetupScreen | `material3.Row`, `foundation.layout.Alignment` wrong imports | `foundation.layout.Row`, `ui.Alignment` |
| TotpManagerScreen | `Box` not imported | import added |
| TotpManagerViewModel | `receiveAsFlow` not imported | import added |
| VaultListScreen | `ListRow` inferred as `Item` only | explicit `<ListRow>` type args |
| VaultListViewModel | `combine` with 7 and 10 flows (max typed overload is 5) | inputs grouped into `Controls` + 5-flow combines |
| VaultListViewModel | `when` on `softDelete()` (returns Unit, not VaultResult) | try/catch VaultError |

Static review only; the next CI build is the verification.
