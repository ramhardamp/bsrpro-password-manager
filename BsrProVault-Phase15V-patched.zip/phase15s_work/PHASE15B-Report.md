# Phase 15B — v1.0.0 (code 26) — STATIC VERIFICATION ONLY

Not compiled (no Gradle/Android SDK in the sandbox). Checks run (tools/static_audit.py, tools/bracket_check.py):
bracket balance on all .kt (0 issues), duplicate imports (0), duplicate top-level types (0), XML well-formed,
unresolved capitalised identifiers (only pre-existing false positives: generics, wildcard-imported Compose names, strings),
Compose symbol/Icons/getValue/setValue imports (only pre-existing false positives from fully-qualified use),
and manual signature checks of every API the new code calls. **Real proof = your GitHub Actions build.**

## Step 1 — Import / Export (Bug 10)
- Merge / Replace chips in Review (Replace moves current entries to the Bin first — recoverable 30 days).
- Duplicates: Skip / Overwrite / Keep both per item, "Skip all / Overwrite all / Keep both" and an "Apply my choice to all" checkbox.
- Confirm dialog: "N entries found: X new, Y duplicates. Import?" + review list.
- Field-mapping screen (CSV with no password column, or the "Import CSV with column mapping" button): auto-detect, manual dropdowns,
  masked sample values, remembered template per header layout.
- Export options dialog: Cards / Notes / Identities / Mobiles / TOTP / Attachments checkboxes; .Vault / CSV / JSON; encrypt choice for CSV
  (.csv.Vault, re-importable); plain-text warning. Progress dialog "Exporting X of Y entries…" with Cancel.
## Step 2 — Contacts (Bug 9)
READ_CONTACTS in manifest; runtime request; denied → explanation + "Open app settings" + re-check; ContactsContract read on IO;
search, multi-select, Select all / Deselect all; duplicates (same last-10 digits) marked and skipped; selected become Mobile entries.
Entry points: Backup & import, Mobiles screen, Settings → Backup. ("Import from Google" = Google contacts synced to the phone appear in the same list; there is no separate Google sign-in.)
## Step 3 — Settings / performance (Bug 12)
Settings hub: 7 categories (Security, Autofill, Backup & Import, Interface, Password Generator, Advanced, About), each clickable, with search.
New settings: Save prompts, generator character sets, show category chips, auto-backup toggle / last backup / back up now, Reset to defaults.
Perf: Room indices (url, username, category, record_type, app_package), drawer counts computed on Dispatchers.Default, vault list is keyed LazyColumn,
app icons already LruCache + 96px. **No profiler run — launch time / fps / recomposition counts are NOT measured.**
## Step 4 — Mobile editor: Name, Number, Operator dropdown (Jio/Airtel/Vi/BSNL/Other, stored as custom field "operator"), Category, Tags, Starred, Notes.
## Step 5 — Bottom nav: 5 tabs (Vault, Generator, TOTP, Health, Settings).
## Step 6 — Drawer badges: Vault, TOTP, Health (issues), Notes, Files, Mobiles, Bin; hidden when 0. Sharing / Emergency have no counted store, so no badge.

## Phase 15C — the items previously left undone (now implemented)
- **Failed-attempts lockout (configurable):** Security → "Failed attempts before lockout" (3/5/10) and "Lockout duration" (30 s / 1 / 5 / 15 min). RateLimiter reads the policy live; defaults unchanged (5 / 30 s) so existing tests still hold.
- **Hidden Vault + PIN:** entries tagged `hidden-vault` (existing V3 tags field, so backup format unchanged). Editor switch "Hide in Hidden Vault"; hidden entries leave the Vault list and drawer count; drawer → Hidden Vault asks for its own 4–6 digit PIN (separate from the sharing PIN, encrypted store), 5 wrong tries → 30 s wait, change/remove PIN (removal blocked while entries are hidden), Unhide button. Hidden entries still autofill and are still in backups (documented in the screen).
- **Language English / हिन्दी:** Settings → Interface → Language (System / English / हिन्दी), applied immediately via attachBaseContext (no new dependency). Fully translated: bottom nav, drawer, Settings hub (categories + subtitles + search box), New-entry chooser. **Other screens are still English** — their text is hard-coded in ~100 composables and was not externalised.
- **Splash with progress:** in-app startup screen (app name + progress bar + status text) replaces the bare spinner. No artificial delay.
- **Sharing + Emergency badges:** Sharing now records created links locally (title + expiry only, no secret) and shows "Active shares" with Remove; badge = active links. Emergency badge = 1 when a request is pending/active. Note: a link already sent cannot be recalled (stateless encrypted link) — Remove only clears the list; this is stated in the UI.
- **Lists:** keyed LazyColumn rows with contentType in the Vault list; keyed filter chips and review rows.
- Tests added: hidden-vault tag helpers, RateLimiter policy.

## Still not done / not verifiable
- No Gradle/SDK here: nothing was compiled or run. Launch time, 60 fps, recomposition counts and Room query timings were NOT measured.
- Remaining English-only screens (see Language above).
- "Import from Google" has no separate sign-in; Google contacts synced to the phone appear in "Import from Contacts".
