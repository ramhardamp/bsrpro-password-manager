# 0.2.10 / Code 12

1. Persist encrypted pre-restore blob snapshot and phase journal under app-private files.
2. During password unlock, recover pending transaction before normal vault data is exposed.
3. Authenticate/parse snapshot before replacing current blob; verify read-back; preserve evidence if recovery fails.

Next scope 0.2.11: folder picker/auto-detection, import progress and counts, four forced-interruption boundary tests, Autofill regression checks, backup cleanup/device verification.
