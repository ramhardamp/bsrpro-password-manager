# BSRPRO Vault 0.2.10 / Code 12 — scoped source delivery

Scope in this package: durable restore snapshot/journal persistence and startup recovery invocation before normal vault reads during password unlock.

Recovery behavior: snapshot is authenticated and parsed with the supplied current master password before replacing the current blob; after replacement, read-back payload is compared to the snapshot payload. Journal evidence is retained on validation or recovery failure.

Not included in this scope: folder picker, import progress redesign, four process-kill boundary instrumentation/tests, full APK/device verification. V3 container serialization and crypto constants are not intentionally changed.

Validation performed in packaging environment: source edits and ZIP integrity only. Android Gradle compilation, JUnit execution, APK verification, and device testing were not run. Test on a disposable vault before any production restore.
