# BSRPRO Vault — Feature Audit (0.2.12 / code 14)

**How this audit was made:** static review of the 0.2.11 source you sent + your device reports. I did **not** run the app.
Status words used below:

| Status | Meaning |
|---|---|
| ✅ Device-verified | You tested it on the phone and said it works |
| 🟢 Code + tests | Implemented and unit-tested, **not yet confirmed on device** |
| 🟡 Partial | Works for some cases only (see note) |
| 🔴 Missing | Not implemented |
| ⚙️ Backend-only | Stored / round-tripped but no screen uses it |

---

## 0. What was wrong (root causes found in 0.2.11)

| # | Symptom | Cause in code | Fix in 0.2.12 |
|---|---|---|---|
| 1 | "Save does nothing" after choosing an app | `EntryEditorViewModel.save()` rejected an empty title with *"Title is required"*. The app picker only set `appName`/`appPackage`, never the title. The error text was drawn at the very **bottom** of a long scrolling form, so it was invisible. The Save button itself was never disabled. | Title is now derived (typed → app name → website → card holder / full name). Error banner is at the **top** and the form scrolls there. |
| 2 | "App name goes into URL field, title empty" | In the 0.2.11 source the picker writes only `appName` + `appPackage` (`onSelected` → `vm.update { copy(appName, appPackage) }`); it does not write `url`. The empty **title** is the real problem. If your screenshot shows the name inside the *Website URL* box, send it — that would be a different code path I could not find. | `withPickedApp()` sets appName, appPackage and (if empty) title; **url is never touched**. |
| 3 | Unlock popup appears, nothing is filled | The locked state used *response-level* authentication. After unlock the framework only **re-shows a suggestion list**; if the list is empty (no matching entry) or the dropdown is not re-opened, nothing is filled. When no entry matched, `deliver()` silently cancelled. | Locked state now uses **dataset-level authentication**: the activity returns one real `Dataset` and Android fills immediately. With several matches a chooser is shown; with none, a message explains why. Every step is logged. |

---

## 1. Entry Editor — field mapping

`Entry` = `VaultEntry` (JSON key in the V3 payload is the same as the property name).

| Field | Editor shown for | Required? | Saved to | Autofill uses it? | Status |
|---|---|---|---|---|---|
| Title | all | **No** (since 0.2.12) — derived if empty; entry rejected only if nothing can be derived | `title` | Dropdown label | 🟢 |
| Website URL | login | No (leave empty for native apps) | `url` | Web matching (domain) | ✅ |
| Username | login | No | `username` | USERNAME field | ✅ |
| Password | login | No | `password` | PASSWORD field | ✅ |
| App PIN (4–6 digits) | login | No; if set must be 4–6 digits | `appPin` | PIN field (numeric-password / "pin" fields) | 🟢 |
| Mobile | login | No | `mobile` | USERNAME fallback when username **and** email are empty | 🟢 |
| TOTP key | login, card, identity (not note) | No; if set must be Base32 or `otpauth://` | `totp` | OTP field (next code if < 3 s left) | 🟢 |
| Android app (name + package) | login, card, identity | No | `appName`, `appPackage` | **Native-app matching** (exact package) | 🟢 |
| Notes | all | No | `notes` | — | ✅ |
| Category | all | No (default *other*) | `category` | — | ✅ |
| Folder | all (only if folders exist) | No | `folderId` | — | ✅ |
| Tags | all | No (comma separated) | `tags` | — | ✅ |
| Custom fields | all | No; rows with empty name are dropped | `customFields` | — | ✅ |
| Cardholder / number / expiry / CVV | card | No | `cardholder`, `cardNumber`, `cardExpiry`, `cardCvv` | **No** (no card autofill) | ✅ editor · 🔴 autofill |
| Full name / email / phone / address / ID number / ID expiry | identity | No | `fullName`, `email`, `phone`, `address`, `idNumber`, `idExpiry` | `email` is the 2nd USERNAME fallback; the rest **no** | ✅ editor · 🟡 autofill |
| `isNote`, `recordType` | record-type chips | — | set from chip | Notes are skipped by autofill | ✅ |
| `isPrimaryAppLogin`, `categoryLocked`, `type`, `folder` (legacy) | no UI | — | kept unchanged when editing | `isPrimaryAppLogin` unused | ⚙️ |
| `lastUsedAt` | no UI | — | **never updated** | used only to sort suggestions (always 0 for new entries) | ⚙️ gap |
| `passwordHistory`, `editHistory` | detail screen | automatic on save | `passwordHistory` (max 20), `editHistory` (max 50) | — | ✅ |

Validation order in `save()`: effective title → PIN length → TOTP parses → duplicate check (new entries only).

## 2. Save flow — four paths

| Path | Required to save | Where validation happens | Save button |
|---|---|---|---|
| **A** Empty form → add manually | At least one of: title, website, Android app (card: holder; identity: full name) | `EntryEditorViewModel.save()` → `effectiveTitle()` | Always enabled (disabled only while saving / after saved) |
| **B** App picker → fill username/password | Nothing else: title = app name | same; `withPickedApp()` | same |
| **C** Website URL typed | Nothing else: title = domain name (e.g. `accounts.google.com` → **Google**) | same | same |
| **D** Imported entry → open → edit → Save | Same rule as A; an imported entry with an empty title is saved with a derived one | same | same |

Failure message (top of the form): *"Enter a title, a website, or choose an Android app"*.
Duplicate (new entries): same username + same domain **or** same package → dialog *Overwrite / Save as new / Cancel*.

## 3. Autofill — match logic (`AutofillMatcher`)

Entries that are notes, folder markers, or have no username/password/PIN/TOTP are ignored. Then, per entry:

1. **Package rule** — `appPackage == requesting app` (or legacy `url = androidapp://<package>`) → **EXACT**. Checked first, even if a web domain is also reported.
2. **Web rule** — only if a web domain was reported: same host → **EXACT**; parent/sub-domain → **RELATED** (shown with ⚠). Look-alike hosts (`github.com.evil.io`, `gitub.com`) never match.
3. Sorting: EXACT first → most recently used → most recently updated → title.

| Entry has | Chrome / web form | Native app |
|---|---|---|
| URL only | matches by domain | **never matches** |
| appPackage only | never matches | matches by exact package |
| both | matches by domain | matches by package |
| neither | never | never |

No guessing from package names is done on purpose: a look-alike app (`com.evil.instagram`) must not receive your password.

## 4. Autofill — fill logic

| Detected field type | How it is recognised | Value filled |
|---|---|---|
| USERNAME | autofill hint (`username`, `email`…), HTML `autocomplete`, `type=email`, words in id/hint (`user`, `login`, `mobile`, `customer`, `employee`, `retailer`, `uid`…), or the plain-text field just before a password field | `username` → else `email` → else `mobile` |
| PASSWORD | hint / `type=password` / password input type / words `password`, `pwd` | `password` |
| PIN | numeric-password input, or a field named *pin* with max length 4–6 | `appPin` |
| OTP | hint `otp`/`smsOtpCode`/`oneTimeCode`, `autocomplete=one-time-code`, words `otp`, `totp`, `2fa`… | current TOTP code |
| NEW_PASSWORD (sign-up / "confirm") | `new-password`, words `new/confirm/repeat` | **never filled** (existing password is never put in a "new" field) |

Native apps:
* Standard `EditText` fields are detected from `inputType`, `hint`, `idEntry` and autofill hints. ✅ for most apps.
* **Compose UIs** are only visible to *any* autofill service if the app marks the field with an autofill content type. Apps that do not are **invisible to Android autofill** — this cannot be fixed inside BSRPRO. 🟡
* Apps that set `importantForAutofill="no"` (some banking apps, deliberately) are skipped by Android itself. 🟡
* WebViews inside apps report a web domain and are matched like Chrome.

Locked vault flow (0.2.12): tap **Unlock BSRPRO Vault** → biometric / master password → exactly one exact match → filled at once; several or only related → chooser; none → explanation. Result is a `Dataset` built from the **same AutofillIds** that were received (the ids are copied through the intent unchanged; `fillableFields` is the only id list used on both sides).

## 5. Feature inventory

### Vault & security
| Feature | Status | Where in the UI |
|---|---|---|
| Create vault, unlock, lock | ✅ | Setup / Lock screens |
| Biometric unlock | ✅ | Settings → Security |
| Auto-lock timeout, lock on background | ✅ | Settings → Security |
| Wrong-password rate limit (5 tries → 30 s) | 🟢 | Lock screen |
| Change master password | ✅ | Settings → Security |
| Reset vault | ✅ | Settings → Data |
| Screenshot block (FLAG_SECURE) | ✅ | all screens |
| Clipboard auto-clear | ✅ | Settings → Security |
| Root/Magisk detection | ⚙️ class exists and is injected, **no screen shows a warning** | — |
| Encrypted storage, V3 format unchanged | ✅ | — |

### Entries
| Feature | Status |
|---|---|
| Add / edit / delete, 4 record types | ✅ |
| Search (typo tolerant), category / strength / starred filters, group by site | 🟢 |
| Duplicate detection | 🟢 |
| Password history / edit history | ✅ saved · 🟢 shown on detail |
| TOTP live code + countdown on detail | 🟢 |
| Password generator (random / passphrase / manual) | ✅ |
| Android app picker (installed apps, with icons) | 🟢 |

### Autofill
| Feature | Status |
|---|---|
| Suggestions + fill in **Chrome** | ✅ |
| Unlock-then-fill in native apps | 🟢 fixed in 0.2.12 — needs your device test |
| Native app matching by package | 🟢 |
| Save-password prompt after login (notification → editor) | 🟢 |
| OTP / PIN fill | 🟢 |
| Inline suggestions above keyboard | 🟡 optional, off by default |
| Card / address autofill | 🔴 |
| `lastUsedAt` updated on use | 🔴 |
| Autofill diagnostics screen + `adb logcat -s BSRPROAutofill` | 🟢 |

### Backup / import
| Feature | Status |
|---|---|
| Export encrypted `.Vault`, CSV, JSON | ✅ |
| Import `.Vault`, device backup, JSON, Chrome, Bitwarden, LastPass, 1Password, Dashlane, KeePass, Firefox, generic CSV, vCard | ✅ |
| Duplicate handling (Skip / Replace / Keep both) | ✅ radio buttons |
| Auto-backup folder + "Restore from backup folder" | 🟢 exists, unverified |
| Import progress | 🟡 spinner only, no counts |

### Appearance
| Feature | Status |
|---|---|
| Theme, app icon colours, splash, logo | ✅ |
| Hindi / English language switch | 🔴 (planned for Phase 10) |

## 6. Manual test script (take a screenshot at every ✱)

**Save button**
1. + → type only *Username* and *Password* → Save. ✱ expect a **red banner at the top**: "Enter a title, a website, or choose an Android app". Form scrolls to the top.
2. Type website `https://google.com` → Save. ✱ entry saved as **Google**.
3. + → *Choose Android app* → JioPOS Plus. ✱ expect **Title = JioPOS Plus**, Website URL **empty**, field "Android App" shows `JioPOS Plus · com.jio.jpp1`. Add username/password → Save. ✱ saved.
4. Open the entry, tap Edit. ✱ Title, Android App (name + package) and empty Website are still correct.

**Native autofill (Jio)**
1. Lock the vault (Menu → Lock now). 2. Open Jio app, tap the username field. ✱ "Unlock BSRPRO Vault" appears.
3. Unlock. ✱ Username **and** password are filled (if you have two entries for this app a chooser appears first).
4. If it fails: Settings → Autofill → *Autofill diagnostics* → Copy report and send it. Expected lines:
   `1 onFillRequest` → `2 parsed pkg=… username=1 password=1` → `4 locked dataset` → `A1 auth activity started` → `A2 after unlock … matches=1` → `4 dataset values USERNAMEx1, PASSWORDx1` → `A3 returning dataset`.
   Whichever line is the last one shows where it stops (e.g. `matches=0` = entry has no package; `username=0 password=0` = app does not expose its fields).
   PC: `adb logcat -s BSRPROAutofill`.

## 7. Not done in 0.2.12
* Folder-picker / auto-restore redesign and import progress with counts (priorities 5–6) — current behaviour left unchanged and listed above as 🟡.
* Language switch, card/address autofill, `lastUsedAt` update, root warning banner.
