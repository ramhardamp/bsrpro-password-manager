# BSRPRO Vault 0.2.5 — Milestone 1 engineering status

## Implemented in this source snapshot
- App version is 0.2.5 / versionCode 7.
- Automatic backup uses the fixed `Downloads/BSRPRO_Backups/BSRPRO.Vault` name on Android 10+ MediaStore; it stages and publishes a complete new file before cleaning previous fixed/legacy dated backups.
- Entry save/edit and starred update/delete request a coalesced backup after successful local persistence. Settings changes and master-password changes also request backup.
- Requests persist a pending marker before the 2.5-second debounce. If the vault is locked, the marker remains; after unlock, the app attempts pending backup before daily catch-up.
- V3 serialization/encryption format was not changed.
- Settings has a restore-tools entry, routing to existing encrypted backup import workflow. The import flow still uses document selection and review; this is not yet automatic folder discovery/one-tap replacement.

## Not accepted / still pending
- Automatic lookup of `Downloads/BSRPRO_Backups/BSRPRO.Vault`, master-password verification against existing vault state, confirm-before-overwrite, round-trip restore verification and `.bak` rollback have not been implemented as a complete safe restore transaction. Do not use this build as evidence those restore requirements are satisfied.
- Pending-backup notification UX is not complete; the durable marker and unlock retry are implemented.
- Gradle assembleDebug, all JUnit tests, emulator, and real-device checks were not run in this environment (no Gradle executable/wrapper JAR and no attached Android device).
- Android 8/9 path remains app-scoped external Downloads, not public Downloads, due scoped-storage compatibility.

## Release gate
Engineering preview only. Do not clear app data, uninstall over a live vault without a verified export, or accept as production-ready until build/tests and the restore rollback matrix pass on a test device with disposable sample vault data.
