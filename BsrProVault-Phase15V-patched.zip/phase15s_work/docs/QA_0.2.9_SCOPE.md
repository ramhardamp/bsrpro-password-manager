# BSRPRO Vault 0.2.9 / Code 11 — iteration notes

## Implemented in this source preview
- Native app autofill datasets prefer `appName`; when blank, installed-app label is resolved through PackageManager, with package-derived fallback.
- App package identity was removed from the visible subtitle; username/mobile remains the subtitle.
- Installed application icons are cached in-memory (bounded LRU); unavailable icons use a generated initial avatar.
- Version bumped to 0.2.9 / 11.
- Auto-backup UI copy now reflects the fixed `BSRPRO.Vault` name.

## Not implemented in this preview
- SAF folder-picker-triggered automatic scan/restore prompt.
- Same-screen import progress and per-entry failure accounting.
- Durable restore crash-recovery protocol and startup recovery.
- Device screenshot validation and Android build/test execution.

## Safety
No V3 serialization/encryption schema or vault blob format changes are intended. Do not use restore against a production vault until the omitted restore recovery work is implemented and tested. Use disposable test data.
