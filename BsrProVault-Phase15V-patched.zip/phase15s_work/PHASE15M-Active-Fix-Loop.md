# Phase 15M active fix loop — current working checkpoint

## Implemented in source in this checkpoint
- FIX 4 SAF foundation: user can select a backup tree with ACTION_OPEN_DOCUMENT_TREE; the URI is persisted in Preferences DataStore and its persistable read/write grant is requested.
- FIX 4 write path: a SAF sibling staging document is written and V3-decrypt-validated before publish. If a canonical backup exists, the writer attempts to rename it to a recovery copy before publishing the staged file and attempts rollback if publish fails. Existing recovery files are not automatically deleted.
- FIX 4 permission recovery: if the stored tree grant is revoked, the stale URI is cleared and the app-managed default backup destination is used.
- FIX 4 MediaStore hardening: no in-place truncation of the previous canonical file; write pending row, validate, then publish. Automatic legacy cleanup remains disabled/non-destructive.
- FIX 6: Notes detail uses a bounded scrollable content area; overflow action menu is anchored to its trigger. The 240-character list teaser is retained; full note content remains accessible in detail/editor.
- Added `tools/phase15m_regression.py` with 10 targeted static regression assertions.

## Checks actually run
- `tools/phase15m_regression.py`: 10/10 static assertions passed.
- `tools/bracket_check.py`: 0 delimiter issues.
- `tools/ci_smoke.sh`: unable to run device install/launch checks because `adb` is not installed.
- Android Gradle compile/test and APK generation were not run: no Gradle wrapper, system Gradle, or configured Android SDK was found in this environment.

## Still open; not marked PASS
- FIX 4: real Android SAF provider behavior, provider rename rollback, backup/restore round trip, revoked-grant UX/device test, and explicit duplicate cleanup confirmation UI.
- FIX 5: full positioning review and device checks across menu-bearing screens.
- FIX 6: accessibility/rotation/device verification.
- FIX 7: profiling and large-vault performance tests.
- FIX 8: biometric key A/B migration design, migration/rollback tests, and device verification. No key migration was attempted because an unsafe speculative migration could lock users out.
- FIX 9: full UI regression and device verification.
- Remaining broader audit findings (including localization and Activity Log instrumentation) remain to be addressed.

This is a working source checkpoint, not a release APK and not an all-fixes-complete claim.
