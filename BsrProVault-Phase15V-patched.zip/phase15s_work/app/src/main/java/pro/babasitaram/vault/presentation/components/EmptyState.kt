// file: app/src/main/java/pro/babasitaram/vault/presentation/components/EmptyState.kt
package pro.babasitaram.vault.presentation.components

// EmptyState is implemented in Components.kt to keep the shared component API in one place.
