package pro.babasitaram.vault.autofill

import android.content.Intent
import android.os.Build
import android.os.CancellationSignal
import android.service.autofill.AutofillService
import android.service.autofill.FillCallback
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.SaveCallback
import android.service.autofill.SaveRequest
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import pro.babasitaram.vault.MainActivity
import pro.babasitaram.vault.autofill.model.AutofillFieldType
import pro.babasitaram.vault.autofill.model.ParsedStructure
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.ThemeMode
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.LockVaultUseCase
import timber.log.Timber

/**
 * System autofill provider.
 *  - unlocked vault: datasets for entries whose domain / package matches
 *  - locked vault: one "Unlock" entry that opens [AutofillAuthActivity]
 *  - after a login form is submitted: the save flow ([onSaveRequest])
 * Nothing sensitive is ever logged.
 */
@AndroidEntryPoint
class VaultAutofillService : AutofillService() {

    @Inject lateinit var session: SessionKeyStore
    @Inject lateinit var repository: VaultRepository
    @Inject lateinit var settings: SettingsRepository
    @Inject lateinit var auth: AuthRepository
    @Inject lateinit var factory: AutofillDatasetFactory
    @Inject lateinit var pendingSaves: PendingSaveStore
    @Inject lateinit var lockVault: LockVaultUseCase

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onConnected() {
        super.onConnected()
        AutofillDiagnostics.record("service connected")
    }

    override fun onFillRequest(request: FillRequest, cancellationSignal: CancellationSignal, callback: FillCallback) {
        AutofillDiagnostics.record("1 onFillRequest called")
        val parsed = try {
            request.fillContexts.lastOrNull()?.structure?.let { AutofillParser.parse(it) }
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            AutofillDiagnostics.record("2 parse FAILED", e.javaClass.simpleName)
            null
        }
        if (parsed == null) {
            AutofillDiagnostics.record("2 no structure", "nothing to fill")
            callback.onSuccess(null)
            return
        }
        AutofillDiagnostics.record(
            "2 parsed",
            "pkg=${parsed.packageName} domain=${parsed.webDomain ?: "-"} scheme=${parsed.webScheme ?: "-"} " +
                "username=${parsed.usernameFields.size} password=${parsed.passwordFields.size} pin=${parsed.pinFields.size} otp=${parsed.otpFields.size}"
        )
        if (!parsed.isFillable || parsed.packageName == packageName) {
            AutofillDiagnostics.record("2 skipped", if (parsed.packageName == packageName) "own app" else "no fillable fields")
            callback.onSuccess(null)
            return
        }
        // never offer credentials to a page that is not served over TLS
        if (parsed.webScheme.equals("http", ignoreCase = true)) {
            AutofillDiagnostics.record("2 skipped", "plain http page")
            callback.onSuccess(null)
            return
        }
        val work = scope.launch {
            val response = try {
                buildResponse(parsed, request)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                AutofillDiagnostics.record("4 build FAILED", e.javaClass.simpleName)
                Timber.w("autofill fill request failed: %s", e.javaClass.simpleName)
                null
            }
            AutofillDiagnostics.record("5 reply", if (response == null) "empty" else "response sent")
            try {
                callback.onSuccess(response)
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                AutofillDiagnostics.record("5 callback FAILED", e.javaClass.simpleName)
            }
        }
        cancellationSignal.setOnCancelListener {
            AutofillDiagnostics.record("cancelled by system")
            work.cancel()
        }
    }

    private suspend fun buildResponse(parsed: ParsedStructure, request: FillRequest): FillResponse? {
        val cfg = settings.current()
        if (cfg.travelMode) {
            AutofillDiagnostics.record("3 skipped", "travel mode enabled")
            return null
        }
        val inline = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && cfg.autofillInline) request.inlineSuggestionsRequest else null
        val nightTheme = when (cfg.theme) {
            ThemeMode.DARK -> true
            ThemeMode.LIGHT -> false
            ThemeMode.SYSTEM -> (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        }
        val wasUnlocked = session.isUnlocked.value
        val validSession = cfg.quickAutofillEnabled && wasUnlocked && session.hasValidSession()
        AutofillDiagnostics.record("3 state", "sessionValid=$validSession inline=${inline != null} entries=${repository.entries.value.size} night=$nightTheme")

        if (!validSession) {
            if (wasUnlocked && cfg.quickAutofillEnabled) {
                // The in-memory timer expired between lifecycle callbacks and this Autofill request.
                // Clear decrypted repository state before showing the authentication dataset.
                lockVault("Session expired")
            }
            if (!auth.vaultExists()) {
                AutofillDiagnostics.record("3 no vault on device")
                return null
            }
            AutofillDiagnostics.record("4 offering unlock entry", "dataset authentication")
            return factory.lockedResponse(parsed, factory.authSender(parsed, inline), inline, nightTheme)
        }
        var matches = AutofillMatcher.match(
            repository.entries.value,
            parsed.packageName,
            parsed.webDomain,
            cfg.autofillExcludedPackages.toSet(),
            cfg.autofillRegexEnabled
        )
        if (parsed.isOtpOnly) matches = matches.filter { it.entry.totp.isNotBlank() }
        AutofillDiagnostics.record("4 matches", "${matches.size} for ${parsed.webDomain ?: parsed.packageName}")
        return factory.unlockedResponse(parsed, matches, inline, System.currentTimeMillis(), nightTheme, cfg.autofillSavePrompts)
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        val parsed = request.fillContexts.lastOrNull()?.structure?.let { AutofillParser.parse(it) }
        val pending = parsed?.let { toPending(it) }
        if (pending == null) {
            callback.onSuccess()
            return
        }
        pendingSaves.put(pending)
        // Try to open the app straight away; also post a notification in case the background launch is blocked.
        runCatching {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
        SaveNotifier.post(this, pending)
        callback.onSuccess()
    }

    private fun toPending(parsed: ParsedStructure): PendingSave? {
        val password = parsed.fields.firstOrNull { it.type == AutofillFieldType.NEW_PASSWORD && !it.value.isNullOrEmpty() }?.value
            ?: parsed.fields.lastOrNull { it.type == AutofillFieldType.PASSWORD && !it.value.isNullOrEmpty() }?.value.orEmpty()
        val appPin = parsed.fields.lastOrNull { it.type == AutofillFieldType.PIN && !it.value.isNullOrEmpty() }?.value.orEmpty()
        if (password.isEmpty() && appPin.isEmpty()) return null
        val username = parsed.fields.firstOrNull { it.type == AutofillFieldType.USERNAME && !it.value.isNullOrEmpty() }?.value.orEmpty()
        return PendingSave(
            packageName = parsed.packageName,
            webDomain = parsed.webDomain,
            username = username,
            password = password,
            appPin = appPin,
            createdAt = System.currentTimeMillis()
        )
    }
}
