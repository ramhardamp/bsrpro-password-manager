@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.vault

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.Avatar
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.components.SelectionBottomBar
import pro.babasitaram.vault.presentation.components.SelectionTopBar
import pro.babasitaram.vault.presentation.components.bucketColor
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.util.findFragmentActivity

private sealed interface ListRow {
    data class Header(val key: String, val count: Int, val expanded: Boolean) : ListRow
    data class Item(val entry: VaultEntry, val indented: Boolean) : ListRow
}

private fun groupKey(e: VaultEntry): String =
    UrlUtils.domainOf(e.url).ifEmpty { e.appName.ifEmpty { e.title.ifEmpty { "other" } } }

private fun buildRows(entries: List<VaultEntry>, grouped: Boolean, expanded: Set<String>): List<ListRow> {
    if (!grouped) return entries.map { ListRow.Item(it, false) }
    return entries.groupBy { groupKey(it) }.flatMap<String, List<VaultEntry>, ListRow> { (key, list) ->
        if (list.size == 1) {
            listOf<ListRow>(ListRow.Item(list.first(), false))
        } else {
            val open = key in expanded
            buildList<ListRow> {
                add(ListRow.Header(key, list.size, open))
                if (open) list.forEach { add(ListRow.Item(it, true)) }
            }
        }
    }
}

@Composable
fun VaultListScreen(
    onOpen: (String) -> Unit,
    onAdd: () -> Unit,
    onGenerator: () -> Unit,
    onSettings: () -> Unit,
    onEdit: (String) -> Unit = {},
    onShare: (String) -> Unit = {},
    onShareSelected: (List<String>) -> Unit = { ids -> ids.forEach(onShare) },
    vm: VaultListViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val selectedIds by vm.selectedIds.collectAsStateWithLifecycle()
    val selectionMode by vm.selectionMode.collectAsStateWithLifecycle()
    val selectableIds by vm.selectableIds.collectAsStateWithLifecycle()
    var confirmBulkDelete by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var sortMenuOpen by remember { mutableStateOf(false) }
    var createFolderOpen by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(emptySet<String>()) }
    CollectMessages(vm.messages)

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (selectionMode) {
                SelectionTopBar(
                    selectedCount = selectedIds.size,
                    allSelected = selectableIds.isNotEmpty() && selectedIds.containsAll(selectableIds),
                    onExit = vm::exitSelection,
                    onToggleSelectAll = vm::toggleSelectAll
                )
            } else {
                // Compact header: pill search + sort / group / more in ONE row, then two slim chip rows (32dp).
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.weight(1f).height(40.dp)
                ) {
                    Row(Modifier.padding(horizontal = AppDimens.ScreenHorizontal), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                            if (state.query.isEmpty()) {
                                Text(stringResource(R.string.vault_search_passwords), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            androidx.compose.foundation.text.BasicTextField(
                                value = state.query,
                                onValueChange = vm::setQuery,
                                singleLine = true,
                                textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
                                cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
                Box {
                    IconButton(onClick = { sortMenuOpen = true }) {
                        Icon(Icons.Default.Sort, contentDescription = stringResource(R.string.vault_sort))
                    }
                    DropdownMenu(expanded = sortMenuOpen, onDismissRequest = { sortMenuOpen = false }) {
                        SortMode.values().forEach { option ->
                            DropdownMenuItem(
                                text = { Text(stringResource(option.labelRes())) },
                                onClick = { sortMenuOpen = false; vm.setSort(option) }
                            )
                        }
                    }
                }
                IconButton(onClick = vm::toggleGrouped) {
                    Icon(Icons.AutoMirrored.Filled.ViewList, contentDescription = stringResource(R.string.vault_group_by_site))
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.vault_more_options))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.vault_manage_folders)) },
                            onClick = { menuOpen = false; createFolderOpen = true }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.vault_password_generator)) },
                            onClick = { menuOpen = false; onGenerator() }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(if (state.biometricEnabled) R.string.vault_disable_biometric else R.string.vault_enable_biometric)) },
                            onClick = {
                                menuOpen = false
                                context.findFragmentActivity()?.let { vm.toggleBiometric(it) }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.p15_settings)) },
                            onClick = { menuOpen = false; onSettings() }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.vault_lock_now)) },
                            onClick = { menuOpen = false; vm.lock() }
                        )
                    }
                }
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(ListFilter.values().toList(), key = { it.name  }, contentType = { "item" }) { filter ->
                    CompactChip(selected = state.filter == filter, onClick = { vm.setFilter(filter) }, label = stringResource(filter.labelRes()))
                }
            }

            if (state.showCategories) LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(CATEGORIES, key = { it }, contentType = { "category" }) { category ->
                    CompactChip(selected = state.category == category, onClick = { vm.setCategory(category) }, label = categoryLabelRes(category).let { stringResource(it) })
                }
                item { CompactChip(selected = state.folderId == null, onClick = { vm.setFolder(null) }, label = stringResource(R.string.vault_all_folders)) }
                items(state.folders, key = { it.id  }, contentType = { "item" }) { folder ->
                    CompactChip(selected = state.folderId == folder.id, onClick = { vm.setFolder(folder.id) }, label = folder.name)
                }
                item { CompactChip(selected = false, onClick = { createFolderOpen = true }, label = stringResource(R.string.vault_add_folder)) }
            }

            }

            val rows = remember(state.entries, state.grouped, expanded) { buildRows(state.entries, state.grouped, expanded) }

            when {
                state.totalCount == 0 -> EmptyState(
                    stringResource(R.string.vault_no_passwords),
                    stringResource(R.string.vault_no_passwords_message)
                )
                rows.isEmpty() -> EmptyState(stringResource(R.string.vault_no_matches), stringResource(R.string.vault_no_matches_message))
                else -> {
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 96.dp)
                    ) {
                        items(
                            rows,
                            key = { row -> if (row is ListRow.Header) "h:${row.key}" else "e:${(row as ListRow.Item).entry.id}" },
                            contentType = { row -> if (row is ListRow.Header) 0 else 1 }
                        ) { row ->
                            when (row) {
                                is ListRow.Header -> ListItem(
                                    headlineContent = { Text(row.key) },
                                    supportingContent = { Text(stringResource(R.string.vault_entries_count, row.count)) },
                                    leadingContent = { Icon(Icons.Default.Folder, contentDescription = null) },
                                    trailingContent = {
                                        Icon(
                                            if (row.expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = null
                                        )
                                    },
                                    modifier = Modifier.clickable {
                                        expanded = if (row.key in expanded) expanded - row.key else expanded + row.key
                                    }
                                )
                                is ListRow.Item -> EntryRow(
                                    entry = row.entry,
                                    indented = row.indented,
                                    selectionMode = selectionMode,
                                    selected = row.entry.id in selectedIds,
                                    onClick = { onOpen(row.entry.id) },
                                    onLongClick = { vm.beginSelection(row.entry.id) },
                                    onToggleSelection = { vm.toggleSelection(row.entry.id) },
                                    onCopy = { vm.copyPassword(row.entry) },
                                    onCopyUsername = { vm.copyUsername(row.entry) },
                                    onCopyTotp = { vm.copyTotp(row.entry) },
                                    onEdit = { onEdit(row.entry.id) },
                                    onDelete = { vm.delete(row.entry) },
                                    onShare = { onShare(row.entry.id) },
                                    onToggleStar = { vm.toggleStar(row.entry) }
                                )
                            }
                        }
                        if (state.canLoadMore && !state.grouped) {
                            item {
                                TextButton(onClick = vm::loadMore, modifier = Modifier.fillMaxWidth()) {
                                    Text(stringResource(R.string.load_more_entries))
                                }
                            }
                        }
                    }
                }
            }
        }

        if (selectionMode) {
            SelectionBottomBar(
                selectedCount = selectedIds.size,
                onDelete = { confirmBulkDelete = true },
                onShare = { onShareSelected(selectedIds.toList()) },
                onFavorite = vm::favoriteSelected,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        if (!selectionMode) FloatingActionButton(
            onClick = onAdd,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .navigationBarsPadding()
        ) {
            Icon(Icons.Default.Add, contentDescription = stringResource(R.string.vault_add_entry))
        }
    }

    if (confirmBulkDelete && selectedIds.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { confirmBulkDelete = false },
            title = { Text(stringResource(R.string.selection_delete_title)) },
            text = { Text(stringResource(R.string.selection_delete_text, selectedIds.size)) },
            confirmButton = {
                TextButton(onClick = { confirmBulkDelete = false; vm.deleteSelected() }) {
                    Text(stringResource(R.string.p15_delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmBulkDelete = false }) {
                    Text(stringResource(R.string.p15_cancel))
                }
            }
        )
    }

    if (createFolderOpen) {
        AlertDialog(
            onDismissRequest = { newFolderName = ""; createFolderOpen = false },
            title = { Text(stringResource(R.string.vault_new_folder)) },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text(stringResource(R.string.vault_folder_name)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        vm.createFolder(newFolderName)
                        newFolderName = ""
                        createFolderOpen = false
                    },
                    enabled = newFolderName.trim().isNotEmpty()
                ) { Text(stringResource(R.string.vault_create)) }
            },
            dismissButton = { TextButton(onClick = { newFolderName = ""; createFolderOpen = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}

@Composable
private fun EntryRow(
    entry: VaultEntry,
    indented: Boolean,
    selectionMode: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onToggleSelection: () -> Unit,
    onCopy: () -> Unit,
    onCopyUsername: () -> Unit,
    onCopyTotp: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit,
    onToggleStar: () -> Unit
) {
    val subtitle = entry.username.ifEmpty { UrlUtils.domainOf(entry.url).ifEmpty { entry.appName } }
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    ListItem(
        headlineContent = { Text(entry.title.ifEmpty { stringResource(R.string.health_untitled) }, maxLines = 1) },
        supportingContent = { if (subtitle.isNotEmpty()) Text(subtitle, maxLines = 1) },
        leadingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selectionMode) {
                    androidx.compose.material3.Checkbox(checked = selected, onCheckedChange = { onToggleSelection() })
                }
                Avatar(entry.title.ifEmpty { subtitle })
            }
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!selectionMode) {
                    IconButton(onClick = onToggleStar) {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = stringResource(
                                if (entry.starred) R.string.vault_remove_favorite else R.string.vault_add_favorite
                            ),
                            tint = if (entry.starred) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(AppDimens.IconSize)
                        )
                    }
                }
                if (!selectionMode) {
                    if (entry.password.isNotEmpty()) {
                        Box(Modifier.padding(horizontal = 6.dp).size(8.dp).background(bucketColor(entry.strengthBucket()), CircleShape))
                        IconButton(onClick = onCopy) { Icon(Icons.Default.ContentCopy, stringResource(R.string.vault_copy_password)) }
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, stringResource(R.string.vault_more_options)) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (entry.password.isNotBlank()) DropdownMenuItem(text = { Text(stringResource(R.string.vault_copy_password)) }, onClick = { menu = false; onCopy() })
                        if (entry.username.isNotBlank()) DropdownMenuItem(text = { Text(stringResource(R.string.vault_copy_username)) }, onClick = { menu = false; onCopyUsername() })
                        if (entry.totp.isNotBlank()) DropdownMenuItem(text = { Text(stringResource(R.string.vault_copy_totp)) }, onClick = { menu = false; onCopyTotp() })
                        DropdownMenuItem(text = { Text(stringResource(R.string.p15_edit)) }, onClick = { menu = false; onEdit() })
                        DropdownMenuItem(text = { Text(stringResource(R.string.vault_move_to_bin)) }, onClick = { menu = false; confirmDelete = true })
                        DropdownMenuItem(text = { Text(stringResource(R.string.vault_share_securely)) }, onClick = { menu = false; onShare() })
                        DropdownMenuItem(text = { Text(stringResource(if (entry.starred) R.string.vault_remove_favorite else R.string.vault_add_favorite)) }, onClick = { menu = false; onToggleStar() })
                        }
                    }
                }
            }
        },
        modifier = Modifier
            .combinedClickable(
                onClick = { if (selectionMode) onToggleSelection() else onClick() },
                onLongClick = { if (selectionMode) onToggleSelection() else onLongClick() }
            )
            .padding(start = if (indented) 24.dp else 0.dp)
    )

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.vault_move_to_bin_title)) },
            text = { Text(stringResource(R.string.vault_move_to_bin_text, entry.title.ifBlank { stringResource(R.string.vault_this_entry) })) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text(stringResource(R.string.vault_move_to_bin)) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}


private fun ListFilter.labelRes(): Int = when (this) {
    ListFilter.ALL -> R.string.p15_all
    ListFilter.STRONG -> R.string.p15_strong
    ListFilter.WEAK -> R.string.p15_weak
    ListFilter.STARRED -> R.string.p15_starred
}

private fun SortMode.labelRes(): Int = when (this) {
    SortMode.NAME -> R.string.sort_name
    SortMode.UPDATED -> R.string.sort_recently_updated
    SortMode.USED -> R.string.sort_recently_used
    SortMode.STRENGTH -> R.string.sort_strength
}

private fun categoryLabelRes(category: String): Int = when (category.lowercase()) {
    "work" -> R.string.p15_work
    "personal" -> R.string.p15_personal
    "banking" -> R.string.p15_banking
    "social" -> R.string.p15_social
    else -> R.string.p15_other
}

@Composable
private fun CompactChip(selected: Boolean, onClick: () -> Unit, label: String) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1) },
        modifier = Modifier.height(32.dp)
    )
}
