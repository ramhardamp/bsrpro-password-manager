package pro.babasitaram.vault

import pro.babasitaram.vault.core.model.ThemeMode

/** Synchronous process-start theme snapshot; DataStore remains the source of truth. */
object AppThemeCache {
    @Volatile
    var initialTheme: ThemeMode = ThemeMode.DARK
        private set

    fun update(theme: ThemeMode) { initialTheme = theme }
}
