package pro.babasitaram.vault.domain.usecase

import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.security.BiometricSessionKeyStore
import pro.babasitaram.vault.domain.repository.SettingsRepository

/**
 * Restores a process-lost session only from the encrypted Key-B credential and session timestamps.
 * No boolean flag can make the vault appear unlocked after process death.
 */
class RestorePersistedSessionUseCase @Inject constructor(
    private val settings: SettingsRepository,
    private val persisted: BiometricSessionKeyStore,
    private val unlockVault: UnlockVaultUseCase
) {
    enum class Result { Restored, NotAvailable, RequiresAuthentication }

    suspend operator fun invoke(forAutofill: Boolean = false): Result = withContext(Dispatchers.Default) {
        val cfg = settings.current()
        if (!cfg.biometricEnabled) return@withContext Result.NotAvailable
        if (forAutofill && !cfg.quickAutofillEnabled) return@withContext Result.NotAvailable
        val metadata = persisted.readSessionMetadata() ?: return@withContext Result.NotAvailable
        val now = System.currentTimeMillis()
        if (now < metadata.issuedAtWallMs || now >= metadata.expiresAtWallMs) {
            persisted.clearSessionMetadata()
            return@withContext Result.NotAvailable
        }
        val bg = metadata.backgroundedAtWallMs
        if (bg > 0L && now - bg >= cfg.backgroundGraceSeconds * 1000L) {
            persisted.clearSessionMetadata()
            return@withContext Result.NotAvailable
        }
        when (val loaded = persisted.tryLoadCredentialSilently()) {
            is BiometricSessionKeyStore.SilentLoadResult.Password -> {
                val password = loaded.value
                try {
                    when (val r = unlockVault(password)) {
                        is pro.babasitaram.vault.core.util.VaultResult.Success -> Result.Restored
                        else -> {
                            persisted.clearSessionMetadata()
                            Result.NotAvailable
                        }
                    }
                } finally {
                    password.fill('\u0000')
                }
            }
            BiometricSessionKeyStore.SilentLoadResult.RequiresAuthentication -> Result.RequiresAuthentication
            BiometricSessionKeyStore.SilentLoadResult.Invalidated -> {
                persisted.clearSessionMetadata()
                persisted.clearSecureCredential()
                settings.update { it.copy(biometricEnabled = false) }
                Result.NotAvailable
            }
            BiometricSessionKeyStore.SilentLoadResult.Missing -> Result.NotAvailable
        }
    }
}
