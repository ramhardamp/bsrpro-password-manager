package pro.babasitaram.vault.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase

/**
 * Created with Room.inMemoryDatabaseBuilder: metadata is refilled from the decrypted blob after unlock
 * and is never written to disk, so no plaintext titles/URLs/usernames can leak from storage.
 */
@Database(
    entities = [EntryMetadataEntity::class, FolderEntity::class, RecentSearchEntity::class],
    version = 1,
    exportSchema = false
)
abstract class VaultDatabase : RoomDatabase() {
    abstract fun vaultDao(): VaultDao
}
