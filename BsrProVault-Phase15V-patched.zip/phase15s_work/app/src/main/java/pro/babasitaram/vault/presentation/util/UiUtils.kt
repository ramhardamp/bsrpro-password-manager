package pro.babasitaram.vault.presentation.util

import android.content.Context
import android.content.ContextWrapper
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import pro.babasitaram.vault.core.security.VaultClipboardManager
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.domain.repository.SettingsRepository
import androidx.compose.runtime.*

fun VaultError.toUserMessage(): String = when (this) {
    is VaultError.Validation -> reason
    VaultError.InvalidMasterPassword -> "Incorrect password"
    is VaultError.InvalidFormat -> "This file is not a valid BSRPRO backup"
    is VaultError.RateLimited -> "Too many attempts. Try again in ${(retryAfterMs + 999) / 1000}s"
    VaultError.VaultNotFound -> "No vault found on this device"
    VaultError.VaultLocked -> "Vault is locked"
    VaultError.BiometricUnavailable -> "Biometric unlock is not available"
    is VaultError.CryptoFailure, is VaultError.IOError, is VaultError.Unknown -> "Something went wrong. Please try again."
}

tailrec fun Context.findFragmentActivity(): FragmentActivity? = when (this) {
    is FragmentActivity -> this
    is ContextWrapper -> baseContext.findFragmentActivity()
    else -> null
}

@Composable
fun CollectMessages(messages: Flow<String>) {
    val context = LocalContext.current
    LaunchedEffect(messages) {
        messages.collect { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
    }
}

/** Copies a secret with the user's auto-clear delay and returns the message to show. */
class ClipboardActions @Inject constructor(
    private val clipboard: VaultClipboardManager,
    private val settings: SettingsRepository
) {
    suspend fun copy(text: String, label: String): String {
        val seconds = settings.current().clipboardClearSeconds
        clipboard.copySensitive(text, seconds * 1000L, label)
        return if (seconds > 0) "$label copied — clears in ${seconds}s" else "$label copied"
    }
}
