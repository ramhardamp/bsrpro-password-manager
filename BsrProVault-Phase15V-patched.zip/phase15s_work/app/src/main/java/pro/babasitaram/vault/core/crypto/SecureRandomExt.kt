package pro.babasitaram.vault.core.crypto

import java.security.SecureRandom

fun SecureRandom.randomBytes(size: Int): ByteArray = ByteArray(size).also { nextBytes(it) }
