package pro.babasitaram.vault.data.repository

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.withLock
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.isHiddenVault
import pro.babasitaram.vault.core.util.vaultCatching
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.data.local.db.VaultDao
import pro.babasitaram.vault.data.local.db.toEntity
import pro.babasitaram.vault.data.local.db.toMetadata
import pro.babasitaram.vault.domain.repository.VaultRepository

class VaultRepositoryImpl(
    private val blobStore: VaultBlobStore,
    private val session: SessionKeyStore,
    private val dao: VaultDao,
    private val activityLog: ActivityLogStore? = null
) : VaultRepository {

    private val mutex = Mutex()
    private var all: List<VaultEntry> = emptyList()
    private var allFolders: List<Folder> = emptyList()

    private val _entries = MutableStateFlow<List<VaultEntry>>(emptyList())
    private val _folders = MutableStateFlow<List<Folder>>(emptyList())
    private val _trashedEntries = MutableStateFlow<List<VaultEntry>>(emptyList())
    private val _mobileCount = MutableStateFlow(0)
    override val entries: StateFlow<List<VaultEntry>> = _entries.asStateFlow()
    override val folders: StateFlow<List<Folder>> = _folders.asStateFlow()
    override val trashedEntries: StateFlow<List<VaultEntry>> = _trashedEntries.asStateFlow()
    override val mobileCount: StateFlow<Int> = _mobileCount.asStateFlow()

    override fun entry(id: String): VaultEntry? = _entries.value.firstOrNull { it.id == id }

    override fun findDuplicate(candidate: VaultEntry): VaultEntry? {
        val domain = UrlUtils.domainOf(candidate.url)
        if (candidate.username.isBlank() || (domain.isEmpty() && candidate.appPackage.isEmpty())) return null
        return _entries.value.firstOrNull {
            it.id != candidate.id &&
                it.username.equals(candidate.username, ignoreCase = true) &&
                (
                    (domain.isNotEmpty() && UrlUtils.domainOf(it.url) == domain) ||
                        (candidate.appPackage.isNotEmpty() && it.appPackage == candidate.appPackage)
                    )
        }
    }

    override suspend fun setData(data: VaultData) = mutex.withLock {
        publish(data.entries, data.folders)
    }

    override suspend fun upsert(entry: VaultEntry) = mutex.withLock {
        val idx = all.indexOfFirst { it.id == entry.id }
        val previousEntry = all.getOrNull(idx)
        val next = if (idx >= 0) all.toMutableList().also { it[idx] = entry } else all + entry
        persist(next, allFolders)       // write first: memory only changes if the disk write succeeded
        publish(next, allFolders)
        val type = when {
            entry.isNote || entry.recordType.equals("note", true) -> "Note"
            entry.recordType.equals("mobile", true) -> "Mobile"
            entry.recordType.equals("card", true) -> "Card"
            entry.recordType.equals("identity", true) -> "Identity"
            entry.recordType.equals("totp", true) -> "TOTP"
            entry.recordType.equals("file", true) || entry.recordType.equals("attachment", true) -> "File"
            else -> "Entry"
        }
        val oldEntry = previousEntry
        activityLog?.record(if (idx >= 0) "$type edited" else "$type added", "Vault record saved")
        if (entry.totp.isNotBlank() && oldEntry?.totp != entry.totp) activityLog?.record(if (oldEntry?.totp.isNullOrBlank()) "TOTP added" else "TOTP updated", "Authenticator data changed")
        if (entry.totp.isBlank() && oldEntry?.totp?.isNotBlank() == true) activityLog?.record("TOTP removed", "Authenticator data removed")
    }

    override suspend fun upsertFolder(folder: Folder): VaultResult<Unit> = mutex.withLock {
        vaultCatching {
            val now = System.currentTimeMillis()
            val normalized = folder.copy(
                id = folder.id.ifBlank { "folder-${now}-${folder.name.trim().hashCode().toUInt().toString(16)}" },
                name = folder.name.trim(),
                updatedAt = now,
                createdAt = folder.createdAt.takeIf { it > 0L } ?: now
            )
            require(normalized.name.isNotBlank()) { "Folder name cannot be empty" }
            val nextFolders = allFolders.filterNot { it.id == normalized.id } + normalized
            persist(all, nextFolders)
            publish(all, nextFolders)
        }
    }

    override suspend fun deleteFolder(id: String): VaultResult<Unit> = mutex.withLock {
        vaultCatching {
            if (allFolders.none { it.id == id }) return@vaultCatching Unit
            val nextEntries = all.map { entry ->
                if (entry.folderId == id) entry.copy(folderId = "", updatedAt = System.currentTimeMillis()) else entry
            }
            val nextFolders = allFolders.filterNot { it.id == id }
            persist(nextEntries, nextFolders)
            publish(nextEntries, nextFolders)
        }
    }

    override suspend fun upsertAll(entries: List<VaultEntry>, folders: List<Folder>) = mutex.withLock {
        if (entries.isEmpty() && folders.isEmpty()) return@withLock
        val merged = LinkedHashMap<String, VaultEntry>()
        all.forEach { merged[it.id] = it }
        entries.forEach { merged[it.id] = it }
        val nextFolders = allFolders + folders.filter { f -> allFolders.none { it.id == f.id } }
        val next = merged.values.toList()
        persist(next, nextFolders)
        publish(next, nextFolders)
    }

    override suspend fun softDelete(id: String) = mutex.withLock {
        val now = System.currentTimeMillis()
        val idx = all.indexOfFirst { it.id == id && it.deletedAt == 0L }
        if (idx < 0) return@withLock
        val deleted = all[idx]
        val kind = when {
            deleted.isNote || deleted.recordType.equals("note", true) -> "Note"
            deleted.recordType.equals("mobile", true) -> "Mobile"
            deleted.recordType.equals("card", true) -> "Card"
            deleted.recordType.equals("identity", true) -> "Identity"
            deleted.hasFileRecordType() -> "File"
            deleted.recordType.equals("totp", true) -> "TOTP"
            else -> "Entry"
        }
        val next = all.toMutableList().also { it[idx] = it[idx].copy(deletedAt = now, updatedAt = now) }
        persist(next, allFolders)
        publish(next, allFolders)
        activityLog?.record("$kind deleted", "Moved to Bin")
    }

    override suspend fun restore(id: String) = mutex.withLock {
        val idx = all.indexOfFirst { it.id == id && it.deletedAt > 0L }
        if (idx < 0) return@withLock
        val next = all.toMutableList().also { it[idx] = it[idx].copy(deletedAt = 0L, updatedAt = System.currentTimeMillis()) }
        persist(next, allFolders)
        publish(next, allFolders)
        activityLog?.record("Entry restored", "Restored from Bin")
    }

    override suspend fun restoreAll() = mutex.withLock {
        if (all.none { it.deletedAt > 0L }) return@withLock
        val restoredCount = all.count { it.deletedAt > 0L }
        val now = System.currentTimeMillis()
        val next = all.map { entry ->
            if (entry.deletedAt > 0L) entry.copy(deletedAt = 0L, updatedAt = now) else entry
        }
        persist(next, allFolders)
        publish(next, allFolders)
        activityLog?.record("Bin restored", "Restored $restoredCount records")
    }

    override suspend fun emptyTrash() = mutex.withLock {
        val removedCount = all.count { it.deletedAt > 0L }
        val next = all.filterNot { it.deletedAt > 0L }
        if (next.size == all.size) return@withLock
        persist(next, allFolders)
        publish(next, allFolders)
        activityLog?.record("Bin emptied", "Permanently removed $removedCount records")
    }

    override suspend fun cleanupExpiredTrash(now: Long, retentionMs: Long) = mutex.withLock {
        val cutoff = now - retentionMs
        val next = all.filterNot { it.deletedAt > 0L && it.deletedAt <= cutoff }
        if (next.size == all.size) return@withLock
        persist(next, allFolders)
        publish(next, allFolders)
    }

    override suspend fun clear() = mutex.withLock {
        all = emptyList()
        allFolders = emptyList()
        _entries.value = emptyList()
        _folders.value = emptyList()
        _trashedEntries.value = emptyList()
        _mobileCount.value = 0
        dao.wipe()
    }

    private fun VaultEntry.hasFileRecordType(): Boolean = recordType.equals("file", true) || recordType.equals("attachment", true)

    /** Mobile badge rule: number field must actually contain a value; hidden/trashed entries never count. */
    private fun VaultEntry.isCountableMobile(): Boolean =
        deletedAt == 0L && !isFolderMarker && !isHiddenVault && (mobile.isNotBlank() || phone.isNotBlank())

    private suspend fun persist(entries: List<VaultEntry>, folders: List<Folder>) {
        session.withPassword { pw -> blobStore.write(VaultData(entries, folders), pw) }
    }

    private suspend fun publish(entries: List<VaultEntry>, folders: List<Folder>) {
        all = entries
        allFolders = folders
        val visible = entries.filterNot { it.isFolderMarker || it.deletedAt > 0L }
        val trashed = entries.filterNot { it.isFolderMarker }.filter { it.deletedAt > 0L }
        _entries.value = visible
        _folders.value = folders
        _trashedEntries.value = trashed
        _mobileCount.value = visible.count { it.isCountableMobile() }
        withContext(Dispatchers.IO) { dao.replaceAll(visible.map { it.toMetadata() }, folders.map { it.toEntity() }) }
    }
}
