package pro.babasitaram.vault.core.security

import android.os.SystemClock
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.di.ApplicationScope
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.LockVaultUseCase

/**
 * App-process lifecycle controller. Backgrounding starts a grace timer; foregrounding does not
 * automatically lock unless that grace or the absolute session lifetime has expired.
 */
@Singleton
class AutoLockController @Inject constructor(
    private val settings: SettingsRepository,
    private val session: SessionKeyStore,
    private val persisted: BiometricSessionKeyStore,
    private val lockVault: LockVaultUseCase,
    @ApplicationScope private val scope: CoroutineScope
) {
    internal var clock: () -> Long = { SystemClock.elapsedRealtime() }
    private var backgroundJob: Job? = null
    private var sessionExpiryJob: Job? = null
    private var backgroundedAtElapsed = 0L
    private var lifecycleCollector: Job? = null

    init {
        lifecycleCollector = scope.launch {
            session.isUnlocked.collectLatest { unlocked ->
                sessionExpiryJob?.cancel()
                if (!unlocked) return@collectLatest
                val remaining = session.sessionRemainingMs(clock())
                if (remaining == Long.MAX_VALUE) return@collectLatest
                if (remaining <= 0L) {
                    lockVault("Auto")
                    return@collectLatest
                }
                sessionExpiryJob = launch {
                    delay(remaining)
                    if (!session.hasValidSession(clock())) {
                        lockVault("Session expired")
                    }
                }
            }
        }
    }

    fun onBackgrounded() {
        if (!session.isUnlocked.value) return
        if (!session.hasValidSession(clock())) {
            scope.launch { lockVault("Session expired") }
            return
        }
        backgroundedAtElapsed = clock()
        backgroundJob?.cancel()
        scope.launch { persisted.markBackgrounded(System.currentTimeMillis()) }
        backgroundJob = scope.launch {
            val s = settings.current()
            val graceMs = s.backgroundGraceSeconds.toTimeoutMs()
            val sessionRemaining = session.sessionRemainingMs(clock())
            val waitMs = when {
                graceMs == Long.MAX_VALUE -> sessionRemaining
                sessionRemaining == Long.MAX_VALUE -> graceMs
                else -> minOf(graceMs, sessionRemaining)
            }
            if (waitMs > 0L && waitMs != Long.MAX_VALUE) delay(waitMs)
            if (!session.hasValidSession(clock())) {
                lockVault("Session expired")
                return@launch
            }
            val current = settings.current()
            val elapsedBackground = clock() - backgroundedAtElapsed
            if (elapsedBackground >= current.backgroundGraceSeconds.toTimeoutMs() || session.sessionRemainingMs(clock()) <= 0L) {
                lockVault("Auto")
            }
        }
    }

    fun onForegrounded() {
        backgroundJob?.cancel()
        val since = backgroundedAtElapsed
        backgroundedAtElapsed = 0L
        if (!session.isUnlocked.value) return
        if (!session.hasValidSession(clock())) {
            scope.launch { lockVault("Session expired") }
            return
        }
        scope.launch {
            val s = settings.current()
            val persistedSince = persisted.readSessionMetadata()?.backgroundedAtWallMs ?: 0L
            val backgroundAt = maxOf(
                if (since > 0L) System.currentTimeMillis() - (clock() - since) else 0L,
                persistedSince
            )
            val graceMs = s.backgroundGraceSeconds.toTimeoutMs()
            val backgroundExpired = backgroundAt > 0L && graceMs != Long.MAX_VALUE &&
                System.currentTimeMillis() - backgroundAt >= graceMs
            if (backgroundExpired || session.sessionRemainingMs(clock()) <= 0L) {
                lockVault("Auto")
            } else {
                persisted.clearBackgrounded()
            }
        }
    }

    private fun Int.toTimeoutMs(): Long = when {
        this == pro.babasitaram.vault.core.model.VaultSettings.AUTO_LOCK_NEVER -> Long.MAX_VALUE
        this <= 0 -> 0L
        else -> this.toLong() * 1000L
    }
}
