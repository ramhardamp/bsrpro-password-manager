package pro.babasitaram.vault.widget

import android.content.Intent
import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import pro.babasitaram.vault.MainActivity
import pro.babasitaram.vault.R

class VaultQuickTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            label = "BSRPRO Vault"
            subtitle = "Open vault"
            icon = Icon.createWithResource(this@VaultQuickTileService, R.mipmap.ic_launcher)
            state = Tile.STATE_ACTIVE
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        startActivityAndCollapse(Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        })
    }
}
