package pro.babasitaram.vault.domain.repository

import kotlinx.coroutines.flow.Flow
import pro.babasitaram.vault.core.model.VaultSettings

interface SettingsRepository {
    val settings: Flow<VaultSettings>
    suspend fun current(): VaultSettings
    suspend fun update(transform: (VaultSettings) -> VaultSettings)
}
