package pro.babasitaram.vault.domain.usecase

import javax.inject.Inject
import pro.babasitaram.vault.core.util.Totp
import pro.babasitaram.vault.core.util.TotpCode

class GenerateTotpCodeUseCase @Inject constructor() {
    operator fun invoke(secretOrUri: String, nowMs: Long = System.currentTimeMillis()): TotpCode? =
        Totp.current(secretOrUri, nowMs)
}
