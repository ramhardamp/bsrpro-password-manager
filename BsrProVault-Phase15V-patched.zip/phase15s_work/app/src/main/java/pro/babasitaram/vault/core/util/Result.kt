package pro.babasitaram.vault.core.util

sealed interface VaultResult<out T> {
    data class Success<T>(val value: T) : VaultResult<T>
    data class Failure(val error: VaultError) : VaultResult<Nothing>
    data object Loading : VaultResult<Nothing>
}

sealed class VaultError(message: String, cause: Throwable? = null) : Exception(message, cause) {
    object VaultLocked : VaultError("Vault is locked")
    object InvalidMasterPassword : VaultError("Invalid master password")
    object BiometricUnavailable : VaultError("Biometric unavailable")
    object VaultNotFound : VaultError("Vault not found")
    class Validation(val reason: String) : VaultError(reason)
    class InvalidFormat(detail: String) : VaultError("Invalid format: $detail")
    class CryptoFailure(cause: Throwable) : VaultError("Crypto failure: ${cause.message}", cause)
    class IOError(cause: Throwable) : VaultError("IO error: ${cause.message}", cause)
    class RateLimited(val retryAfterMs: Long) : VaultError("Too many attempts. Retry in ${retryAfterMs}ms")
    class Unknown(cause: Throwable) : VaultError("Unknown error: ${cause.message}", cause)
}

suspend inline fun <T> vaultCatching(crossinline block: suspend () -> T): VaultResult<T> = try {
    VaultResult.Success(block())
} catch (e: VaultError) {
    VaultResult.Failure(e)
} catch (ce: kotlinx.coroutines.CancellationException) {
    throw ce
} catch (e: Exception) {
    VaultResult.Failure(VaultError.Unknown(e))
}

fun <T> VaultResult<T>.getOrNull(): T? = (this as? VaultResult.Success)?.value
