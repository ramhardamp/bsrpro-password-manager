package pro.babasitaram.vault.presentation.navigation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.vaulthealth.VaultHealthCalculator
import pro.babasitaram.vault.core.util.isHiddenVault
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.presentation.files.hasFileMetadata

/** Drawer badge contract: 0 is hidden; 1..999 is exact; 1000+ is displayed as 999+. */
fun drawerBadgeText(count: Int): String? = when {
    count <= 0 -> null
    count >= 1000 -> "999+"
    else -> count.toString()
}

data class DrawerCounts(
    val vault: Int = 0,
    val totp: Int = 0,
    val healthIssues: Int = 0,
    val notes: Int = 0,
    val files: Int = 0,
    val mobiles: Int = 0,
    val bin: Int = 0,
    val sharing: Int = 0,
    val emergency: Int = 0
) {
    /** Badge number for a drawer route; 0 means "hide the badge". */
    fun forRoute(route: String): Int = when (route) {
        Routes.LIST -> vault
        Routes.TOTP -> totp
        Routes.HEALTH -> healthIssues
        Routes.NOTES -> notes
        Routes.FILES -> files
        Routes.MOBILES -> mobiles
        Routes.BIN -> bin
        Routes.SHARING -> sharing
        Routes.EMERGENCY -> emergency
        else -> 0
    }
}

/** Same feature filters as each screen's own ViewModel, computed once for the drawer badges. */
object DrawerCountsCalc {
    fun compute(entries: List<VaultEntry>, trashed: List<VaultEntry>, mobileCount: Int, now: Long = System.currentTimeMillis()): DrawerCounts {
        val live = entries.filter { it.deletedAt == 0L && !it.isFolderMarker }
        val health = VaultHealthCalculator.calculate(live, now)
        return DrawerCounts(
            vault = live.count { !it.isNote && !it.isHiddenVault && it.recordType.lowercase() !in setOf("note", "totp", "mobile") },
            totp = live.count { it.totp.isNotBlank() },
            healthIssues = health.uniqueIssueCount,
            notes = live.count { it.isNote || it.recordType.equals("note", true) },
            files = live.count { it.hasFileMetadata() },
            mobiles = mobileCount,
            bin = trashed.size
        )
    }
}

@HiltViewModel
class DrawerCountsViewModel @Inject constructor(
    repository: VaultRepository,
    shareRecords: pro.babasitaram.vault.core.security.ShareRecordStore,
    settings: pro.babasitaram.vault.domain.repository.SettingsRepository
) : ViewModel() {
    // computed off the main thread; StateFlow only re-emits when the numbers actually change
    val counts: StateFlow<DrawerCounts> = combine(
        repository.entries, repository.trashedEntries, repository.mobileCount, shareRecords.records, settings.settings
    ) { e, t, mobiles, shares, cfg ->
        val now = System.currentTimeMillis()
        DrawerCountsCalc.compute(e, t, mobiles, now).copy(
            sharing = shares.count { it.isActive(now) },
            // 1 = an emergency-access request is pending / active and needs attention
            emergency = if (cfg.emergencyActive || cfg.emergencyRequestTime > 0L) 1 else 0
        )
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DrawerCounts())
}
