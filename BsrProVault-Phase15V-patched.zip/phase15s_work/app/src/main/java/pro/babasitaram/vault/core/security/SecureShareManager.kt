package pro.babasitaram.vault.core.security

import android.net.Uri
import java.security.SecureRandom
import kotlinx.serialization.json.Json
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.VaultEntry

object SecureShareManager {
    const val SCHEME = "bsrpro"
    const val HOST = "share"
    const val DEFAULT_TTL_MS = 10L * 60L * 1000L
    const val MAX_TTL_MS = 7L * 24L * 60L * 60L * 1000L
    const val MIN_TTL_MS = 60_000L

    data class ShareOptions(
        val ttlMs: Long = DEFAULT_TTL_MS,
        val maxViews: Int = 1,
        val password: String = ""
    ) {
        fun normalized(): ShareOptions = copy(
            ttlMs = ttlMs.coerceIn(MIN_TTL_MS, MAX_TTL_MS),
            maxViews = if (maxViews <= 0) 0 else maxViews.coerceAtMost(100),
            password = password.trim()
        )
    }

    data class Envelope(
        val encrypted: String,
        val secret: String?,
        val expiry: Long,
        val maxViews: Int,
        val passwordProtected: Boolean,
        val fingerprint: String,
        val legacy: Boolean = false
    )

    suspend fun create(
        entry: VaultEntry,
        options: ShareOptions = ShareOptions(),
        now: Long = System.currentTimeMillis()
    ): String {
        val normalized = options.normalized()
        val payload = Json.encodeToString(VaultEntry.serializer(), entry)
        val expiry = now + normalized.ttlMs

        return if (normalized.password.isBlank()) {
            val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
            val random = SecureRandom()
            val secret = buildString(32) {
                repeat(32) { append(alphabet[random.nextInt(alphabet.length)]) }
            }
            val ciphertext = VaultCrypto.encrypt(payload, secret.toCharArray())
            Uri.Builder()
                .scheme(SCHEME)
                .authority(HOST)
                .fragment(
                    listOf(
                        "v2",
                        "n",
                        encode(ciphertext),
                        secret,
                        expiry.toString(),
                        normalized.maxViews.toString()
                    ).joinToString(".")
                )
                .build()
                .toString()
        } else {
            val ciphertext = VaultCrypto.encrypt(payload, normalized.password.toCharArray())
            Uri.Builder()
                .scheme(SCHEME)
                .authority(HOST)
                .fragment(
                    listOf(
                        "v2",
                        "p",
                        encode(ciphertext),
                        expiry.toString(),
                        normalized.maxViews.toString()
                    ).joinToString(".")
                )
                .build()
                .toString()
        }
    }

    fun parse(fragment: String?): Envelope? {
        val raw = fragment?.let(Uri::decode) ?: return null
        val parts = raw.split('.')

        // Legacy Phase 12 links: ciphertext.secret.expiry
        if (parts.size == 3) {
            val expiry = parts[2].toLongOrNull() ?: return null
            return Envelope(
                encrypted = decodeCiphertext(parts[0]),
                secret = parts[1],
                expiry = expiry,
                maxViews = 1,
                passwordProtected = false,
                fingerprint = fingerprint(raw),
                legacy = true
            )
        }

        if (parts.size !in 5..6 || parts[0] != "v2") return null
        val mode = parts[1]
        val encrypted = decodeCiphertext(parts[2])
        val expiry: Long
        val maxViews: Int

        return if (mode == "n" && parts.size == 6) {
            expiry = parts[4].toLongOrNull() ?: return null
            maxViews = parts[5].toIntOrNull() ?: return null
            Envelope(
                encrypted = encrypted,
                secret = parts[3],
                expiry = expiry,
                maxViews = maxViews.coerceAtLeast(0),
                passwordProtected = false,
                fingerprint = fingerprint(raw)
            )
        } else if (mode == "p" && parts.size == 5) {
            expiry = parts[3].toLongOrNull() ?: return null
            maxViews = parts[4].toIntOrNull() ?: return null
            Envelope(
                encrypted = encrypted,
                secret = null,
                expiry = expiry,
                maxViews = maxViews.coerceAtLeast(0),
                passwordProtected = true,
                fingerprint = fingerprint(raw)
            )
        } else {
            null
        }
    }

    suspend fun decryptEnvelope(
        envelope: Envelope,
        secret: String
    ): VaultEntry {
        val plain = VaultCrypto.decrypt(envelope.encrypted, secret.toCharArray())
        return Json.decodeFromString(VaultEntry.serializer(), plain)
    }

    fun decodeCiphertext(value: String): String {
        val normalized = value
            .replace('-', '+')
            .replace('_', '/')
        return normalized + "=".repeat((4 - normalized.length % 4) % 4)
    }

    private fun encode(value: String): String =
        value.replace('+', '-').replace('/', '_').trimEnd('=')

    private fun fingerprint(value: String): String =
        java.security.MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
}
