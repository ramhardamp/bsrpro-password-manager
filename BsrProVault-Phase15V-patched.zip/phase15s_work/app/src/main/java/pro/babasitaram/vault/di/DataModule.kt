package pro.babasitaram.vault.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStoreFile
import androidx.room.Room
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Named
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import pro.babasitaram.vault.core.crypto.MasterKeyManager
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.security.RateLimiter
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.core.util.DispatcherProvider
import pro.babasitaram.vault.data.local.blob.FileVaultBlobStore
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.data.local.db.VaultDao
import pro.babasitaram.vault.data.local.db.ActivityLogDatabase
import pro.babasitaram.vault.data.local.db.ActivityLogDao
import pro.babasitaram.vault.data.local.db.VaultDatabase
import pro.babasitaram.vault.data.local.preferences.BiometricCredentialStore
import pro.babasitaram.vault.data.local.preferences.EncryptedLockoutStore
import pro.babasitaram.vault.data.local.preferences.SettingsDataStore
import pro.babasitaram.vault.data.local.preferences.EncryptedSensitiveActionPinStore
import pro.babasitaram.vault.data.local.preferences.SensitiveActionPinStore
import pro.babasitaram.vault.data.local.preferences.WrappedBiometricCredentialStore
import pro.babasitaram.vault.data.repository.AuthRepositoryImpl
import pro.babasitaram.vault.data.repository.VaultRepositoryImpl
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository

@Module
@InstallIn(SingletonComponent::class)
object DataModule {

    @Provides
    @Singleton
    fun provideBlobStore(@ApplicationContext context: Context, dispatchers: DispatcherProvider): VaultBlobStore =
        FileVaultBlobStore(context.filesDir, dispatchers.io)

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): VaultDatabase =
        Room.inMemoryDatabaseBuilder(context, VaultDatabase::class.java).build()

    @Provides
    @Singleton
    fun provideDao(db: VaultDatabase): VaultDao = db.vaultDao()

    @Provides
    @Singleton
    fun provideActivityLogDatabase(@ApplicationContext context: Context): ActivityLogDatabase =
        Room.databaseBuilder(context, ActivityLogDatabase::class.java, "activity-log.db").build()

    @Provides
    @Singleton
    fun provideActivityLogDao(db: ActivityLogDatabase): ActivityLogDao = db.activityLogDao()

    @Provides
    @Singleton
    @Named("settings")
    fun provideSettingsStore(
        @ApplicationContext context: Context,
        @ApplicationScope scope: CoroutineScope
    ): DataStore<Preferences> =
        PreferenceDataStoreFactory.create(scope = scope) { context.preferencesDataStoreFile("settings") }

    @Provides
    @Singleton
    @Named("secure")
    fun provideSecureStore(
        @ApplicationContext context: Context,
        @ApplicationScope scope: CoroutineScope
    ): DataStore<Preferences> =
        PreferenceDataStoreFactory.create(scope = scope) { context.preferencesDataStoreFile("secure") }

    @Provides
    @Singleton
    fun provideSettingsRepository(@ApplicationContext context: Context, @Named("settings") store: DataStore<Preferences>): SettingsRepository =
        SettingsDataStore(store, context)

    @Provides
    @Singleton
    fun provideRateLimiter(
        @Named("secure") store: DataStore<Preferences>,
        @Named("settings") settingsStore: DataStore<Preferences>,
        keys: MasterKeyManager,
        @ApplicationContext context: Context
    ): RateLimiter {
        val settings = SettingsDataStore(settingsStore, context)
        return RateLimiter(
            EncryptedLockoutStore(store, keys),
            policy = { settings.current().let { it.lockoutMaxAttempts to it.lockoutSeconds * 1000L } }
        )
    }

    @Provides
    @Singleton
    @Named("hiddenPin")
    fun provideHiddenVaultPinStore(
        @Named("secure") store: DataStore<Preferences>,
        keys: MasterKeyManager
    ): SensitiveActionPinStore = EncryptedSensitiveActionPinStore(store, keys, "hidden_vault_pin_v1")

    @Provides
    @Singleton
    fun provideCredentialStore(@Named("secure") store: DataStore<Preferences>, keys: MasterKeyManager): BiometricCredentialStore =
        WrappedBiometricCredentialStore(store, keys)

    @Provides
    @Singleton
    fun provideSensitiveActionPinStore(
        @Named("secure") store: DataStore<Preferences>,
        keys: MasterKeyManager
    ): SensitiveActionPinStore = EncryptedSensitiveActionPinStore(store, keys)

    @Provides
    @Singleton
    fun provideAuthRepository(
        blobStore: VaultBlobStore,
        rateLimiter: RateLimiter,
        credentials: BiometricCredentialStore
    ): AuthRepository = AuthRepositoryImpl(blobStore, rateLimiter, credentials)

    @Provides
    @Singleton
    fun provideVaultRepository(blobStore: VaultBlobStore, session: SessionKeyStore, dao: VaultDao, activityLog: ActivityLogStore): VaultRepository =
        VaultRepositoryImpl(blobStore, session, dao, activityLog)
}
