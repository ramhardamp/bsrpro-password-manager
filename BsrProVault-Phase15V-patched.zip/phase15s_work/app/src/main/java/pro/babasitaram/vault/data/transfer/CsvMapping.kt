package pro.babasitaram.vault.data.transfer

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.IdGenerator
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.core.util.VaultError

/** Target fields a CSV column can be mapped to. */
enum class MapField(val label: String, val hints: List<String>) {
    TITLE("Title / name", listOf("name", "title", "site", "service", "account")),
    URL("Website URL", listOf("url", "website", "web site", "origin", "uri", "domain", "login_uri")),
    USERNAME("Username / email", listOf("username", "user", "login", "email", "e-mail")),
    PASSWORD("Password", listOf("password", "pass", "pwd", "secret")),
    NOTES("Notes", listOf("notes", "note", "comment", "extra", "description")),
    TOTP("TOTP secret", listOf("totp", "otpauth", "otp", "one-time")),
    MOBILE("Mobile number", listOf("mobile", "phone", "contact", "tel")),
    CATEGORY("Category", listOf("category", "folder", "group", "tag")),
    APP_PIN("App PIN", listOf("app_pin", "apppin", "pin"))
}

object CsvMapping {
    fun headers(text: String): List<String> = Csv.parse(text).firstOrNull()?.map { it.trim() }.orEmpty()

    fun sampleRow(text: String): List<String> = Csv.parse(text).getOrNull(1).orEmpty()

    /** field → column index, guessed from the header names (exact match preferred over "contains"). */
    fun autoDetect(headers: List<String>): Map<MapField, Int> {
        val lower = headers.map { it.trim().lowercase() }
        val used = HashSet<Int>()
        val out = LinkedHashMap<MapField, Int>()
        for (f in MapField.values()) {
            val idx = f.hints.firstNotNullOfOrNull { h -> lower.indexOf(h).takeIf { it >= 0 && it !in used } }
                ?: lower.indices.firstOrNull { i -> i !in used && f.hints.any { h -> lower[i].contains(h) } }
            if (idx != null) { out[f] = idx; used.add(idx) }
        }
        return out
    }

    fun parse(text: String, mapping: Map<MapField, Int>, now: Long = System.currentTimeMillis()): ParsedImport {
        if (text.length > ImportParser.MAX_CHARS) throw VaultError.Validation("Import file is too large (max 25 MB).")
        if (mapping.isEmpty() || (MapField.PASSWORD !in mapping && MapField.USERNAME !in mapping && MapField.MOBILE !in mapping && MapField.TOTP !in mapping)) {
            throw VaultError.Validation("Map at least a password, username, mobile or TOTP column.")
        }
        val rows = Csv.parse(text)
        if (rows.size < 2) throw VaultError.Validation("The file is empty or has no data rows.")
        val out = ArrayList<VaultEntry>()
        var skipped = 0
        for (r in rows.drop(1)) {
            fun v(f: MapField): String { val i = mapping[f] ?: return ""; return if (i < r.size) r[i] else "" }
            val password = v(MapField.PASSWORD)
            val username = v(MapField.USERNAME).trim()
            val mobile = v(MapField.MOBILE).trim()
            val totp = v(MapField.TOTP).trim()
            val url = v(MapField.URL).trim()
            val pin = v(MapField.APP_PIN).trim().filter { it in '0'..'9' }.take(6)
            if (password.isEmpty() && username.isEmpty() && mobile.isEmpty() && totp.isEmpty()) { skipped++; continue }
            if (out.size >= ImportParser.MAX_ENTRIES) throw VaultError.Validation("Import contains too many entries (max 10,000).")
            val title = v(MapField.TITLE).trim()
                .ifEmpty { UrlUtils.domainOf(url).substringBefore('.').replaceFirstChar { it.uppercase() } }
                .ifEmpty { if (username.isNotEmpty()) "Imported Login" else "Imported Entry" }
            out.add(
                VaultEntry(
                    id = IdGenerator.newId(now), title = title, url = url, username = username, password = password,
                    mobile = mobile, totp = totp, appPin = if (pin.length in 4..6) pin else "", notes = v(MapField.NOTES),
                    category = v(MapField.CATEGORY).trim().lowercase().ifEmpty { "other" },
                    createdAt = now, updatedAt = now
                )
            )
        }
        if (out.isEmpty()) throw VaultError.Validation("No rows could be imported with this mapping.")
        return ParsedImport(ImportFormat.GENERIC, out, skipped)
    }
}

/** Remembers a column mapping per header layout so the next file of the same shape needs no manual work. */
@Singleton
class ImportMappingStore @Inject constructor(@ApplicationContext context: Context) {
    private val prefs = context.getSharedPreferences("bsrpro_import_templates", Context.MODE_PRIVATE)

    private fun key(headers: List<String>) = "t_" + headers.joinToString("|") { it.trim().lowercase() }.hashCode()

    fun load(headers: List<String>): Map<MapField, Int>? {
        val raw = prefs.getString(key(headers), null) ?: return null
        val out = LinkedHashMap<MapField, Int>()
        raw.split(';').forEach { pair ->
            val f = pair.substringBefore('=')
            val i = pair.substringAfter('=', "").toIntOrNull() ?: return@forEach
            MapField.values().firstOrNull { it.name == f }?.let { if (i in headers.indices) out[it] = i }
        }
        return out.takeIf { it.isNotEmpty() }
    }

    fun save(headers: List<String>, mapping: Map<MapField, Int>) {
        prefs.edit().putString(key(headers), mapping.entries.joinToString(";") { "${it.key.name}=${it.value}" }).apply()
    }
}
