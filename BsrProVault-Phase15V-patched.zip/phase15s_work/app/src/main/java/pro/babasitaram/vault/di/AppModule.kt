package pro.babasitaram.vault.di

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import pro.babasitaram.vault.core.security.AndroidRootEnvironment
import pro.babasitaram.vault.core.security.RootDetector
import pro.babasitaram.vault.core.util.DefaultDispatcherProvider
import pro.babasitaram.vault.core.util.DispatcherProvider

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideDispatchers(): DispatcherProvider = DefaultDispatcherProvider()

    @Provides
    @Singleton
    @ApplicationScope
    fun provideApplicationScope(dispatchers: DispatcherProvider): CoroutineScope =
        CoroutineScope(SupervisorJob() + dispatchers.default)

    @Provides
    @Singleton
    fun provideRootDetector(@ApplicationContext context: Context): RootDetector =
        RootDetector(AndroidRootEnvironment(context))
}
