package pro.babasitaram.vault.core.crypto

import java.nio.CharBuffer
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * PBKDF2-HMAC-SHA256 over the password's UTF-8 bytes (what WebCrypto does in the extension).
 *
 * ASCII passwords use the platform provider (fast, encoding-independent). Non-ASCII passwords use an
 * explicit HMAC loop so the result never depends on how a provider encodes a char[] password.
 */
internal object Pbkdf2 {
    private const val HMAC = "HmacSHA256"

    fun deriveSha256(password: CharArray, salt: ByteArray, iterations: Int, keyLengthBytes: Int = 32): ByteArray =
        if (password.all { it.code < 0x80 }) {
            viaProvider(password, salt, iterations, keyLengthBytes)
        } else {
            viaManualHmac(password, salt, iterations, keyLengthBytes)
        }

    fun viaProvider(password: CharArray, salt: ByteArray, iterations: Int, keyLengthBytes: Int): ByteArray {
        val spec = PBEKeySpec(password, salt, iterations, keyLengthBytes * 8)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    /** Single-block PBKDF2 (output length == SHA-256 size == 32 bytes). */
    fun viaManualHmac(password: CharArray, salt: ByteArray, iterations: Int, keyLengthBytes: Int): ByteArray {
        require(keyLengthBytes == 32) { "Manual PBKDF2 supports 32-byte output only" }
        val pwBytes = utf8Bytes(password)
        try {
            val mac = Mac.getInstance(HMAC)
            mac.init(SecretKeySpec(pwBytes, HMAC))
            mac.update(salt)
            mac.update(byteArrayOf(0, 0, 0, 1))
            var u = mac.doFinal()
            val t = u.copyOf()
            for (i in 2..iterations) {
                u = mac.doFinal(u)
                for (j in t.indices) t[j] = (t[j].toInt() xor u[j].toInt()).toByte()
            }
            return t
        } finally {
            pwBytes.fill(0)
        }
    }

    fun utf8Bytes(chars: CharArray): ByteArray {
        val buffer = Charsets.UTF_8.encode(CharBuffer.wrap(chars))
        val out = ByteArray(buffer.remaining())
        buffer.get(out)
        if (buffer.hasArray()) buffer.array().fill(0)
        return out
    }
}
