package pro.babasitaram.vault.data.transfer

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.yield
import pro.babasitaram.vault.core.model.VaultEntry

enum class ExportKind(val label: String) {
    VAULT(".Vault (encrypted backup)"),
    CSV("CSV"),
    JSON("JSON (plain text)")
}

/** What goes into a manual export. Logins / passwords are always included. */
data class ExportOptions(
    val includeCards: Boolean = true,
    val includeNotes: Boolean = true,
    val includeIdentities: Boolean = true,
    val includeMobiles: Boolean = true,
    val includeTotp: Boolean = true,
    val includeAttachments: Boolean = true,
    val kind: ExportKind = ExportKind.VAULT,
    /** Only meaningful for CSV: encrypts the CSV text with the master password. .Vault is always encrypted, JSON never. */
    val encrypt: Boolean = true
) {
    /** true when the produced file can be read by anyone. */
    val isPlainText: Boolean get() = when (kind) {
        ExportKind.VAULT -> false
        ExportKind.JSON -> true
        ExportKind.CSV -> !encrypt
    }

    val legacyFormat: ExportFormat get() = when (kind) {
        ExportKind.VAULT -> ExportFormat.V3
        ExportKind.CSV -> ExportFormat.VAULT_CSV
        ExportKind.JSON -> ExportFormat.PLAIN_JSON
    }
}

data class ExportProgress(val done: Int, val total: Int, val stage: String)

/** Pure selection / stripping rules for [ExportOptions] so they can be unit-tested. */
object ExportFilter {
    private const val ATTACHMENT_PREFIX = "attachment_"

    fun includes(e: VaultEntry, o: ExportOptions): Boolean {
        val type = e.recordType.lowercase()
        return when {
            e.isNote || type == "note" -> o.includeNotes
            type == "card" -> o.includeCards
            type == "identity" -> o.includeIdentities
            type == "mobile" -> o.includeMobiles
            type == "totp" -> o.includeTotp
            else -> true
        }
    }

    fun shape(e: VaultEntry, o: ExportOptions): VaultEntry {
        var out = e
        if (!o.includeTotp && out.totp.isNotEmpty()) out = out.copy(totp = "")
        if (!o.includeAttachments && out.customFields.any { it.k.startsWith(ATTACHMENT_PREFIX) }) {
            out = out.copy(customFields = out.customFields.filterNot { it.k.startsWith(ATTACHMENT_PREFIX) })
        }
        return out
    }

    fun apply(entries: List<VaultEntry>, o: ExportOptions): List<VaultEntry> =
        entries.filter { includes(it, o) }.map { shape(it, o) }

    /** Same as [apply] but reports "X of Y" every few entries and honours cancellation. */
    suspend fun applyWithProgress(entries: List<VaultEntry>, o: ExportOptions, onProgress: (Int, Int) -> Unit): List<VaultEntry> {
        val selected = entries.filter { includes(it, o) }
        val out = ArrayList<VaultEntry>(selected.size)
        onProgress(0, selected.size)
        selected.forEachIndexed { i, e ->
            out.add(shape(e, o))
            if ((i + 1) % 20 == 0 || i == selected.lastIndex) {
                onProgress(i + 1, selected.size)
                currentCoroutineContext().ensureActive()
                yield()
            }
        }
        return out
    }

    fun fileName(o: ExportOptions, date: String): String = when (o.kind) {
        ExportKind.VAULT -> "BSRPRO_Backup_$date.Vault"
        ExportKind.JSON -> "BSRPRO_plain_$date.json"
        ExportKind.CSV -> if (o.encrypt) "BSRPRO_Vault_$date.csv.Vault" else "BSRPRO_Vault_$date.csv"
    }

    fun mime(o: ExportOptions): String = when {
        o.kind == ExportKind.JSON -> "application/json"
        o.kind == ExportKind.CSV && !o.encrypt -> "text/csv"
        else -> "application/octet-stream"
    }
}
