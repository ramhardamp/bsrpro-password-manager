package pro.babasitaram.vault.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase

/** Separate durable database: vault metadata DB intentionally remains in-memory. */
@Database(entities = [ActivityLogEntity::class], version = 1, exportSchema = false)
abstract class ActivityLogDatabase : RoomDatabase() {
    abstract fun activityLogDao(): ActivityLogDao
}
