@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
package pro.babasitaram.vault.presentation.notes

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import java.text.DateFormat
import java.util.Date
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.components.AppDimens

@Composable
fun NotesScreen(
    onBack: () -> Unit = {},
    onAdd: () -> Unit = {},
    onEdit: (String) -> Unit = {},
    onShare: (String) -> Unit = {},
    vm: NotesViewModel = hiltViewModel()
) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    BackHandler { onBack() }
    CollectMessages(vm.messages)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.p15_notes), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.p15_back)) } }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onAdd, icon = { Icon(Icons.Default.Add, null) }, text = { Text(stringResource(R.string.notes_new_note)) })
        }
    ) { padding ->
        if (entries.isEmpty()) {
            EmptyState(stringResource(R.string.p15_no_notes), stringResource(R.string.notes_empty_message), Modifier.padding(padding).fillMaxWidth())
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(AppDimens.ScreenHorizontal), verticalArrangement = Arrangement.spacedBy(AppDimens.ItemSpacing)) {
                items(entries, key = { it.id  }, contentType = { "item" }) { entry ->
                    NoteItem(entry, onOpen = {}, onEdit = { onEdit(entry.id) }, onCopy = { vm.copy(entry.notes) }, onDelete = { vm.delete(entry.id) }, onShare = { onShare(entry.id) })
                }
            }
        }
    }
}

@Composable
private fun NoteItem(
    entry: VaultEntry,
    onOpen: () -> Unit,
    onEdit: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    var view by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        Card(
            Modifier
                .fillMaxWidth()
                .combinedClickable(onClick = { view = true }, onLongClick = { menu = true })
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row {
                    Column(Modifier.weight(1f)) {
                        Text(entry.title.ifBlank { stringResource(R.string.p15_note) }, style = MaterialTheme.typography.titleMedium)
                        MarkdownPreview(entry.notes, style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        val noteDate = entry.updatedAt.takeIf { it > 0L } ?: entry.createdAt
                        if (noteDate > 0L) {
                            Text(
                                stringResource(R.string.notes_date, DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(noteDate))),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.notes_more)) }
                }
            }
        }

        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text(stringResource(R.string.p15_edit)) }, onClick = { menu = false; onEdit() })
            DropdownMenuItem(text = { Text(stringResource(R.string.p15_copy)) }, onClick = { menu = false; onCopy() })
            DropdownMenuItem(text = { Text(stringResource(R.string.p15_share)) }, onClick = { menu = false; onShare() })
            DropdownMenuItem(text = { Text(stringResource(R.string.p15_delete)) }, onClick = { menu = false; confirmDelete = true })
        }
    }
    if (view) {
        AlertDialog(
            onDismissRequest = { view = false },
            title = { Text(entry.title.ifBlank { stringResource(R.string.p15_note) }) },
            text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) { MarkdownPreview(entry.notes, maxLines = Int.MAX_VALUE, overflow = TextOverflow.Clip) } },
            confirmButton = { TextButton(onClick = { view = false; onEdit() }) { Text(stringResource(R.string.p15_edit)) } },
            dismissButton = { TextButton(onClick = { view = false }) { Text(stringResource(R.string.p15_close)) } }
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.notes_move_bin_title)) },
            text = { Text(stringResource(R.string.notes_move_bin_text)) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text(stringResource(R.string.notes_move_bin)) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}


@Composable
private fun MarkdownPreview(value: String, style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.bodyMedium, maxLines: Int = Int.MAX_VALUE, overflow: TextOverflow = TextOverflow.Clip) {
    androidx.compose.material3.Text(
        text = buildAnnotatedString {
            val lines = value.split("\n")
            lines.forEachIndexed { index, raw ->
                val line = raw.trimStart()
                val prefix = when {
                    line.startsWith("## ") -> line.removePrefix("## ")
                    line.startsWith("- ") -> "• " + line.removePrefix("- ")
                    else -> line
                }
                when {
                    raw.startsWith("## ") -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(prefix) }
                    else -> appendInlineMarkdown(prefix)
                }
                if (index < lines.lastIndex) append("\n")
            }
        },
        style = style,
        maxLines = maxLines,
        overflow = overflow
    )
}

private fun androidx.compose.ui.text.AnnotatedString.Builder.appendInlineMarkdown(text: String) {
    val regex = Regex("(\\*\\*[^*]+\\*\\*)|(\\*[^*]+\\*)|(`[^`]+`)")
    var cursor = 0
    regex.findAll(text).forEach { match ->
        append(text.substring(cursor, match.range.first))
        val token = match.value
        when {
            token.startsWith("**") -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(token.trim('*')) }
            token.startsWith("*") -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(token.trim('*')) }
            token.startsWith("`") -> withStyle(SpanStyle(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)) { append(token.trim('`')) }
        }
        cursor = match.range.last + 1
    }
    append(text.substring(cursor))
}
