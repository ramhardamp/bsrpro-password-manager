package pro.babasitaram.vault.presentation.backup

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler

import androidx.compose.ui.semantics.Role
import androidx.compose.material3.RadioButton
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.selectable
import pro.babasitaram.vault.presentation.components.PasswordField
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.DateFormat
import java.util.Date
import pro.babasitaram.vault.data.transfer.DuplicateAction
import pro.babasitaram.vault.data.transfer.ExportFormat
import pro.babasitaram.vault.data.transfer.ExportKind
import pro.babasitaram.vault.data.transfer.ExportOptions
import pro.babasitaram.vault.data.transfer.ImportMode
import pro.babasitaram.vault.data.transfer.MapField

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupScreen(onBack: () -> Unit, onImportContacts: () -> Unit = {}, vm: BackupViewModel = hiltViewModel()) {
    BackHandler { onBack() }
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var saveMime by remember { mutableStateOf("application/octet-stream") }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> vm.onImportFile(uri) }
    val exportTarget = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri: Uri? -> vm.onExportTarget(uri) }
    val backupFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }.onSuccess { vm.setBackupFolder(uri) }
                .onFailure { android.widget.Toast.makeText(context, context.getString(pro.babasitaram.vault.R.string.p17_folder_access_failed), android.widget.Toast.LENGTH_LONG).show() }
        }
    }

    LaunchedEffect(vm) {
        vm.events.collect { e ->
            when (e) {
                is BackupEvent.Message -> android.widget.Toast.makeText(context, e.text, android.widget.Toast.LENGTH_LONG).show()
                is BackupEvent.SaveFile -> { saveMime = e.mime; exportTarget.launch(e.fileName) }
            }
        }
    }

    val review = state.importing as? ImportStage.Review
    val mapStage = state.importing as? ImportStage.MapFields
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (review != null) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_review_import) else if (mapStage != null) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_map_columns) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_backup_import_title)) },
                navigationIcon = {
                    IconButton(onClick = { if (review != null || mapStage != null) vm.cancelImport() else onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037))
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (state.busy) CircularProgressIndicator(Modifier.padding(16.dp).align(Alignment.CenterHorizontally))
            when {
                review != null -> ReviewPane(review, vm)
                mapStage != null -> MapPane(mapStage, vm)
                else -> MainPane(
                    state, vm,
                    onPick = { importPicker.launch(arrayOf("*/*")) },
                    onPickMapped = { vm.requestMappedImport(); importPicker.launch(arrayOf("*/*")) },
                    onContacts = onImportContacts,
                    onChooseBackupFolder = { backupFolderPicker.launch(null) }
                )
            }
        }
    }

    state.exportOptions?.let { o ->
        ExportOptionsDialog(o, onChange = vm::updateExportOptions, onContinue = vm::continueExport, onCancel = vm::dismissExportOptions)
    }
    state.exportProgress?.let { p ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_038)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (p.total > 0) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_export_progress, p.done, p.total) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_preparing_export))
                    if (p.total > 0 && p.done < p.total) LinearProgressIndicator(progress = { p.done / p.total.toFloat() }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    if (p.total > 0 && p.done >= p.total) Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_039), style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = vm::cancelRunningExport) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
    state.exportAsk?.takeIf { state.exportProgress == null }?.let { format ->
        val plain = state.activeExport?.isPlainText ?: format.plaintext
        PasswordDialog(
            title = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_export_title, state.activeExport?.kind?.label ?: format.label),
            message = if (plain) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_plain_export_warning)
            else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_encrypted_export_prompt),
            confirmLabel = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_export),
            error = state.exportError,
            busy = state.busy,
            onConfirm = vm::confirmExport,
            onCancel = vm::cancelExport
        )
    }
    state.smartBackupPassword?.let { smart ->
        AlertDialog(
            onDismissRequest = vm::dismissSmartBackupPassword,
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_040)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_041))
                    OutlinedTextField(
                        value = smart,
                        onValueChange = {},
                        readOnly = true,
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    TextButton(
                        onClick = {
                            vm.copySecret(smart, "Backup password")
                        }
                    ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_042)) }
                }
            },
            confirmButton = { TextButton(onClick = vm::dismissSmartBackupPassword) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_043)) } }
        )
    }

    if (state.restoreAsk) {
        AlertDialog(
            onDismissRequest = { if (!state.busy) vm.cancelFolderRestore() },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_044), style = MaterialTheme.typography.titleLarge) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_045))
                var restorePassword by remember(state.restoreAsk) { mutableStateOf("") }
                PasswordField(value = restorePassword, onValueChange = { restorePassword = it }, label = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_046), enabled = !state.busy)
                state.restoreError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Button(onClick = { vm.confirmFolderRestore(restorePassword); restorePassword = "" }, enabled = restorePassword.isNotEmpty() && !state.busy, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_047)) }
            } },
            confirmButton = {},
            dismissButton = { TextButton(onClick = vm::cancelFolderRestore, enabled = !state.busy) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
    (state.importing as? ImportStage.NeedsBackupPassword)?.let { s ->
        PasswordDialog(
            title = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_041),
            message = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_backup_password_message),
            confirmLabel = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_047),
            error = s.error,
            busy = state.busy,
            onConfirm = vm::submitBackupPassword,
            onCancel = vm::cancelImport
        )
    }
}

@Composable
private fun MainPane(state: BackupUiState, vm: BackupViewModel, onPick: () -> Unit, onPickMapped: () -> Unit, onContacts: () -> Unit, onChooseBackupFolder: () -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_048), style = MaterialTheme.typography.titleMedium)
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_049), style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = vm::startFolderRestore, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_050)) }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_051), style = MaterialTheme.typography.titleMedium)
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_052), style = MaterialTheme.typography.bodySmall)
                Button(onClick = vm::openExportOptions, Modifier.fillMaxWidth(), enabled = !state.busy) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_053)) }
                OutlinedButton(onClick = vm::startSmartEncryptedExport, Modifier.fillMaxWidth(), enabled = !state.busy) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_054)) }
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_055), style = MaterialTheme.typography.bodySmall)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_056), style = MaterialTheme.typography.titleMedium)
                Text(
                    ".Vault backup, BSRPRO / Chrome / Edge / Bitwarden / LastPass / 1Password / Dashlane / KeePass / Firefox CSV, generic CSV, plain JSON or vCard. You review everything before it is added.",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = onPick, Modifier.fillMaxWidth(), enabled = !state.busy) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_057)) }
                OutlinedButton(onClick = onPickMapped, Modifier.fillMaxWidth(), enabled = !state.busy) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_058)) }
                OutlinedButton(onClick = onContacts, Modifier.fillMaxWidth(), enabled = !state.busy) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_059)) }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_060), style = MaterialTheme.typography.titleMedium)
                        Text(if (state.backupFolderUri.isBlank()) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_saves_default_backup) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_uses_selected_backup_folder), style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = state.autoBackupEnabled, onCheckedChange = vm::setAutoBackup)
                }
                OutlinedButton(onClick = onChooseBackupFolder, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) {
                    Text(if (state.backupFolderUri.isBlank()) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_choose_backup_folder) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_change_backup_folder))
                }
                if (state.backupFolderUri.isNotBlank()) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_061), style = MaterialTheme.typography.bodySmall)
                }
                Text(
                    androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_backup_security_note),
                    style = MaterialTheme.typography.bodySmall
                )
                if (state.lastAutoBackupAt > 0) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_backup_last, DateFormat.getDateTimeInstance().format(Date(state.lastAutoBackupAt))), style = MaterialTheme.typography.labelMedium)
                }
                OutlinedButton(onClick = vm::backupNow, enabled = !state.busy) { Text(stringResource(R.string.p15_back_up_now)) }
            }
        }
    }
}

@Composable
private fun ReviewPane(review: ImportStage.Review, vm: BackupViewModel) {
    val p = review.preview
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(p.format.label, style = MaterialTheme.typography.titleSmall)
            Text(
                "${p.newCount} new · ${p.duplicateCount} duplicate${if (p.duplicateCount == 1) "" else "s"}" +
                    if (p.skippedRows > 0) " · ${p.skippedRows} row(s) skipped" else "",
                style = MaterialTheme.typography.bodyMedium
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ImportMode.values().forEach { m ->
                    FilterChip(
                        selected = review.mode == m,
                        onClick = { vm.setImportMode(m) },
                        label = { Text(if (m == ImportMode.MERGE) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_merge) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_replace)) }
                    )
                }
            }
            Text(
                if (review.mode == ImportMode.MERGE) "Merge: your current entries stay; new ones are added and duplicates follow the choice below."
                else "Replace: every current entry moves to the Bin (restorable for 30 days), then these entries are imported.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (p.duplicateCount > 0 && review.mode == ImportMode.MERGE) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { vm.setAllDuplicates(DuplicateAction.SKIP) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_062)) }
                    TextButton(onClick = { vm.setAllDuplicates(DuplicateAction.REPLACE) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_063)) }
                    TextButton(onClick = { vm.setAllDuplicates(DuplicateAction.KEEP_BOTH) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_064)) }
                }
                Row(Modifier.clickable { vm.setApplyToAll(!review.applyToAll) }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = review.applyToAll, onCheckedChange = null)
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_065), modifier = Modifier.padding(start = 8.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(p.items, key = { index, _ -> index }) { index, item ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(item.entry.title, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        listOf(item.entry.username.ifEmpty { item.entry.mobile }, item.entry.url).filter { it.isNotEmpty() }.joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (item.duplicateOf != null && review.mode == ImportMode.MERGE) {
                        val action = review.actions[index] ?: DuplicateAction.SKIP
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_066), style = MaterialTheme.typography.labelSmall)
                        Column(Modifier.selectableGroup()) {
                            DuplicateAction.values().forEach { a ->
                                Row(
                                    Modifier.fillMaxWidth().selectable(
                                        selected = action == a,
                                        onClick = { vm.setAction(index, a) },
                                        role = Role.RadioButton
                                    ).padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = action == a, onClick = null)
                                    Text(
                                        when (a) { DuplicateAction.SKIP -> "Skip"; DuplicateAction.REPLACE -> "Replace existing"; DuplicateAction.KEEP_BOTH -> "Keep both" },
                                        modifier = Modifier.padding(start = 8.dp)
                                    )
                                }
                            }
                        }
                    } else {
                        Text(stringResource(R.string.p15_new), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                HorizontalDivider()
            }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = vm::cancelImport, Modifier.weight(1f)) { Text(stringResource(R.string.p15_cancel)) }
            Button(onClick = vm::askConfirmImport, Modifier.weight(1f)) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_056)) }
        }
    }
    if (review.confirm) {
        AlertDialog(
            onDismissRequest = vm::dismissConfirmImport,
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_import_entries_count, p.items.size)) },
            text = {
                Text(
                    "${p.items.size} entries found: ${p.newCount} new, ${p.duplicateCount} duplicate${if (p.duplicateCount == 1) "" else "s"}." +
                        if (review.mode == ImportMode.REPLACE) "\n\nAll current entries will first move to the Bin." else ""
                )
            },
            confirmButton = { TextButton(onClick = vm::confirmImport) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_056)) } },
            dismissButton = { TextButton(onClick = vm::dismissConfirmImport) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}

@Composable
private fun MapPane(s: ImportStage.MapFields, vm: BackupViewModel) {
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text(
                    "Match each BSRPRO field to a column of your file. Columns were detected automatically; change any that are wrong.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            items(MapField.values().toList(), key = { it.name  }, contentType = { "item" }) { f -> ColumnPicker(f, s, vm) }
            item {
                Row(Modifier.clickable { vm.setSaveTemplate(!s.saveTemplate) }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = s.saveTemplate, onCheckedChange = null)
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_067), modifier = Modifier.padding(start = 8.dp))
                }
            }
            s.error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = vm::cancelImport, Modifier.weight(1f)) { Text(stringResource(R.string.p15_cancel)) }
            Button(onClick = vm::confirmMapping, Modifier.weight(1f)) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_068)) }
        }
    }
}

@Composable
private fun ColumnPicker(f: MapField, s: ImportStage.MapFields, vm: BackupViewModel) {
    var open by remember { mutableStateOf(false) }
    val idx = s.mapping[f]
    val secret = f == MapField.PASSWORD || f == MapField.TOTP || f == MapField.APP_PIN
    Column {
        Text(f.label, style = MaterialTheme.typography.labelLarge)
        Box {
            OutlinedButton(onClick = { open = true }, Modifier.fillMaxWidth()) {
                Text(if (idx == null) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_069) else s.headers.getOrElse(idx) { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_column, idx + 1) }.ifBlank { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_column, idx + 1) })
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_069)) }, onClick = { open = false; vm.setColumn(f, null) })
                s.headers.forEachIndexed { i, h ->
                    DropdownMenuItem(text = { Text(h.ifBlank { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_column, i + 1) }) }, onClick = { open = false; vm.setColumn(f, i) })
                }
            }
        }
        if (idx != null) {
            val value = s.sample.getOrNull(idx).orEmpty()
            if (value.isNotEmpty()) Text(
                "e.g. " + if (secret) "••••••" else value.take(40),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ExportOptionsDialog(
    o: ExportOptions,
    onChange: ((ExportOptions) -> ExportOptions) -> Unit,
    onContinue: () -> Unit,
    onCancel: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_070)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_071), style = MaterialTheme.typography.bodySmall)
                OptionCheck("Cards", o.includeCards) { v -> onChange { it.copy(includeCards = v) } }
                OptionCheck("Notes", o.includeNotes) { v -> onChange { it.copy(includeNotes = v) } }
                OptionCheck("Identities", o.includeIdentities) { v -> onChange { it.copy(includeIdentities = v) } }
                OptionCheck("Mobile numbers", o.includeMobiles) { v -> onChange { it.copy(includeMobiles = v) } }
                OptionCheck("TOTP secrets", o.includeTotp) { v -> onChange { it.copy(includeTotp = v) } }
                OptionCheck("Attachments (references)", o.includeAttachments) { v -> onChange { it.copy(includeAttachments = v) } }
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_072), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                ExportKind.values().forEach { k ->
                    Row(
                        Modifier.fillMaxWidth().selectable(selected = o.kind == k, onClick = { onChange { it.copy(kind = k) } }, role = Role.RadioButton).padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = o.kind == k, onClick = null)
                        Text(k.label, modifier = Modifier.padding(start = 8.dp))
                    }
                }
                if (o.kind == ExportKind.CSV) {
                    OptionCheck("Encrypt CSV with my master password", o.encrypt) { v -> onChange { it.copy(encrypt = v) } }
                }
                Text(
                    when {
                        o.kind == ExportKind.VAULT -> "Encrypted with your master password. The BSRPRO extension can open it."
                        o.kind == ExportKind.CSV && o.encrypt -> "Saved as .csv.Vault. Only BSRPRO can open it (Import from file)."
                        else -> "This file will NOT be encrypted. Anyone who gets it can read your passwords."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (o.isPlainText) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = onContinue) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_073)) } },
        dismissButton = { TextButton(onClick = onCancel) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun OptionCheck(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = null)
        Text(label, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
internal fun PasswordDialog(
    title: String,
    message: String,
    confirmLabel: String,
    error: String?,
    busy: Boolean,
    onConfirm: (String) -> Unit,
    onCancel: () -> Unit
) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { if (!busy) onCancel() },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(message, style = MaterialTheme.typography.bodyMedium)
                PasswordField(value = pw, onValueChange = { pw = it }, label = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_074), enabled = !busy)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(pw); pw = "" }, enabled = pw.isNotEmpty() && !busy) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onCancel, enabled = !busy) { Text(stringResource(R.string.p15_cancel)) } }
    )
}
