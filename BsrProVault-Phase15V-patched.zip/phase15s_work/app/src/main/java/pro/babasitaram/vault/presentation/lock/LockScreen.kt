@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.lock

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.presentation.components.PasswordField
import pro.babasitaram.vault.presentation.util.findFragmentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*

@Composable
fun LockScreen(vm: LockViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var password by rememberSaveable { mutableStateOf("") }
    val activity = LocalContext.current.findFragmentActivity()
    var autoPrompted by rememberSaveable { mutableStateOf(false) }
    var emergencyOpen by rememberSaveable { mutableStateOf(false) }
    var emergencyKey by rememberSaveable { mutableStateOf("") }
    var recoveryOpen by rememberSaveable { mutableStateOf(false) }
    var recoveryKey by rememberSaveable { mutableStateOf("") }
    var recoveryNew by rememberSaveable { mutableStateOf("") }
    var recoveryConfirm by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(state.biometricAvailable) {
        if (state.biometricAvailable && !autoPrompted && activity != null) {
            autoPrompted = true
            vm.unlockWithBiometric(activity)
        }
    }

    val locked = state.lockedSeconds > 0
    Scaffold { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(pro.babasitaram.vault.R.drawable.brand_logo),
                contentDescription = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_brand_accessibility),
                modifier = Modifier.size(88.dp)
            )
            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_087), style = MaterialTheme.typography.headlineMedium)
            PasswordField(password, { password = it }, "Master password", enabled = !state.busy && !locked)
            if (locked) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_unlock_retry, state.lockedSeconds), color = MaterialTheme.colorScheme.error)
            } else {
                state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
            Button(
                onClick = { vm.unlock(password); password = "" },
                enabled = password.isNotEmpty() && !state.busy && !locked,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (state.busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text(stringResource(R.string.p15_unlock))
            }
            if (state.biometricAvailable && activity != null) {
                TextButton(onClick = { vm.unlockWithBiometric(activity) }, enabled = !state.busy && !locked) {
                    Icon(Icons.Default.Fingerprint, contentDescription = null)
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_088))
                }
            }
            if (state.emergencyConfigured) {
                TextButton(onClick = { emergencyOpen = true }, enabled = !state.busy && !locked) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_089))
                }
            }
            TextButton(
                onClick = { recoveryOpen = true },
                enabled = !state.busy && !locked
            ) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_090))
            }
        }
    }

    if (recoveryOpen) {
        AlertDialog(
            onDismissRequest = { if (!state.busy) { recoveryOpen = false; recoveryKey = ""; recoveryNew = ""; recoveryConfirm = "" } },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_091), style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_092))
                    PasswordField(recoveryKey, { recoveryKey = it.uppercase().filter(Char::isLetterOrDigit).take(24) }, "Recovery key", enabled = !state.busy)
                    PasswordField(recoveryNew, { recoveryNew = it }, "New master password", enabled = !state.busy)
                    PasswordField(recoveryConfirm, { recoveryConfirm = it }, "Confirm new password", enabled = !state.busy)
                    state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = recoveryKey.length == 24 && recoveryNew.isNotEmpty() && recoveryConfirm.isNotEmpty() && !state.busy,
                    onClick = { vm.recoverMasterPassword(recoveryKey, recoveryNew, recoveryConfirm) }
                ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_093)) }
            },
            dismissButton = {
                TextButton(
                    onClick = { recoveryOpen = false; recoveryKey = ""; recoveryNew = ""; recoveryConfirm = "" },
                    enabled = !state.busy
                ) { Text(stringResource(R.string.p15_cancel)) }
            }
        )
    }

    if (emergencyOpen) {
        val requestAt = state.emergencyRequestTime
        val unlockAt = requestAt + pro.babasitaram.vault.domain.usecase.EmergencyAccessUseCase.WAIT_MS
        val ready = requestAt > 0L && System.currentTimeMillis() >= unlockAt
        AlertDialog(
            onDismissRequest = { if (!state.busy) emergencyOpen = false },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_089), style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (requestAt == 0L) stringResource(pro.babasitaram.vault.R.string.p17_emergency_start_message) else if (!ready) stringResource(pro.babasitaram.vault.R.string.p17_emergency_pending) else stringResource(pro.babasitaram.vault.R.string.p17_emergency_complete))
                    PasswordField(emergencyKey, { emergencyKey = it }, "Emergency key", enabled = !state.busy)
                    if (!ready && requestAt > 0L) Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_unlock_at, java.text.DateFormat.getDateTimeInstance().format(java.util.Date(unlockAt))))
                    state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = emergencyKey.filter(Char::isLetterOrDigit).length == 24 && !state.busy,
                    onClick = {
                        if (requestAt == 0L) vm.requestEmergency(emergencyKey) else if (ready) vm.unlockEmergency(emergencyKey)
                    }
                ) { Text(if (requestAt == 0L) stringResource(pro.babasitaram.vault.R.string.p17_start_72h) else stringResource(pro.babasitaram.vault.R.string.p17_unlock)) }
            },
            dismissButton = { TextButton(onClick = { emergencyOpen = false }, enabled = !state.busy) { Text(stringResource(R.string.p15_close)) } }
        )
    }
}
