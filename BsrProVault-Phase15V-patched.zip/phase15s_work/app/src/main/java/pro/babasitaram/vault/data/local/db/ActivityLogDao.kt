package pro.babasitaram.vault.data.local.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityLogDao {
    @Insert
    suspend fun insert(item: ActivityLogEntity)

    @Insert
    suspend fun insertAll(items: List<ActivityLogEntity>)

    @Query("SELECT * FROM activity_log ORDER BY timestamp DESC, id DESC LIMIT :limit")
    fun observeLatest(limit: Int): Flow<List<ActivityLogEntity>>

    @Query("DELETE FROM activity_log")
    suspend fun clear()
}
