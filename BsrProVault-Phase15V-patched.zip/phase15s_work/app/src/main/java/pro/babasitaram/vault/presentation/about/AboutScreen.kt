@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.about

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import pro.babasitaram.vault.BuildConfig
import pro.babasitaram.vault.core.constants.AppLinks

@Composable
fun AboutScreen(onBack: () -> Unit = {}) {
    val context = LocalContext.current
    fun open(url: String) { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }
    BackHandler { onBack() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_174), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }
            )
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_175), style = MaterialTheme.typography.titleLarge)
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_about_version, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE), style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_176))
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(vertical = 6.dp)) {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_177), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(16.dp, 10.dp, 16.dp, 2.dp))
                        Text(AppLinks.DEVELOPER, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(horizontal = 16.dp))
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_178), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp, 0.dp, 16.dp, 8.dp))
                        HorizontalDivider()
                        LinkRow("Website", AppLinks.WEBSITE) { open(AppLinks.WEBSITE) }
                        LinkRow("Email", AppLinks.EMAIL) { open("mailto:${AppLinks.EMAIL}") }
                        LinkRow("GitHub", AppLinks.GITHUB) { open(AppLinks.GITHUB) }
                        LinkRow("Support (UPI)", AppLinks.UPI_ID) { open("upi://pay?pa=${AppLinks.UPI_ID}&pn=BabaSitaRam%20Pro") }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(vertical = 6.dp)) {
                        LinkRow("License", "Source code license") { open(AppLinks.GITHUB_LICENSE) }
                        LinkRow("Changelog", "What's new") { open(AppLinks.CHANGELOG) }
                        LinkRow("Privacy Policy", "How your data is handled") { open(AppLinks.PRIVACY) }
                    }
                }
            }
            item { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_179), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.fillMaxWidth().padding(8.dp)) }
        }
    }
}

@Composable
private fun LinkRow(title: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}
