package pro.babasitaram.vault.presentation.theme

import androidx.compose.ui.graphics.Color

val AccentPurple = Color(0xFFA78BFA)
val AccentOrange = Color(0xFFF59E0B)
val DarkBackground = Color(0xFF14121F)
val DarkSurface = Color(0xFF1E1B2E)
val LightBackground = Color(0xFFFAF9FF)
val LightSurface = Color(0xFFFFFFFF)
