package pro.babasitaram.vault.core.constants

import javax.inject.Inject
import javax.inject.Singleton

/** Tiny Hilt-injected class; proves DI wiring works in Phase 0. */
@Singleton
class AppInfo @Inject constructor() {
    val name: String = VaultConstants.APP_NAME
    val kdfLabel: String = "${VaultConstants.V3_KDF} · ${VaultConstants.PBKDF2_ITERATIONS}"
}
