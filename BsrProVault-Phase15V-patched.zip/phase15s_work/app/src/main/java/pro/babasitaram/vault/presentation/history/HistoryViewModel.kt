package pro.babasitaram.vault.presentation.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions
import pro.babasitaram.vault.presentation.util.launchCatching

@HiltViewModel
class HistoryViewModel @Inject constructor(
    repository: VaultRepository,
    private val saveEntry: SaveEntryUseCase,
    private val clipboard: ClipboardActions
) : ViewModel() {
    enum class Filter { ALL, PASSWORDS, EDITS }
    private val filter = MutableStateFlow(Filter.ALL)
    val filterState: StateFlow<Filter> = filter.asStateFlow()
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    val entries: StateFlow<List<VaultEntry>> = combine(repository.entries, filter) { values, selectedFilter ->
        when (selectedFilter) {
            Filter.ALL -> values.filter { it.deletedAt == 0L && (it.passwordHistory.isNotEmpty() || it.editHistory.isNotEmpty()) }
            Filter.PASSWORDS -> values.filter { it.deletedAt == 0L && it.passwordHistory.isNotEmpty() }
            Filter.EDITS -> values.filter { it.deletedAt == 0L && it.editHistory.isNotEmpty() }
        }
    }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setFilter(value: Filter) { filter.value = value }

    fun restorePassword(entry: VaultEntry, password: String) {
        if (password.isBlank()) return
        launchCatching {
            when (val result = saveEntry(entry.copy(password = password), existing = entry)) {
                is VaultResult.Success -> _messages.send("Previous password restored")
                is VaultResult.Failure -> _messages.send(result.error.message ?: "Could not restore password")
                VaultResult.Loading -> Unit
            }
        }
    }

    fun copy(value: String, label: String) {
        launchCatching { _messages.send(clipboard.copy(value, label)) }
    }
}
