package pro.babasitaram.vault.presentation.theme

import androidx.compose.material3.Typography

/** Central typography: Compose resolves text direction from LocalLayoutDirection. */
val VaultTypography = Typography()
