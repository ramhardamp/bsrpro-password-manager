package pro.babasitaram.vault.autofill

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.autofill.AutofillManager

object AutofillStatus {
    /** True when BSRPRO Vault is the autofill service the user selected. */
    fun isEnabled(context: Context): Boolean =
        runCatching { context.getSystemService(AutofillManager::class.java)?.hasEnabledAutofillServices() == true }
            .getOrDefault(false)

    fun enableIntent(context: Context): Intent =
        Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE, Uri.parse("package:${context.packageName}"))

    fun fallbackIntent(): Intent = Intent(Settings.ACTION_SETTINGS)
}
