package pro.babasitaram.vault.data.local.blob

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.crypto.DerivedVaultKey
import pro.babasitaram.vault.core.crypto.Pbkdf2
import pro.babasitaram.vault.core.crypto.V3PayloadParser
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultJson
import pro.babasitaram.vault.core.model.VaultPayload
import pro.babasitaram.vault.core.util.VaultError

interface VaultBlobStore {
    suspend fun exists(): Boolean
    suspend fun read(password: CharArray): VaultData
    suspend fun write(data: VaultData, password: CharArray)
    suspend fun readRaw(): String?
    suspend fun writeRaw(blob: String)
    suspend fun deleteAll()

    /** Remove the .bak / .bak2 copies (they are still encrypted with the *previous* password after a password change). */
    suspend fun deleteBackups()

    /** Forget the cached derived key (call on lock). */
    fun invalidateKeyCache()
}

/**
 * vault.blob = base64(salt16 || iv12 || AES-256-GCM(payload JSON)) — the extension's legacy vault format.
 * Writes are atomic (tmp + fsync + rename) and the previous two versions are kept as .bak / .bak2.
 */
fun interface VaultWriteHooks {
    fun before(step: Step)

    enum class Step { TEMP_WRITE, BACKUP_ROTATE, ATOMIC_MOVE, FALLBACK_MOVE }
}

object NoopVaultWriteHooks : VaultWriteHooks {
    override fun before(step: VaultWriteHooks.Step) = Unit
}

class FileVaultBlobStore(
    private val dir: File,
    private val dispatcher: CoroutineDispatcher,
    private val writeHooks: VaultWriteHooks = NoopVaultWriteHooks
) : VaultBlobStore {

    private val main = File(dir, "vault.blob")
    private val tmp = File(dir, "vault.blob.tmp")
    private val bak1 = File(dir, "vault.blob.bak")
    private val bak2 = File(dir, "vault.blob.bak2")
    private val mutex = Mutex()

    private class KeyCache(val fingerprint: ByteArray, val dk: DerivedVaultKey)

    @Volatile
    private var cache: KeyCache? = null

    override suspend fun exists(): Boolean = withContext(dispatcher) { main.exists() || bak1.exists() }

    override suspend fun read(password: CharArray): VaultData = mutex.withLock {
        var formatError: VaultError? = null
        var result: VaultData? = null
        for (file in listOf(main, bak1, bak2)) {
            if (result != null) break
            if (!withContext(dispatcher) { file.exists() }) continue
            try {
                result = readFile(file, password)
            } catch (e: VaultError.InvalidFormat) {
                // corrupted file: try the previous version. A wrong password is NOT retried on backups.
                formatError = e
            }
        }
        result ?: throw (formatError ?: VaultError.VaultNotFound)
    }

    private suspend fun readFile(file: File, password: CharArray): VaultData {
        val text = ioCall { file.readText(Charsets.UTF_8) }.trim()
        val (plain, dk) = VaultCrypto.decryptWithKeyInfo(text, password)
        cache = KeyCache(fingerprint(password, dk.salt), dk)
        return toVaultData(plain)
    }

    override suspend fun write(data: VaultData, password: CharArray) = mutex.withLock {
        val dk = obtainKey(password)
        val json = VaultJson.encodeToString(VaultPayload.serializer(), VaultPayload(entries = data.entries, folders = data.folders))
        val blob = VaultCrypto.encryptWithKey(json, dk)
        atomicWrite(blob)
    }

    private suspend fun obtainKey(password: CharArray): DerivedVaultKey {
        val c = cache
        if (c != null && MessageDigest.isEqual(c.fingerprint, fingerprint(password, c.dk.salt))) return c.dk
        val fresh = VaultCrypto.deriveNewVaultKey(password)
        cache = KeyCache(fingerprint(password, fresh.salt), fresh)
        return fresh
    }

    private fun fingerprint(password: CharArray, salt: ByteArray): ByteArray {
        val bytes = Pbkdf2.utf8Bytes(password)
        try {
            return MessageDigest.getInstance("SHA-256").apply { update(salt); update(bytes) }.digest()
        } finally {
            bytes.fill(0)
        }
    }

    private suspend fun atomicWrite(blob: String): Unit = ioCall {
        dir.mkdirs()
        writeHooks.before(VaultWriteHooks.Step.TEMP_WRITE)
        FileOutputStream(tmp).use { out ->
            out.write(blob.toByteArray(Charsets.UTF_8))
            out.flush()
            out.fd.sync()
        }
        if (main.exists()) {
            writeHooks.before(VaultWriteHooks.Step.BACKUP_ROTATE)
            if (bak1.exists()) bak1.copyTo(bak2, overwrite = true)
            main.copyTo(bak1, overwrite = true)
        }
        try {
            writeHooks.before(VaultWriteHooks.Step.ATOMIC_MOVE)
            Files.move(tmp.toPath(), main.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            Unit
        } catch (e: AtomicMoveNotSupportedException) {
            writeHooks.before(VaultWriteHooks.Step.FALLBACK_MOVE)
            if (!tmp.renameTo(main)) throw IOException("rename failed")
            Unit
        }
        Unit
    }

    override suspend fun readRaw(): String? = mutex.withLock {
        ioCall { if (main.exists()) main.readText(Charsets.UTF_8).trim() else null }
    }

    override suspend fun writeRaw(blob: String) = mutex.withLock { atomicWrite(blob) }

    override suspend fun deleteAll() = mutex.withLock {
        cache = null
        ioCall { listOf(main, tmp, bak1, bak2).forEach { it.delete() } }
        Unit
    }

    override suspend fun deleteBackups() = mutex.withLock {
        ioCall { listOf(bak1, bak2).forEach { it.delete() } }
        Unit
    }

    override fun invalidateKeyCache() {
        cache = null
    }

    private fun toVaultData(plaintext: String): VaultData {
        val r = V3PayloadParser.parse(plaintext)
        return VaultData(r.entries, r.folders)
    }

    private suspend fun <T> ioCall(block: () -> T): T = withContext(dispatcher) {
        try {
            block()
        } catch (e: IOException) {
            throw VaultError.IOError(e)
        }
    }
}
