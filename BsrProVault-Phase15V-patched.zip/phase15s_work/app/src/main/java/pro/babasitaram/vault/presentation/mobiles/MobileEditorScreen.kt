@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.mobiles

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun MobileEditorScreen(
    onDone: () -> Unit,
    vm: MobileEditorViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    BackHandler(enabled = !state.saving) { onDone() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(if (state.existing == null) R.string.mobile_add_title else R.string.mobile_edit_title), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onDone, enabled = !state.saving) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.mobile_back)) } },
                actions = { Button(onClick = vm::save, enabled = !state.saving && !state.saved) { Text(stringResource(R.string.p15_save)) } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            OutlinedTextField(state.title, vm::setTitle, label = { Text(stringResource(R.string.p15_title)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(state.number, vm::setNumber, label = { Text(stringResource(R.string.mobile_number_label)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            var operatorOpen by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { operatorOpen = true }, Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.mobile_operator_label, state.operator.ifBlank { stringResource(R.string.mobile_operator_not_set) }))
                }
                DropdownMenu(expanded = operatorOpen, onDismissRequest = { operatorOpen = false }) {
                    MOBILE_OPERATORS.forEach { op ->
                        DropdownMenuItem(text = { Text(op) }, onClick = { operatorOpen = false; vm.setOperator(op) })
                    }
                }
            }
            Text(stringResource(R.string.p15_category), style = MaterialTheme.typography.labelLarge)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(MOBILE_CATEGORIES) { c ->
                    FilterChip(selected = state.category == c, onClick = { vm.setCategory(c) }, label = { Text(c.replaceFirstChar { it.uppercase() }) })
                }
            }
            OutlinedTextField(state.tags, vm::setTags, label = { Text(stringResource(R.string.mobile_tags_label)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.p15_starred), Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                Switch(checked = state.starred, onCheckedChange = vm::setStarred)
            }
            OutlinedTextField(state.notes, vm::setNotes, label = { Text(stringResource(R.string.p15_notes)) }, minLines = 4, modifier = Modifier.fillMaxWidth())
        }
    }
}
