package pro.babasitaram.vault.core.crypto

import android.os.SystemClock
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import pro.babasitaram.vault.core.util.VaultError

/**
 * Process-local vault session. The master password is never persisted here.
 * A session has an absolute expiry so keeping the app open cannot bypass the configured limit.
 */
@Singleton
class SessionKeyStore @Inject constructor() {
    private val lock = Any()
    private var password: CharArray? = null
    private var expiresAtElapsedMs: Long = 0L
    private var expiresAtWallMs: Long = 0L
    private val _unlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _unlocked.asStateFlow()

    fun unlock(
        master: CharArray,
        sessionSeconds: Int = DEFAULT_SESSION_SECONDS,
        nowElapsedMs: Long = SystemClock.elapsedRealtime(),
        nowWallMs: Long = System.currentTimeMillis()
    ) = synchronized(lock) {
        password?.fill('\u0000')
        password = master.copyOf()
        val durationMs = sessionSeconds.toDurationMs()
        expiresAtElapsedMs = if (durationMs == Long.MAX_VALUE) Long.MAX_VALUE else nowElapsedMs + durationMs
        expiresAtWallMs = if (durationMs == Long.MAX_VALUE) Long.MAX_VALUE else nowWallMs + durationMs
        _unlocked.value = true
    }

    /** Restore a process-local session from an already authenticated persistent credential. */
    fun restore(
        master: CharArray,
        expiresAtWallMs: Long,
        nowElapsedMs: Long = SystemClock.elapsedRealtime(),
        nowWallMs: Long = System.currentTimeMillis()
    ): Boolean = synchronized(lock) {
        if (expiresAtWallMs != Long.MAX_VALUE && (expiresAtWallMs <= nowWallMs || nowWallMs < 0L)) {
            password?.fill('\u0000')
            password = null
            expiresAtElapsedMs = 0L
            this@SessionKeyStore.expiresAtWallMs = 0L
            _unlocked.value = false
            return false
        }
        password?.fill('\u0000')
        password = master.copyOf()
        val remaining = if (expiresAtWallMs == Long.MAX_VALUE) Long.MAX_VALUE else (expiresAtWallMs - nowWallMs).coerceAtLeast(1L)
        expiresAtElapsedMs = if (remaining == Long.MAX_VALUE) Long.MAX_VALUE else nowElapsedMs + remaining
        this@SessionKeyStore.expiresAtWallMs = expiresAtWallMs
        _unlocked.value = true
        true
    }

    fun sessionRemainingMs(nowElapsedMs: Long = SystemClock.elapsedRealtime()): Long = synchronized(lock) {
        if (!_unlocked.value) return 0L
        if (expiresAtElapsedMs == Long.MAX_VALUE) return Long.MAX_VALUE
        (expiresAtElapsedMs - nowElapsedMs).coerceAtLeast(0L)
    }

    fun sessionExpiresAtWallMs(): Long = synchronized(lock) { expiresAtWallMs }

    fun hasValidSession(nowElapsedMs: Long = SystemClock.elapsedRealtime()): Boolean = synchronized(lock) {
        if (!_unlocked.value) return false
        if (expiresAtElapsedMs == Long.MAX_VALUE) return true
        if (nowElapsedMs < expiresAtElapsedMs) return true
        clearLocked()
        false
    }

    /** Runs [block] with a temporary copy which is wiped afterwards. */
    suspend fun <T> withPassword(block: suspend (CharArray) -> T): T {
        val copy = synchronized(lock) {
            if (!_unlocked.value || isExpiredLocked(SystemClock.elapsedRealtime())) {
                clearLocked()
                null
            } else {
                password?.copyOf()
            }
        } ?: throw VaultError.VaultLocked
        try {
            return block(copy)
        } finally {
            copy.fill('\u0000')
        }
    }

    fun lock() = synchronized(lock) { clearLocked() }

    private fun isExpiredLocked(nowElapsedMs: Long): Boolean =
        expiresAtElapsedMs != Long.MAX_VALUE && nowElapsedMs >= expiresAtElapsedMs

    private fun clearLocked() {
        password?.fill('\u0000')
        password = null
        expiresAtElapsedMs = 0L
        expiresAtWallMs = 0L
        _unlocked.value = false
    }

    private fun Int.toDurationMs(): Long = when {
        this == AUTO_LOCK_NEVER -> Long.MAX_VALUE
        this <= 0 -> 0L
        else -> this.toLong() * 1000L
    }

    companion object {
        const val AUTO_LOCK_NEVER = -1
        const val DEFAULT_SESSION_SECONDS = 24 * 60 * 60
    }
}
