// file: app/src/main/java/pro/babasitaram/vault/presentation/components/DesignSystem.kt
package pro.babasitaram.vault.presentation.components

import androidx.compose.ui.unit.dp

/** Shared layout tokens for consistent Android UI spacing and hit targets. */
object AppDimens {
    val ScreenHorizontal = 16.dp
    val ItemSpacing = 8.dp
    val CardPadding = 16.dp
    val CompactPadding = 8.dp
    val IconSize = 24.dp
    val SmallIconSize = 20.dp
    val AvatarSize = 40.dp
}
