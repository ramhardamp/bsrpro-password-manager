package pro.babasitaram.vault.presentation.components
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*

@Composable fun CountdownRing(progress:Float, modifier:Modifier=Modifier) { Canvas(modifier.size(44.dp)) { drawArc(Color(0xFF16A34A),-90f,360f*progress.coerceIn(0f,1f),false,style=androidx.compose.ui.graphics.drawscope.Stroke(width=5.dp.toPx())) } }
