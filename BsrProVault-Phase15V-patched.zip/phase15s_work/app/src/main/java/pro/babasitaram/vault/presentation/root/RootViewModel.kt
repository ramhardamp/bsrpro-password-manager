package pro.babasitaram.vault.presentation.root

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.RestorePersistedSessionUseCase
import pro.babasitaram.vault.presentation.util.launchCatching

enum class RootState { Loading, NeedsSetup, Locked, Unlocked }

@HiltViewModel
class RootViewModel @Inject constructor(
    private val auth: AuthRepository,
    private val session: SessionKeyStore,
    settingsRepository: SettingsRepository,
    private val restoreSession: RestorePersistedSessionUseCase
) : ViewModel() {
    private val _state = MutableStateFlow(RootState.Loading)
    val state: StateFlow<RootState> = _state.asStateFlow()

    val settings: StateFlow<VaultSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VaultSettings())

    init {
        launchCatching {
            // Restore is best-effort. A corrupt/expired quick-unlock record must fall back to
            // the normal lock/setup screen instead of leaving startup stuck on Loading.
            runCatching { restoreSession() }
            publishState()
            session.isUnlocked.collect { publishState() }
        }
    }

    private suspend fun publishState() {
        _state.value = when {
            session.hasValidSession() -> RootState.Unlocked
            auth.vaultExists() -> RootState.Locked
            else -> RootState.NeedsSetup
        }
    }
}
