package pro.babasitaram.vault.domain.usecase

import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.security.BiometricSessionKeyStore
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.vaultCatching
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.data.local.db.VaultDao
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.RecoveryKeyCodec

/** Re-checks the master password (rate-limited like the lock screen) before sensitive actions. */
class VerifyMasterPasswordUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val auth: AuthRepository
) {
    suspend operator fun invoke(password: CharArray): VaultResult<Unit> = vaultCatching {
        auth.checkAllowed()
        try {
            blobStore.read(password)
        } catch (e: VaultError.InvalidMasterPassword) {
            auth.recordFailure()
            throw e
        }
        auth.recordSuccess()
    }
}

/** Re-encrypts the vault under a new master password. The old password stops working immediately. */
class ChangeMasterPasswordUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val session: SessionKeyStore,
    private val auth: AuthRepository,
    private val settings: SettingsRepository,
    private val biometricStore: BiometricSessionKeyStore
) {
    suspend operator fun invoke(old: CharArray, new: CharArray, confirm: CharArray): VaultResult<Unit> = vaultCatching {
        if (!new.contentEquals(confirm)) throw VaultError.Validation("New passwords do not match")
        if (new.contentEquals(old)) throw VaultError.Validation("The new password must differ from the current one")
        if (!PasswordStrength.isAcceptableMaster(java.nio.CharBuffer.wrap(new))) {
            throw VaultError.Validation("Use at least 12 characters with upper & lower case letters, digits or symbols")
        }
        auth.checkAllowed()
        val data = try {
            blobStore.read(old)                      // full payload incl. folder markers
        } catch (e: VaultError.InvalidMasterPassword) {
            auth.recordFailure()
            throw e
        }
        auth.recordSuccess()

        val beforeRaw = blobStore.readRaw() ?: throw VaultError.VaultNotFound
        val currentSettings = settings.current()
        val recoveryKey = if (currentSettings.recoveryEncryptedKey.isNotBlank()) {
            try {
                RecoveryKeyCodec.validate(VaultCrypto.decrypt(currentSettings.recoveryEncryptedKey, old))
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                throw VaultError.Validation("Recovery key metadata is invalid; repair it before changing the master password")
            }
        } else {
            RecoveryKeyCodec.generate()
        }

        try {
            blobStore.write(data, new)                   // new salt + new key (cache fingerprint no longer matches)
            val verified = blobStore.read(new)
            if (verified != data) throw VaultError.IOError(IllegalStateException("Password change verification mismatch"))

            val newRecoveryEncryptedMaster = VaultCrypto.encrypt(
                String(new),
                recoveryKey.toCharArray()
            )
            val newRecoveryEncryptedKey = VaultCrypto.encrypt(
                recoveryKey,
                new
            )

            settings.update {
                it.copy(
                    recoveryEncryptedMaster = newRecoveryEncryptedMaster,
                    recoveryEncryptedKey = newRecoveryEncryptedKey,
                    recoveryCreatedAt = if (it.recoveryCreatedAt > 0L) it.recoveryCreatedAt else System.currentTimeMillis(),
                    emergencyEncryptedMaster = "",
                    emergencyRequestTime = 0L,
                    emergencyActive = false
                )
            }

            blobStore.deleteBackups()                    // backups still carry the OLD password
            // A changed master password invalidates any previously wrapped quick-unlock credential.
            // Disable biometric until the user explicitly re-enrolls Key B with the new password.
            biometricStore.clearSecureCredential()
            biometricStore.clearSessionMetadata()
            auth.clearBiometricCredential()
            settings.update { it.copy(biometricEnabled = false) }
            session.unlock(new, settings.current().vaultSessionSeconds)
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (failure: Exception) {
            runCatching {
                blobStore.writeRaw(beforeRaw)
                blobStore.deleteBackups()
            }
            throw failure
        }
    }
}

/** Wipes the vault from this device. Requires the master password. */
class ResetVaultUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val session: SessionKeyStore,
    private val repository: VaultRepository,
    private val auth: AuthRepository,
    private val settings: SettingsRepository,
    private val verify: VerifyMasterPasswordUseCase,
    private val biometricStore: pro.babasitaram.vault.core.security.BiometricSessionKeyStore
) {
    suspend operator fun invoke(password: CharArray): VaultResult<Unit> {
        val r = verify(password)
        if (r is VaultResult.Failure) return r
        return vaultCatching {
            blobStore.deleteAll()
            biometricStore.clearAllCredentials()
            auth.clearBiometricCredential()
            settings.update { it.copy(
                biometricEnabled = false,
                autoBackupEnabled = false,
                lastAutoBackupAt = 0L,
                emergencyEncryptedMaster = "",
                emergencyRequestTime = 0L,
                emergencyActive = false,
                recoveryEncryptedMaster = "",
                recoveryEncryptedKey = "",
                recoveryCreatedAt = 0L
            ) }
            repository.clear()
            session.lock()                           // RootViewModel then shows the setup screen
        }
    }
}

class ClearRecentSearchesUseCase @Inject constructor(private val dao: VaultDao) {
    suspend operator fun invoke() = withContext(Dispatchers.IO) { dao.clearRecents() }
}
