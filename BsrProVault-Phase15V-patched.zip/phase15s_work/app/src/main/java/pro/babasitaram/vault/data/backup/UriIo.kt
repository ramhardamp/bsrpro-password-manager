package pro.babasitaram.vault.data.backup

import android.content.Context
import android.net.Uri
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.ByteArrayOutputStream
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.util.VaultError

/** Reads / writes user-picked documents (Storage Access Framework). */
@Singleton
class UriIo @Inject constructor(@ApplicationContext private val context: Context) {

    suspend fun readText(uri: Uri, maxBytes: Int = MAX_BYTES): String = withContext(Dispatchers.IO) {
        try {
            val input = context.contentResolver.openInputStream(uri) ?: throw VaultError.Validation("Could not open the file")
            input.use { stream ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = stream.read(buf)
                    if (n < 0) break
                    if (out.size() + n > maxBytes) throw VaultError.Validation("Import file is too large (max 25 MB).")
                    out.write(buf, 0, n)
                }
                String(out.toByteArray(), Charsets.UTF_8)
            }
        } catch (e: IOException) {
            throw VaultError.IOError(e)
        } catch (e: SecurityException) {
            throw VaultError.IOError(e)
        }
    }

    suspend fun writeText(uri: Uri, text: String) = withContext(Dispatchers.IO) {
        try {
            val out = context.contentResolver.openOutputStream(uri, "wt") ?: throw VaultError.Validation("Could not create the file")
            out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
        } catch (e: IOException) {
            throw VaultError.IOError(e)
        } catch (e: SecurityException) {
            throw VaultError.IOError(e)
        }
    }

    companion object {
        const val MAX_BYTES = 25 * 1024 * 1024
    }
}
