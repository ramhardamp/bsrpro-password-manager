package pro.babasitaram.vault.autofill

import android.app.assist.AssistStructure
import android.os.Build
import android.view.View
import android.view.autofill.AutofillId
import pro.babasitaram.vault.autofill.model.AutofillField
import pro.babasitaram.vault.autofill.model.AutofillFieldType
import pro.babasitaram.vault.autofill.model.FieldHints
import pro.babasitaram.vault.autofill.model.ParsedStructure
import androidx.compose.foundation.lazy.*

/** Turns an AssistStructure into classified username / password / OTP fields. */
object AutofillParser {
    private const val MAX_DEPTH = 120   // Compose / web trees can be deep
    private const val MAX_FIELDS = 120

    // View.AUTOFILL_HINT_* values (some constants are newer than minSdk 26, so the literals are used)
    private val USERNAME_HINTS = setOf("username", "newusername", "emailaddress", "email")
    private const val HINT_PASSWORD = "password"
    private const val HINT_NEW_PASSWORD = "newpassword"
    private val OTP_HINTS = setOf("smsotpcode", "otp", "onetimecode")

    private val OTP_TOKENS = setOf("otp", "totp", "mfa", "2fa", "tfa", "onetime")
    private val OTP_JOINED = listOf("onetime", "verificationcode", "authenticatorcode", "authcode", "twofactor", "2stepcode")
    private val PASSWORD_TOKENS = setOf("password", "passwd", "pwd")
    private val NEW_TOKENS = setOf("new", "confirm", "repeat", "retype", "create", "again", "reenter")
    private val USERNAME_TOKENS = setOf("username", "userid", "login", "loginid", "email", "mail", "phone", "mobile", "mobileno", "user", "uid", "customer", "cust", "employee", "emp", "member", "agent", "retailer")

    // android.text.InputType (literal values keep this object JVM-testable)
    private const val CLASS_MASK = 0xf
    private const val VARIATION_MASK = 0xff0
    private const val CLASS_TEXT = 0x1
    private const val CLASS_NUMBER = 0x2
    private const val TEXT_PASSWORD = 0x80
    private const val TEXT_VISIBLE_PASSWORD = 0x90
    private const val TEXT_WEB_PASSWORD = 0xe0
    private const val TEXT_EMAIL = 0x20
    private const val TEXT_WEB_EMAIL = 0xd0
    private const val NUMBER_PASSWORD = 0x10
    private const val FLAG_MULTI_LINE = 0x20000

    // ───────────────────────── framework entry point ─────────────────────────

    private class RawNode(val id: AutofillId, val focused: Boolean, val value: String?)

    private class Collector {
        val items = ArrayList<Pair<RawNode, FieldHints>>()
        var domain: String? = null
        var scheme: String? = null
    }

    fun parse(structure: AssistStructure): ParsedStructure? {
        val packageName = structure.activityComponent?.packageName ?: return null
        val collector = Collector()
        for (i in 0 until structure.windowNodeCount) {
            walk(structure.getWindowNodeAt(i).rootViewNode, collector, 0)
        }
        val fields = resolve(collector.items).mapNotNull { (raw, type) ->
            if (type == null) null else AutofillField(raw.id, type, raw.focused, raw.value)
        }
        return ParsedStructure(
            packageName = packageName,
            webDomain = collector.domain?.trim()?.lowercase()?.takeIf { it.isNotEmpty() },
            webScheme = collector.scheme?.trim()?.lowercase()?.takeIf { it.isNotEmpty() },
            fields = fields
        )
    }

    private fun walk(node: AssistStructure.ViewNode, c: Collector, depth: Int) {
        if (depth > MAX_DEPTH || c.items.size >= MAX_FIELDS) return
        if (c.domain == null) {
            val d = node.webDomain
            if (!d.isNullOrBlank()) {
                c.domain = d
                c.scheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) node.webScheme else null
            }
        }
        val id = node.autofillId
        val textual = node.autofillType == View.AUTOFILL_TYPE_TEXT ||
            !node.autofillHints.isNullOrEmpty() ||
            (node.autofillType == View.AUTOFILL_TYPE_NONE && node.inputType != 0)
        if (id != null && textual && node.visibility == View.VISIBLE) {
            val attrs = HashMap<String, String>()
            node.htmlInfo?.attributes?.forEach { p ->
                val k = p.first
                val v = p.second
                if (k != null && v != null) attrs[k.lowercase()] = v
            }
            val hints = FieldHints(
                autofillHints = node.autofillHints?.toList().orEmpty(),
                idEntry = node.idEntry,
                hint = node.hint,
                inputType = node.inputType,
                htmlType = attrs["type"],
                htmlName = attrs["name"],
                htmlId = attrs["id"],
                htmlAutocomplete = attrs["autocomplete"],
                htmlPlaceholder = attrs["placeholder"],
                maxLength = node.maxTextLength
            )
            val value = node.autofillValue?.takeIf { it.isText }?.textValue?.toString()
            c.items.add(RawNode(id, node.isFocused, value) to hints)
        }
        for (i in 0 until node.childCount) walk(node.getChildAt(i), c, depth + 1)
    }

    // ───────────────────────── pure classification ─────────────────────────

    /**
     * Classifies every item, then applies the "text field right before the password field is the
     * username" rule when nothing was explicitly marked as a username.
     */
    fun <T> resolve(items: List<Pair<T, FieldHints>>): List<Pair<T, AutofillFieldType?>> {
        val types = items.map { classify(it.second) }.toMutableList()
        val hasUsername = types.any { it == AutofillFieldType.USERNAME }
        val firstPassword = types.indexOfFirst { it == AutofillFieldType.PASSWORD || it == AutofillFieldType.PIN || it == AutofillFieldType.NEW_PASSWORD }
        if (!hasUsername && firstPassword > 0) {
            for (i in firstPassword - 1 downTo 0) {
                if (types[i] == null && isPlainText(items[i].second)) {
                    types[i] = AutofillFieldType.USERNAME
                    break
                }
            }
        }
        return items.mapIndexed { i, item -> item.first to types[i] }
    }

    fun classify(h: FieldHints): AutofillFieldType? {
        val earlyWords = Words.of(h)
        val earlyAutocomplete = h.htmlAutocomplete?.lowercase()?.split(' ', '\t')?.filter { it.isNotEmpty() }.orEmpty()
        if (h.autofillHints.any { it.equals(HINT_NEW_PASSWORD, true) } || "new-password" in earlyAutocomplete) {
            return AutofillFieldType.NEW_PASSWORD
        }
        if (h.autofillHints.any { it.lowercase() in OTP_HINTS } ||
            "one-time-code" in earlyAutocomplete || isOtp(earlyWords)) return AutofillFieldType.OTP
        val earlyNumericPassword = (h.inputType and CLASS_MASK) == CLASS_NUMBER && (h.inputType and VARIATION_MASK) == NUMBER_PASSWORD
        val earlyPinNamed = "pin" in earlyWords.tokens || earlyWords.joined.contains("pin")
        if ((earlyNumericPassword || (earlyPinNamed && h.maxLength in 4..6)) && earlyWords.tokens.any { it in NEW_TOKENS }) {
            return AutofillFieldType.NEW_PASSWORD
        }
        if (earlyNumericPassword || (earlyPinNamed && h.maxLength in 4..6)) return AutofillFieldType.PIN
        // 1. explicit autofill hints
        for (raw in h.autofillHints) {
            val hint = raw.lowercase()
            when {
                hint == HINT_PASSWORD -> return AutofillFieldType.PASSWORD
                hint == HINT_NEW_PASSWORD -> return AutofillFieldType.NEW_PASSWORD
                hint in OTP_HINTS -> return AutofillFieldType.OTP
                hint in USERNAME_HINTS -> return AutofillFieldType.USERNAME
            }
        }
        // 2. HTML autocomplete attribute (Chrome / WebView)
        val ac = h.htmlAutocomplete?.lowercase()?.split(' ', '\t')?.filter { it.isNotEmpty() }.orEmpty()
        when {
            "one-time-code" in ac -> return AutofillFieldType.OTP
            "new-password" in ac -> return AutofillFieldType.NEW_PASSWORD
            "current-password" in ac -> return AutofillFieldType.PASSWORD
            "username" in ac || "email" in ac -> return AutofillFieldType.USERNAME
        }
        // 3. keywords, input type, html type
        val words = Words.of(h)
        if (isOtp(words)) return AutofillFieldType.OTP
        val htmlType = h.htmlType?.lowercase()
        if (isPasswordInput(h.inputType) || htmlType == "password" || words.tokens.any { it in PASSWORD_TOKENS }) {
            return if (words.tokens.any { it in NEW_TOKENS }) AutofillFieldType.NEW_PASSWORD else AutofillFieldType.PASSWORD
        }
        if (htmlType == "email" || isEmailInput(h.inputType)) return AutofillFieldType.USERNAME
        if (words.tokens.any { it in USERNAME_TOKENS }) return AutofillFieldType.USERNAME
        return null
    }

    private class Words(val tokens: Set<String>, val joined: String) {
        companion object {
            private val CAMEL = Regex("([a-z0-9])([A-Z])")
            private val SPLIT = Regex("[^a-z0-9]+")

            fun of(h: FieldHints): Words {
                val text = listOfNotNull(h.idEntry, h.hint, h.htmlName, h.htmlId, h.htmlPlaceholder)
                    .joinToString(" ") { it.replace(CAMEL, "$1 $2") }
                    .lowercase()
                val list = text.split(SPLIT).filter { it.isNotEmpty() }
                return Words(list.toSet(), list.joinToString(""))
            }
        }
    }

    private fun isOtp(w: Words): Boolean =
        w.tokens.any { it in OTP_TOKENS } || OTP_JOINED.any { w.joined.contains(it) }

    private fun isPasswordInput(inputType: Int): Boolean {
        val cls = inputType and CLASS_MASK
        val variation = inputType and VARIATION_MASK
        return (cls == CLASS_TEXT && (variation == TEXT_PASSWORD || variation == TEXT_VISIBLE_PASSWORD || variation == TEXT_WEB_PASSWORD)) ||
            (cls == CLASS_NUMBER && variation == NUMBER_PASSWORD)
    }

    private fun isEmailInput(inputType: Int): Boolean {
        val variation = inputType and VARIATION_MASK
        return (inputType and CLASS_MASK) == CLASS_TEXT && (variation == TEXT_EMAIL || variation == TEXT_WEB_EMAIL)
    }

    private fun isPlainText(h: FieldHints): Boolean {
        val textual = h.inputType == 0 || ((h.inputType and CLASS_MASK) == CLASS_TEXT && (h.inputType and FLAG_MULTI_LINE) == 0)
        val htmlOk = h.htmlType == null || h.htmlType.lowercase() in setOf("text", "tel", "url", "search", "email")
        return textual && htmlOk
    }
}
