package pro.babasitaram.vault.core.security

import java.security.SecureRandom

/** Generates a strong, printable backup-only password without storing it. */
object SmartBackupPassword {
    private const val LENGTH = 20
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*-_+="
    private val secureRandom = SecureRandom()

    fun generate(): String = buildString(LENGTH) {
        repeat(LENGTH) { append(ALPHABET[secureRandom.nextInt(ALPHABET.length)]) }
    }
}
