package pro.babasitaram.vault.presentation.activitylog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.presentation.util.launchCatching

@HiltViewModel
class ActivityLogViewModel @Inject constructor(
    private val store: ActivityLogStore
) : ViewModel() {
    val items: StateFlow<List<ActivityLogStore.ActivityLogItem>> =
        store.observe().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun clear() { launchCatching { store.clear() } }
}
