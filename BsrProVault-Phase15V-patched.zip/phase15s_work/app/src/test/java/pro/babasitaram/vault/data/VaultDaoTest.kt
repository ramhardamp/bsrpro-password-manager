package pro.babasitaram.vault.data

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.data.local.db.RecentSearchEntity
import pro.babasitaram.vault.data.local.db.VaultDao
import pro.babasitaram.vault.data.local.db.VaultDatabase
import pro.babasitaram.vault.data.local.db.toEntity
import pro.babasitaram.vault.data.local.db.toMetadata

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class VaultDaoTest {
    private lateinit var db: VaultDatabase
    private lateinit var dao: VaultDao

    @Before
    fun setUp() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), VaultDatabase::class.java)
            .allowMainThreadQueries().build()
        dao = db.vaultDao()
    }

    @After
    fun tearDown() = db.close()

    private val entries = listOf(
        VaultEntry(id = "1", title = "zeta", url = "https://www.github.com/login", category = "work", starred = true, lastUsedAt = 5),
        VaultEntry(id = "2", title = "Alpha", url = "https://bank.example.com", category = "Banking", appPackage = "com.bank.app", lastUsedAt = 9),
        VaultEntry(id = "3", title = "mid", category = "personal")
    )

    @Test
    fun replaceAllStoresAndSortsByTitle() = runTest {
        dao.replaceAll(entries.map { it.toMetadata() }, listOf(Folder("f", "Work").toEntity()))
        assertEquals(listOf("Alpha", "mid", "zeta"), dao.observeMetadata().first().map { it.title })
        assertEquals(1, dao.observeFolders().first().size)
    }

    @Test
    fun replaceAllDropsPreviousRows() = runTest {
        dao.replaceAll(entries.map { it.toMetadata() }, emptyList())
        dao.replaceAll(listOf(entries[0].toMetadata()), emptyList())
        assertEquals(1, dao.observeMetadata().first().size)
    }

    @Test
    fun categoryFilterIsCaseInsensitive() = runTest {
        dao.replaceAll(entries.map { it.toMetadata() }, emptyList())
        assertEquals(listOf("Alpha"), dao.byCategory("banking").map { it.title })
    }

    @Test
    fun starredQuery() = runTest {
        dao.replaceAll(entries.map { it.toMetadata() }, emptyList())
        assertEquals(listOf("zeta"), dao.starred().map { it.title })
    }

    @Test
    fun autofillMatchesByHostOrPackage() = runTest {
        dao.replaceAll(entries.map { it.toMetadata() }, emptyList())
        assertEquals(listOf("zeta"), dao.findForAutofill("github.com", "").map { it.title })
        assertEquals(listOf("Alpha"), dao.findForAutofill("", "com.bank.app").map { it.title })
        assertTrue(dao.findForAutofill("", "").isEmpty())
    }

    @Test
    fun recentSearchesAreNewestFirstAndLimited() = runTest {
        dao.insertRecent(RecentSearchEntity("a", 1))
        dao.insertRecent(RecentSearchEntity("b", 3))
        dao.insertRecent(RecentSearchEntity("c", 2))
        assertEquals(listOf("b", "c"), dao.recent(2).map { it.query })
    }

    @Test
    fun wipeClearsEverything() = runTest {
        dao.replaceAll(entries.map { it.toMetadata() }, listOf(Folder("f", "Work").toEntity()))
        dao.insertRecent(RecentSearchEntity("a", 1))
        dao.wipe()
        assertTrue(dao.observeMetadata().first().isEmpty())
        assertTrue(dao.observeFolders().first().isEmpty())
        assertTrue(dao.recent(10).isEmpty())
    }
}
