package pro.babasitaram.vault.autofill

import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import java.io.File

class AutofillDiagnosticsTest {
    @BeforeEach @AfterEach
    fun reset() = AutofillDiagnostics.clear()

    @Test
    fun `newest event comes first`() {
        AutofillDiagnostics.record("1 onFillRequest called")
        AutofillDiagnostics.record("2 parsed", "pkg=com.example")
        val s = AutofillDiagnostics.snapshot()
        assertEquals(2, s.size)
        assertTrue(s[0].contains("2 parsed — pkg=com.example"))
        assertTrue(s[1].contains("1 onFillRequest called"))
    }

    @Test
    fun `buffer is capped at 40 events`() {
        repeat(100) { AutofillDiagnostics.record("event $it") }
        val s = AutofillDiagnostics.snapshot()
        assertEquals(40, s.size)
        assertTrue(s.first().contains("event 99"))
        assertTrue(s.last().contains("event 60"))
    }

    @Test
    fun `report explains when empty and clear empties`() {
        assertTrue(AutofillDiagnostics.report().contains("No autofill requests"))
        AutofillDiagnostics.record("x")
        assertFalse(AutofillDiagnostics.report().contains("No autofill requests"))
        AutofillDiagnostics.clear()
        assertTrue(AutofillDiagnostics.snapshot().isEmpty())
    }
}

/** Regression guards for the files that decide whether Android even talks to the service. */
class AutofillRegistrationTest {
    private val manifest = File("src/main/AndroidManifest.xml").readText()
    private val serviceXml = File("src/main/res/xml/autofill_service.xml").readText()

    @Test
    fun `service is declared with the bind permission, intent filter and metadata`() {
        val service = manifest.substringAfter("<service").substringBefore("</service>")
        assertTrue(service.contains("android.permission.BIND_AUTOFILL_SERVICE"))
        assertTrue(service.contains("android.service.autofill.AutofillService"))
        assertTrue(service.contains("android:name=\"android.autofill\""))
        assertTrue(service.contains("@xml/autofill_service"))
        assertTrue(service.contains("android:exported=\"true\""))
        assertTrue(service.contains("android:icon=\"@mipmap/ic_launcher\""))
        assertTrue(service.contains("android:label=\"@string/autofill_service_label\""))
    }

    @Test
    fun `popular browsers are registered for compatibility mode`() {
        listOf("com.android.chrome", "com.brave.browser", "com.microsoft.emmx", "org.mozilla.firefox", "com.sec.android.app.sbrowser")
            .forEach { assertTrue(serviceXml.contains("compatibility-package android:name=\"$it\""), it) }
        assertTrue(serviceXml.contains("android:maxLongVersionCode"))
    }
}


class AutofillIdPropagationStaticTest {
    private val parser = File("src/main/java/pro/babasitaram/vault/autofill/AutofillParser.kt").readText()
    private val factory = File("src/main/java/pro/babasitaram/vault/autofill/AutofillDatasetFactory.kt").readText()
    private val auth = File("src/main/java/pro/babasitaram/vault/autofill/AutofillAuthActivity.kt").readText()

    @Test
    fun `framework AutofillIds are captured and returned unchanged`() {
        assertTrue(parser.contains("val id = node.autofillId"))
        assertTrue(parser.contains("AutofillField(raw.id, type, raw.focused, raw.value)"))
        assertTrue(factory.contains("f.id, AutofillValue.forText(v)"))
        assertTrue(auth.contains("EXTRA_IDS, ArrayList<AutofillId>(parsed.fillableFields.map { it.id })"))
    }

    @Test
    fun `nothing-to-fill path records the concrete target`() {
        assertTrue(auth.contains("No saved login for this"))
        assertTrue(auth.contains("p.webDomain ?: p.packageName"))
    }
}
