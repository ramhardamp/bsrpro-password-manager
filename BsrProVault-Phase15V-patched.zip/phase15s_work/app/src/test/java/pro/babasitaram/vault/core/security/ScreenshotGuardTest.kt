package pro.babasitaram.vault.core.security

import android.app.Activity
import android.view.WindowManager
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ScreenshotGuardTest {
    private val flag = WindowManager.LayoutParams.FLAG_SECURE

    @Test
    fun enableSetsFlagSecure() {
        val activity = Robolectric.buildActivity(Activity::class.java).create().get()
        ScreenshotGuard.enable(activity)
        assertEquals(flag, activity.window.attributes.flags and flag)
    }

    @Test
    fun disableClearsFlagSecure() {
        val activity = Robolectric.buildActivity(Activity::class.java).create().get()
        ScreenshotGuard.enable(activity)
        ScreenshotGuard.disable(activity)
        assertEquals(0, activity.window.attributes.flags and flag)
    }
}
