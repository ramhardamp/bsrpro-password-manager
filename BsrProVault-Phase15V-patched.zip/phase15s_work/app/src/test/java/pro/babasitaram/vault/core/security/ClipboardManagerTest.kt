package pro.babasitaram.vault.core.security

import android.content.ClipData
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ClipboardManagerTest {
    private val context: Context = ApplicationProvider.getApplicationContext()
    private val system get() = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
    private fun clipText(): String? = system.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()

    @Test
    fun clearsAfterDelay() = runTest {
        val cm = VaultClipboardManager(context, backgroundScope)
        cm.copySensitive("test", 1000)
        assertEquals("test", clipText())
        advanceTimeBy(999); runCurrent()
        assertEquals("test", clipText())
        advanceTimeBy(2); runCurrent()
        assertTrue(clipText().isNullOrEmpty())
    }

    @Test
    fun newCopyCancelsPreviousClear() = runTest {
        val cm = VaultClipboardManager(context, backgroundScope)
        cm.copySensitive("first", 1000)
        advanceTimeBy(500); runCurrent()
        cm.copySensitive("second", 1000)
        advanceTimeBy(600); runCurrent() // t=1100: the first timer would have fired
        assertEquals("second", clipText())
        advanceTimeBy(500); runCurrent() // t=1600
        assertTrue(clipText().isNullOrEmpty())
    }

    @Test
    fun doesNotWipeSomethingTheUserCopiedLater() = runTest {
        val cm = VaultClipboardManager(context, backgroundScope)
        cm.copySensitive("secret", 1000)
        system.setPrimaryClip(ClipData.newPlainText("other", "user copied this"))
        advanceTimeBy(1100); runCurrent()
        assertEquals("user copied this", clipText())
    }

    @Test
    fun clearNowWipesImmediately() = runTest {
        val cm = VaultClipboardManager(context, backgroundScope)
        cm.copySensitive("secret", 30_000)
        cm.clearNow()
        assertTrue(clipText().isNullOrEmpty())
    }
}
