package pro.babasitaram.vault.data.transfer

import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertThrows
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.crypto.V3PayloadParser
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultError
import androidx.compose.foundation.lazy.*

class CsvTest {
    @Test fun `quotes, embedded commas and newlines`() {
        val rows = Csv.parse("a,b,c\n\"x, y\",\"he said \"\"hi\"\"\",\"line1\nline2\"\n")
        assertEquals(listOf("a", "b", "c"), rows[0])
        assertEquals(listOf("x, y", "he said \"hi\"", "line1\nline2"), rows[1])
    }

    @Test fun `bom, crlf, semicolon and tab delimiters`() {
        assertEquals(listOf(listOf("a", "b"), listOf("1", "2")), Csv.parse("\uFEFFa;b\r\n1;2\r\n"))
        assertEquals(listOf(listOf("a", "b"), listOf("1", "2")), Csv.parse("a\tb\n1\t2"))
    }

    @Test fun `blank lines are dropped and a missing final newline is fine`() =
        assertEquals(2, Csv.parse("a,b\n\n1,2").size)

    @Test fun `cell escaping round trips`() {
        val tricky = "a,\"b\"\nc"
        assertEquals(listOf(listOf("h"), listOf(tricky)), Csv.parse("h\n" + Csv.cell(tricky)))
    }
}

class ImportParserTest {
    @Test fun `chrome csv`() {
        val r = ImportParser.parseCsv("name,url,username,password\nGitHub,https://github.com,me,pw1\n,https://x.org,u,pw2\nEmpty,https://z.com,,\n", 1L)
        assertEquals(ImportFormat.CHROME, r.format)
        assertEquals(2, r.entries.size)
        assertEquals("GitHub", r.entries[0].title)
        assertEquals("X", r.entries[1].title)          // title falls back to the domain
        assertEquals(1, r.skippedRows)
        assertTrue(r.entries.all { it.id.startsWith("v_") })
    }

    @Test fun `bitwarden skips non login items and keeps totp`() {
        val csv = "folder,favorite,type,name,notes,fields,reprompt,login_uri,login_username,login_password,login_totp\n" +
            ",1,login,Site,n,,0,https://s.com,me,pw,JBSWY3DPEHPK3PXP\n" +
            ",0,note,Secret note,body,,0,,,,\n"
        val r = ImportParser.parseCsv(csv)
        assertEquals(ImportFormat.BITWARDEN, r.format)
        assertEquals(1, r.entries.size)
        assertEquals("JBSWY3DPEHPK3PXP", r.entries[0].totp)
        assertTrue(r.entries[0].starred)
        assertEquals(1, r.skippedRows)
    }

    @Test fun `lastpass and 1password and generic`() {
        val lp = ImportParser.parseCsv("url,username,password,totp,extra,name,grouping,fav\nhttps://a.com,u,p,,note,A,,0\n")
        assertEquals(ImportFormat.LASTPASS, lp.format); assertEquals("A", lp.entries[0].title); assertEquals("note", lp.entries[0].notes)
        val op = ImportParser.parseCsv("Title,Website,Username,Password,OTPAuth,Notes,Type\nB,https://b.com,u,p,JBSWY3DPEHPK3PXP,nn,Login\n")
        assertEquals(ImportFormat.ONEPASSWORD, op.format); assertEquals("JBSWY3DPEHPK3PXP", op.entries[0].totp)
        val g = ImportParser.parseCsv("site,login,pwd\nc.com,u,p\n")
        assertEquals(ImportFormat.GENERIC, g.format); assertEquals("c.com", g.entries[0].title); assertEquals("p", g.entries[0].password)
    }

    @Test fun `bsrpro vault csv keeps mobile and timestamps`() {
        val r = ImportParser.parseCsv("name,url,username,mobile,password,notes,strength,starred,createdAt,updatedAt\nA,https://a.com,u,12345,p,n,strong,1,100,200\n")
        assertEquals(ImportFormat.VAULT_CSV, r.format)
        val e = r.entries.single()
        assertEquals("12345", e.mobile); assertEquals(100L, e.createdAt); assertEquals(200L, e.updatedAt); assertTrue(e.starred)
    }

    @Test fun `invalid imported PIN lengths and characters are rejected`() {
        assertThrows(VaultError.Validation::class.java) { ImportParser.parseCsv("name,password,app_pin\nBank,pw,123\n") }
        assertThrows(VaultError.Validation::class.java) { ImportParser.parseCsv("name,password,app_pin\nBank,pw,12a4\n") }
    }

    @Test fun `password is never trimmed`() =
        assertEquals(" pw ", ImportParser.parseCsv("name,url,username,password\nA,,u, pw \n").entries.single().password)

    @Test fun `missing password column and empty files are rejected`() {
        assertThrows(VaultError.Validation::class.java) { ImportParser.parseCsv("name,url\nA,b\n") }
        assertThrows(VaultError.Validation::class.java) { ImportParser.parseCsv("") }
    }

    @Test fun `kind detection is content based`() {
        assertEquals(SourceKind.V3_BACKUP, ImportParser.detectKind("""{"header":{"format":"BSRPRO.Vault"},"ciphertext":"x"}"""))
        assertEquals(SourceKind.PLAIN_JSON, ImportParser.detectKind("""{"entries":[]}"""))
        assertEquals(SourceKind.VCARD, ImportParser.detectKind("BEGIN:VCARD\nFN:A\nEND:VCARD"))
        assertEquals(SourceKind.DEVICE_BACKUP, ImportParser.detectKind("A".repeat(80)))
        assertEquals(SourceKind.CSV, ImportParser.detectKind("name,url,username,password\n"))
        assertEquals(SourceKind.UNKNOWN, ImportParser.detectKind("   \n"))
    }

    @Test fun `vcard`() {
        val r = ImportParser.parseVCard("BEGIN:VCARD\nFN:Asha Rao\nTEL;TYPE=CELL:+91 98765-43210\nEMAIL:asha@x.com\nEND:VCARD\n")
        val e = r.entries.single()
        assertEquals("Asha Rao", e.title); assertEquals("919876543210", e.mobile); assertEquals("asha@x.com", e.username); assertEquals("", e.password)
        assertThrows(VaultError.Validation::class.java) { ImportParser.parseVCard("nothing here") }
    }

    @Test fun `plain json from this app is re-imported with fresh ids`() {
        val e = VaultEntry(id = "old", title = "T", url = "https://t.com", username = "u", password = "p")
        val json = EntryExporter.plainJson(listOf(e), 0L)
        val back = ImportParser.parsePlainJson(json, 5L).entries.single()
        assertEquals("T", back.title); assertEquals("p", back.password)
        assertTrue(back.id != "old")
    }
}

class EntryExporterTest {
    private val e = VaultEntry(id = "1", title = "A, \"B\"", url = "https://a.com", username = "u", password = "p\nq", notes = "n", starred = true, strength = "strong", createdAt = 1, updatedAt = 2, totp = "SECRET")

    @Test fun `csv layouts match the extension`() {
        assertEquals("name,url,username,password,app_pin\n\"A, \"\"B\"\"\",https://a.com,u,\"p\nq\",", EntryExporter.chromeCsv(listOf(e)))
        assertTrue(EntryExporter.vaultCsv(listOf(e)).startsWith("name,url,username,mobile,password,notes,strength,starred,createdAt,updatedAt,app_pin\n"))
        assertTrue(EntryExporter.bitwardenCsv(listOf(e)).endsWith(",SECRET,"))
    }

    @Test fun `PIN is retained across supported CSV exports and imports`() {
        val withPin = e.copy(appPin = "0042")
        assertEquals("0042", ImportParser.parseCsv(EntryExporter.vaultCsv(listOf(withPin))).entries.single().appPin)
        assertEquals("0042", ImportParser.parseCsv(EntryExporter.chromeCsv(listOf(withPin))).entries.single().appPin)
        assertEquals("0042", ImportParser.parseCsv(EntryExporter.bitwardenCsv(listOf(withPin))).entries.single().appPin)
    }

    @Test fun `exported csv can be imported again`() {
        val back = ImportParser.parseCsv(EntryExporter.vaultCsv(listOf(e))).entries.single()
        assertEquals(e.title, back.title); assertEquals(e.password, back.password); assertTrue(back.starred)
    }

    @Test fun `v3 backup round trips through the same crypto as the extension`() = runTest {
        val pw = "Str0ng!Passw0rd".toCharArray()
        val data = VaultData(
            entries = listOf(e.copy(folderId = "missing", appPackage = "not a package", appPin = "0042")),
            folders = listOf(Folder(id = "f1", name = "Work"))
        )
        val container = EntryExporter.v3(data, pw)
        assertTrue(container.startsWith("{\"header\":{\"format\":\"BSRPRO.Vault\",\"version\":3"))
        val parsed = V3PayloadParser.parse(VaultCrypto.decryptV3(container, pw))
        assertEquals("A, \"B\"", parsed.entries.single().title)
        assertEquals("", parsed.entries.single().folderId)       // dangling folder reference removed
        assertEquals("", parsed.entries.single().appPackage)     // invalid package removed
        assertEquals("0042", parsed.entries.single().appPin)
        assertEquals("Work", parsed.folders.single().name)
        val failure = runCatching { VaultCrypto.decryptV3(container, "wrong-Passw0rd!".toCharArray()) }.exceptionOrNull()
        assertTrue(failure === VaultError.InvalidMasterPassword)
    }
}

class DuplicateDetectorTest {
    private fun e(url: String, user: String, mobile: String = "", note: Boolean = false, title: String = "t", notes: String = "") =
        VaultEntry(url = url, username = user, mobile = mobile, isNote = note, title = title, notes = notes)

    @Test fun `same domain, username and phone digits`() {
        val existing = listOf(e("https://www.site.com/login", "Me", "+1 (555) 123"))
        assertNotNull(DuplicateDetector.find(e("site.com", "me", "1555123"), existing))
        assertNull(DuplicateDetector.find(e("site.com", "other", "1555123"), existing))
        assertNull(DuplicateDetector.find(e("site.org", "me", "1555123"), existing))
        assertNull(DuplicateDetector.find(e("site.com", "me", "999"), existing))
    }

    @Test fun `secure notes match on title and body`() {
        val existing = listOf(e("", "", note = true, title = "WiFi", notes = "pw"))
        assertNotNull(DuplicateDetector.find(e("", "", note = true, title = "wifi", notes = "pw"), existing))
        assertNull(DuplicateDetector.find(e("", "", note = true, title = "wifi", notes = "other"), existing))
    }
}

class ContactImportTest {
    @org.junit.Test fun `multi contact vcard becomes mobile entries`() {
        val vcf = "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:Asha Rao\r\nTEL;TYPE=CELL:+91 98765-43210\r\nEND:VCARD\r\n" +
            "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:Ravi\r\nTEL:99999 11111\r\nEND:VCARD\r\n"
        val r = pro.babasitaram.vault.data.transfer.ImportParser.parseVCard(vcf)
        org.junit.Assert.assertEquals(2, r.entries.size)
        org.junit.Assert.assertTrue(r.entries.all { it.recordType == "mobile" })
    }

    @org.junit.Test fun `contacts csv is detected and parsed`() {
        val csv = "First Name,Last Name,Phone 1 - Value,E-mail 1 - Value\nAsha,Rao,98765 43210,a@x.com\nRavi,,99999-11111,\n"
        org.junit.Assert.assertTrue(pro.babasitaram.vault.data.transfer.ImportParser.looksLikeContactsCsv(csv))
        val r = pro.babasitaram.vault.data.transfer.ImportParser.parseContactsCsv(csv)
        org.junit.Assert.assertEquals(listOf("Asha Rao", "Ravi"), r.entries.map { it.title })
        org.junit.Assert.assertEquals("9876543210", r.entries[0].mobile)
    }
}
