package pro.babasitaram.vault.domain.usecase

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import java.io.File

class RecoveryJournalPersistenceTest {
    @TempDir lateinit var temp: File

    @Test fun preparedSnapshotAndPhaseSurviveNewJournalInstance() {
        val first = RecoveryJournal(temp)
        first.prepare("encrypted-old-vault-blob")
        first.setPhase(RecoveryJournal.Phase.REPLACING)

        val restarted = RecoveryJournal(temp)
        assertTrue(restarted.hasPending())
        assertEquals("encrypted-old-vault-blob", File(temp, "vault-restore.snapshot").readText())
        assertEquals("BSR-RESTORE-1", File(temp, "vault-restore.transaction").readLines().first())
        assertEquals("REPLACING", File(temp, "vault-restore.transaction").readLines()[1])
    }

    @Test fun clearRemovesJournalAndSnapshot() {
        val journal = RecoveryJournal(temp)
        journal.prepare("encrypted-snapshot")
        journal.clear()
        assertTrue(!File(temp, "vault-restore.transaction").exists())
        assertTrue(!File(temp, "vault-restore.snapshot").exists())
    }
}
