package pro.babasitaram.vault.core.crypto

import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import pro.babasitaram.vault.core.util.VaultError

class SessionKeyStoreTest {
    @Test
    fun `locked by default and withPassword throws`() = runTest {
        val s = SessionKeyStore()
        assertFalse(s.isUnlocked.value)
        assertThrows<VaultError.VaultLocked> { s.withPassword { } }
    }

    @Test
    fun `unlock stores a copy and lock wipes it`() = runTest {
        val s = SessionKeyStore()
        val input = "hunter2hunter2".toCharArray()
        s.unlock(input)
        assertTrue(s.isUnlocked.value)
        assertEquals("hunter2hunter2", s.withPassword { String(it) })
        s.lock()
        assertFalse(s.isUnlocked.value)
        assertThrows<VaultError.VaultLocked> { s.withPassword { } }
    }

    @Test
    fun `temporary copy is wiped after use`() = runTest {
        val s = SessionKeyStore()
        s.unlock("abcdef123456".toCharArray())
        var leaked: CharArray? = null
        s.withPassword { leaked = it }
        assertTrue(leaked!!.all { it == '\u0000' })
    }
    @Test
    fun `session expires at the configured absolute lifetime`() = runTest {
        val s = SessionKeyStore()
        s.unlock("abcdef123456".toCharArray(), sessionSeconds = 10, nowElapsedMs = 1_000L, nowWallMs = 50_000L)
        assertTrue(s.hasValidSession(10_999L))
        assertFalse(s.hasValidSession(11_000L))
        assertThrows<VaultError.VaultLocked> { s.withPassword { } }
    }

    @Test
    fun `process restore recomputes remaining session from wall clock`() = runTest {
        val s = SessionKeyStore()
        assertTrue(
            s.restore(
                "abcdef123456".toCharArray(),
                expiresAtWallMs = 70_000L,
                nowElapsedMs = 2_000L,
                nowWallMs = 60_000L
            )
        )
        assertTrue(s.sessionRemainingMs(11_999L) > 0L)
        assertFalse(s.restore("abcdef123456".toCharArray(), 70_000L, nowElapsedMs = 2_000L, nowWallMs = 70_000L))
    }

}
