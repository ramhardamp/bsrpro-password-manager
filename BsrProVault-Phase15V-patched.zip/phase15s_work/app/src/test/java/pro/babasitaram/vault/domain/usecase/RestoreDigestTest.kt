package pro.babasitaram.vault.domain.usecase

import org.junit.jupiter.api.Assertions.assertArrayEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Test
import java.security.MessageDigest

class RestoreDigestTest {
    private fun sha(text: String) = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))

    @Test fun samePlaintextProducesSameDigest() {
        assertArrayEquals(sha("normalized vault payload"), sha("normalized vault payload"))
    }

    @Test fun changedPlaintextProducesDifferentDigest() {
        assertFalse(MessageDigest.isEqual(sha("before"), sha("after")))
    }
}
