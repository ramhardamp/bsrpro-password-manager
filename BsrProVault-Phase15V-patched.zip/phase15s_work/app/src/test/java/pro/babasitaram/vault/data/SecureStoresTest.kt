package pro.babasitaram.vault.data

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertArrayEquals
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.crypto.KeystoreMasterKeyManager
import pro.babasitaram.vault.core.security.LockoutState
import pro.babasitaram.vault.data.local.preferences.EncryptedLockoutStore
import pro.babasitaram.vault.data.local.preferences.WrappedBiometricCredentialStore
import pro.babasitaram.vault.testing.SoftwareKeyBackend

class SecureStoresTest {
    @TempDir
    lateinit var dir: File

    private val keys = KeystoreMasterKeyManager(SoftwareKeyBackend(), Dispatchers.Unconfined)

    @Test
    fun `lockout state round trips encrypted`() = runTest {
        val ds = PreferenceDataStoreFactory.create(scope = backgroundScope) { File(dir, "l.preferences_pb") }
        val store = EncryptedLockoutStore(ds, keys)
        assertEquals(LockoutState(), store.load())
        store.save(LockoutState(3, 123_456L))
        assertEquals(LockoutState(3, 123_456L), store.load())
    }

    @Test
    fun `tampered lockout value falls back to a clean state`() = runTest {
        val ds = PreferenceDataStoreFactory.create(scope = backgroundScope) { File(dir, "t.preferences_pb") }
        ds.edit { it[stringPreferencesKey("lockout_v1")] = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==" }
        assertEquals(LockoutState(), EncryptedLockoutStore(ds, keys).load())
    }

    @Test
    fun `biometric credential save load clear`() = runTest {
        val ds = PreferenceDataStoreFactory.create(scope = backgroundScope) { File(dir, "c.preferences_pb") }
        val store = WrappedBiometricCredentialStore(ds, keys)
        assertFalse(store.exists())
        assertNull(store.load())
        val pw = "पासवर्ड-Pass#123".toCharArray()
        store.save(pw)
        assertTrue(store.exists())
        assertArrayEquals(pw, store.load())
        store.clear()
        assertFalse(store.exists())
    }
}
