package pro.babasitaram.vault.domain

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertThrows
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.domain.usecase.RecoveryKeyCodec

class RecoveryKeyCodecTest {
    @Test
    fun `generated recovery key has exactly 24 safe alphanumeric characters`() {
        val key = RecoveryKeyCodec.generate()
        assertEquals(24, key.length)
        require(key.all { it.isLetterOrDigit() })
    }

    @Test
    fun `normalize strips separators and uppercases`() {
        assertEquals("ABCD2345", RecoveryKeyCodec.normalize("abcd-2345"))
    }

    @Test
    fun `invalid recovery key is rejected`() {
        assertThrows(VaultError.Validation::class.java) {
            RecoveryKeyCodec.validate("A".repeat(23))
        }
        assertThrows(VaultError.Validation::class.java) {
            RecoveryKeyCodec.validate("O".repeat(24))
        }
    }
}
