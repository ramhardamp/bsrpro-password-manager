package pro.babasitaram.vault

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.constants.AppInfo
import pro.babasitaram.vault.core.constants.VaultConstants

class AppInfoTest {
    @Test
    fun `app info exposes constants`() {
        val info = AppInfo()
        assertEquals("BSRPRO Vault", info.name)
        assertEquals("PBKDF2-HMAC-SHA256 · 600000", info.kdfLabel)
    }

    @Test
    fun `crypto constants match browser extension`() {
        assertEquals(600_000, VaultConstants.PBKDF2_ITERATIONS)
        assertEquals(16, VaultConstants.SALT_BYTES)
        assertEquals(12, VaultConstants.IV_BYTES)
        assertEquals(128, VaultConstants.GCM_TAG_BITS)
        assertEquals("BSRPRO.Vault", VaultConstants.V3_FORMAT)
    }
}
