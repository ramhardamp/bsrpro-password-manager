package pro.babasitaram.vault.data

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import java.io.File
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.model.AppIconColor
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.data.local.preferences.SettingsDataStore

class SettingsDataStorePhase7Test {
    @TempDir
    lateinit var dir: File

    @Test
    fun `new settings persist and defaults are sensible`() = runTest {
        val ds = SettingsDataStore(PreferenceDataStoreFactory.create(scope = backgroundScope) { File(dir, "p7.preferences_pb") })
        assertEquals(false, ds.current().autofillInline)
        assertEquals(false, ds.current().autoBackupEnabled)
        val wanted = VaultSettings(
            autoLockSeconds = VaultSettings.AUTO_LOCK_NEVER, autofillInline = true, generatorExcludeSimilar = true,
            appIcon = AppIconColor.TEAL, autoBackupEnabled = true, lastAutoBackupAt = 1_700_000_000_000L
        )
        ds.update { wanted }
        assertEquals(wanted, ds.current())
    }
}
