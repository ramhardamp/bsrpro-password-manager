package pro.babasitaram.vault.core.crypto

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.model.VaultJson
import pro.babasitaram.vault.core.util.VaultError

class V3PayloadParserTest {

    @Test
    fun `schema payload parses as auto backup`() {
        val r = V3PayloadParser.parse(GoldenVectors.V3[0].plaintext)
        assertTrue(r is V3PayloadResult.AutoBackup)
        assertEquals("Bank", r.entries.single().title)
    }

    @Test
    fun `manual export parses entries, folders and app binding`() {
        val r = V3PayloadParser.parse(GoldenVectors.V3[1].plaintext)
        assertTrue(r is V3PayloadResult.ManualExport)
        assertEquals("com.example.app", r.entries.single().appPackage)
        assertTrue(r.entries.single().isAppEntry)
        assertEquals("Work", r.folders.single().name)
    }

    @Test
    fun `bare entries object falls back to auto backup`() {
        val r = V3PayloadParser.parse("""{"entries":[{"id":"x","title":"T"}]}""")
        assertTrue(r is V3PayloadResult.AutoBackup)
    }

    @Test
    fun `schema payload may carry folders`() {
        val r = V3PayloadParser.parse(
            """{"schema":"BSRPRO.Vault.Payload","version":3,"entries":[],"folders":[{"id":"f","name":"N"}]}"""
        )
        assertEquals(1, r.folders.size)
    }

    @Test
    fun `unknown schema is rejected`() {
        assertThrows<VaultError.InvalidFormat> { V3PayloadParser.parse("""{"foo":1}""") }
        assertThrows<VaultError.InvalidFormat> { V3PayloadParser.parse("[1,2]") }
        assertThrows<VaultError.InvalidFormat> { V3PayloadParser.parse("not json") }
    }

    @Test
    fun `entry without id gets one`() {
        val r = V3PayloadParser.parse("""{"entries":[{"title":"No id"}]}""")
        assertTrue(r.entries.single().id.isNotBlank())
    }

    @Test
    fun `extension quirks decode - unknown keys, nulls, numeric id`() {
        val e = VaultJson.decodeFromString(
            VaultEntry.serializer(),
            """{"id":123,"title":null,"password":"p","futureField":{"a":1},"tags":["a"],"_metaType":"folder"}"""
        )
        assertEquals("123", e.id)
        assertEquals("", e.title)
        assertEquals("p", e.password)
        assertTrue(e.isFolderMarker)
    }

    @Test
    fun `entry round trips through json`() {
        val e = VaultEntry(id = "1", title = "T", appPackage = "a.b", isPrimaryAppLogin = true)
        val back = VaultJson.decodeFromString(VaultEntry.serializer(), VaultJson.encodeToString(VaultEntry.serializer(), e))
        assertEquals(e, back)
        assertFalse(back.isFolderMarker)
    }
}
