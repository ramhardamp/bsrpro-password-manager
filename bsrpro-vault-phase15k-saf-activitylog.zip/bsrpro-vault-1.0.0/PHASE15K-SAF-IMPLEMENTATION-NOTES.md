# Phase 15K SAF implementation notes

Implemented in this source snapshot:
- Selected SAF tree URI is managed through the existing BackupFolderManager and SettingsRepository-backed backupFolderUri.
- AutoBackupManager adds a staged SAF path: working write/readback SHA, V3 decrypt/payload count validation, ready recovery document, canonical publication, final readback/hash/decrypt validation, then ready cleanup and duplicate cleanup.
- Startup recovery is invoked from BsrApplication. Because V3 validation requires the unlocked session password, recovery defers while locked and is retried from the unlocked backup flow.
- BackupScreen adds a folder picker card without replacing the existing import/export/restore sections.
- Activity events were added to the applicable existing ViewModels and RateLimiter; ActivityLogStore remains the existing store.

Validation performed:
- tools/bracket_check.py: 0 files with bracket issues.
- Static marker inspection completed.
- Android Kotlin compilation/device tests were not run: this source archive has no gradlew executable and no system Gradle was available in the execution environment.

Keep an independent copy of existing vault backups before installing/testing this build. SAF provider behavior varies; test recovery and restore with a disposable vault before relying on it as the only backup.
