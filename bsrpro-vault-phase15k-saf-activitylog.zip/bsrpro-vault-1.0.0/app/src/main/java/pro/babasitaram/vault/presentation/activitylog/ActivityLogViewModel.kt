package pro.babasitaram.vault.presentation.activitylog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.security.ActivityLogStore

@HiltViewModel
class ActivityLogViewModel @Inject constructor(
    private val store: ActivityLogStore
) : ViewModel() {
    private val _items = MutableStateFlow(store.snapshot())
    val items: StateFlow<List<ActivityLogStore.ActivityLogItem>> = _items.asStateFlow()

    fun refresh() { _items.value = store.snapshot() }

    fun clear() {
        viewModelScope.launch {
            store.clear()
            _items.value = emptyList()
        }
    }
}
