package pro.babasitaram.vault.data.backup

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.runBlocking
import pro.babasitaram.vault.domain.repository.SettingsRepository

/** Persists the user-selected SAF tree URI. Never removes an existing backup. */
@Singleton
class BackupFolderManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepo: SettingsRepository
) {
    fun getFolderUri(): Uri? = runBlocking {
        settingsRepo.current().backupFolderUri.takeIf(String::isNotBlank)?.let(Uri::parse)
    }

    fun hasFolderPermission(): Boolean {
        val uri = getFolderUri() ?: return false
        val persisted = context.contentResolver.persistedUriPermissions.any {
            it.uri == uri && it.isReadPermission && it.isWritePermission
        }
        return persisted && DocumentFile.fromTreeUri(context, uri)?.canWrite() == true
    }

    fun saveFolderPermission(uri: Uri) {
        context.contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        runBlocking {
            settingsRepo.update { it.copy(backupFolderUri = uri.toString()) }
        }
    }
}
