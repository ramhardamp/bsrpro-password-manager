package pro.babasitaram.vault

import android.app.Application
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject
import pro.babasitaram.vault.core.security.AppIconApplier
import pro.babasitaram.vault.core.security.AutoLockController
import timber.log.Timber
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import pro.babasitaram.vault.data.backup.AutoBackupManager

@HiltAndroidApp
class BsrApplication : Application() {

    @Inject
    lateinit var autoLock: AutoLockController

    @Inject
    lateinit var iconApplier: AppIconApplier

    @Inject
    lateinit var autoBackupManager: AutoBackupManager

    override fun onCreate() {
        super.onCreate()
        // Debug-only logging. A redacting release tree is added in Phase 10.
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            autoBackupManager.recoverInterruptedSafBackup()
        }

        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) = autoLock.onForegrounded()
            override fun onStop(owner: LifecycleOwner) {
                autoLock.onBackgrounded()
                iconApplier.applyWhenBackgrounded()
            }
        })
    }
}
