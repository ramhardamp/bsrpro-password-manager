package pro.babasitaram.vault.domain.usecase

import java.security.SecureRandom
import javax.inject.Inject
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.vaultCatching
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository

object RecoveryKeyCodec {
    const val LENGTH = 24
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    fun generate(): String {
        val random = SecureRandom()
        return buildString(LENGTH) {
            repeat(LENGTH) {
                append(ALPHABET[random.nextInt(ALPHABET.length)])
            }
        }
    }

    fun normalize(value: String): String =
        value.filter(Char::isLetterOrDigit).uppercase()

    fun validate(value: String): String {
        val clean = normalize(value)
        if (clean.length != LENGTH || clean.any { it !in ALPHABET }) {
            throw VaultError.Validation("Recovery key must be exactly 24 characters")
        }
        return clean
    }
}

/** Generates and stores a recovery credential without ever storing the plaintext recovery key. */
class RecoveryKeyUseCase @Inject constructor(
    private val settings: SettingsRepository,
    private val session: SessionKeyStore
) {
    private val mutex = Mutex()

    suspend fun ensureCreated(): VaultResult<String> = mutex.withLock {
        vaultCatching {
            if (!session.isUnlocked.value) throw VaultError.VaultLocked
            val existing = settings.current()
            if (existing.recoveryEncryptedMaster.isNotBlank() && existing.recoveryEncryptedKey.isNotBlank()) {
                return@vaultCatching session.withPassword { master ->
                    VaultCrypto.decrypt(existing.recoveryEncryptedKey, master)
                }
            }

            val key = RecoveryKeyCodec.generate()
            session.withPassword { master ->
                val masterText = String(master)
                val encryptedMaster = VaultCrypto.encrypt(masterText, key.toCharArray())
                val encryptedKey = VaultCrypto.encrypt(key, master)
                settings.update {
                    it.copy(
                        recoveryEncryptedMaster = encryptedMaster,
                        recoveryEncryptedKey = encryptedKey,
                        recoveryCreatedAt = System.currentTimeMillis()
                    )
                }
            }
            key
        }
    }

    suspend fun currentKey(): VaultResult<String> =
        if (settings.current().recoveryEncryptedKey.isBlank()) ensureCreated()
        else vaultCatching {
            val current = settings.current()
            session.withPassword { master ->
                VaultCrypto.decrypt(current.recoveryEncryptedKey, master)
                    .let(RecoveryKeyCodec::validate)
            }
        }
}

/** Immediate master-password recovery using the user-held 24-character recovery key. */
class RecoverMasterPasswordUseCase @Inject constructor(
    private val settings: SettingsRepository,
    private val session: SessionKeyStore,
    private val blobStore: VaultBlobStore,
    private val repository: VaultRepository,
    private val auth: AuthRepository
) {
    private val mutex = Mutex()

    suspend operator fun invoke(
        recoveryKey: CharArray,
        newPassword: CharArray,
        confirm: CharArray
    ): VaultResult<Unit> = mutex.withLock {
        vaultCatching {
            if (!newPassword.contentEquals(confirm)) {
                throw VaultError.Validation("New passwords do not match")
            }
            if (!PasswordStrength.isAcceptableMaster(java.nio.CharBuffer.wrap(newPassword))) {
                throw VaultError.Validation("Use at least 12 characters with upper & lower case letters, digits or symbols")
            }
            auth.checkAllowed()

            val cleanKey = try {
                RecoveryKeyCodec.validate(String(recoveryKey))
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                auth.recordFailure()
                throw e
            }

            val current = settings.current()
            if (current.recoveryEncryptedMaster.isBlank()) {
                throw VaultError.Validation("No recovery key is configured for this vault")
            }

            val oldMaster = try {
                VaultCrypto.decrypt(current.recoveryEncryptedMaster, cleanKey.toCharArray()).toCharArray()
            } catch (e: VaultError.CryptoFailure) {
                auth.recordFailure()
                throw VaultError.Validation("Recovery key is invalid")
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                auth.recordFailure()
                throw VaultError.Validation("Recovery key is invalid")
            }

            try {
                val data = try {
                    blobStore.read(oldMaster)
                } catch (e: VaultError.InvalidMasterPassword) {
                    throw VaultError.IOError(IllegalStateException("Recovery credential no longer matches the vault", e))
                }

                val oldRaw = blobStore.readRaw()
                    ?: throw VaultError.VaultNotFound

                try {
                    blobStore.write(data, newPassword)
                    val verified = blobStore.read(newPassword)
                    if (verified != data) {
                        throw VaultError.IOError(IllegalStateException("Recovered vault verification mismatch"))
                    }

                    val newEncryptedMaster = VaultCrypto.encrypt(
                        String(newPassword),
                        cleanKey.toCharArray()
                    )
                    val newEncryptedKey = VaultCrypto.encrypt(
                        cleanKey,
                        newPassword
                    )

                    settings.update {
                        it.copy(
                            recoveryEncryptedMaster = newEncryptedMaster,
                            recoveryEncryptedKey = newEncryptedKey,
                            recoveryCreatedAt = if (it.recoveryCreatedAt > 0L) it.recoveryCreatedAt else System.currentTimeMillis(),
                            emergencyEncryptedMaster = "",
                            emergencyRequestTime = 0L,
                            emergencyActive = false
                        )
                    }

                    auth.clearBiometricCredential()
                    session.unlock(newPassword)
                    repository.setData(verified)
                    auth.recordSuccess()
                } catch (ce: kotlinx.coroutines.CancellationException) {
                    throw ce
                } catch (failure: Exception) {
                    runCatching {
                        blobStore.writeRaw(oldRaw)
                        val rolledBack = blobStore.read(oldMaster)
                        repository.setData(rolledBack)
                    }
                    throw failure
                }
            } finally {
                oldMaster.fill('\u0000')
            }
        }
    }
}
