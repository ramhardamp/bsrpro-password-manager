package pro.babasitaram.vault.presentation.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.DeleteEntryUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions

@HiltViewModel
class NotesViewModel @Inject constructor(
    repository: VaultRepository,
    private val deleteEntry: DeleteEntryUseCase,
    private val clipboard: ClipboardActions,
    private val activityLog: pro.babasitaram.vault.core.security.ActivityLogStore
) : ViewModel() {
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()
    private val entriesSource = repository.entries
    val entries: StateFlow<List<VaultEntry>> = entriesSource
        .map { values -> values.filter { it.deletedAt == 0L && (it.isNote || it.recordType.equals("note", true)) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun copy(text: String) { viewModelScope.launch { activityLog.record("Note copied", "Secure note text copied"); _messages.send(clipboard.copy(text, "Note")) } }
    fun delete(id: String) { viewModelScope.launch {
        val title = entries.value.firstOrNull { it.id == id }?.title.orEmpty()
        deleteEntry(id); activityLog.record("Note deleted", title); _messages.send("Moved to Bin")
    } }
}
