@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.supportdeveloper

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix

private const val WEBSITE_URL = "https://ramhardamp.github.io/babasitaram-pro/"
private const val SUPPORT_UPI_ID = "Totalpay@upi"

@Composable
fun SupportDeveloperScreen(onBack: () -> Unit = {}) {
    val context = LocalContext.current
    val upiUri = "upi://pay?pa=${Uri.encode(SUPPORT_UPI_ID)}&pn=${Uri.encode("BSRPRO Developer")}"
    val upiQr = rememberQr(upiUri)
    val websiteQr = rememberQr(WEBSITE_URL)
    BackHandler { onBack() }
    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.p15_support_developer), style = MaterialTheme.typography.titleLarge) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(Icons.Default.VolunteerActivism, null); Text("Support BSRPRO development", style = MaterialTheme.typography.titleMedium); Text("Your support helps maintain the vault and future security updates.") } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("UPI", style = MaterialTheme.typography.titleMedium)
                Text(SUPPORT_UPI_ID, style = MaterialTheme.typography.headlineSmall)
                upiQr?.let { Image(it.asImageBitmap(), "UPI QR code", Modifier.size(240.dp)) }
                Button(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(upiUri))) } }, modifier = Modifier.fillMaxWidth()) { Text("Pay via UPI") }
            } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.QrCode2, null); Text("Website", style = MaterialTheme.typography.titleMedium); websiteQr?.let { Image(it.asImageBitmap(), "Website QR code", Modifier.size(220.dp)) }; Text(WEBSITE_URL, style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(WEBSITE_URL))) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Language, null); Text("  Open website") }
            } } }
        }
    }
}

@Composable
private fun rememberQr(value: String): Bitmap? = androidx.compose.runtime.remember(value) {
    runCatching {
        val matrix: BitMatrix = MultiFormatWriter().encode(value, BarcodeFormat.QR_CODE, 600, 600)
        val bitmap = Bitmap.createBitmap(600, 600, Bitmap.Config.ARGB_8888)
        for (x in 0 until 600) for (y in 0 until 600) bitmap.setPixel(x, y, if (matrix[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        bitmap
    }.getOrNull()
}
