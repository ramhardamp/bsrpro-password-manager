@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.emergency

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContactEmergency
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

@Composable
fun EmergencyScreen(onBack: () -> Unit = {}, vm: EmergencyViewModel = hiltViewModel()) {
    val status by vm.status.collectAsStateWithLifecycle()
    val key by vm.generatedKey.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val contactName by vm.contactName.collectAsStateWithLifecycle()
    val contactPhone by vm.contactPhone.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var requestKey by remember { mutableStateOf("") }
    var timer by remember { mutableStateOf(now) }
    BackHandler { onBack() }
    LaunchedEffect(Unit) { while (true) { timer = System.currentTimeMillis(); delay(1_000L) } }
    val unlockAt = status?.unlockAt ?: 0L
    val remaining = (unlockAt - timer).coerceAtLeast(0L)
    val hours = remaining / 3_600_000L
    val minutes = (remaining % 3_600_000L) / 60_000L

    Scaffold(topBar = { TopAppBar(title = { Text("Emergency Access", style = MaterialTheme.typography.titleLarge) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.ContactEmergency, null)
                Text("Trusted emergency contact", style = MaterialTheme.typography.titleMedium)
                Text("The contact details are stored in local settings. The recovery secret stays encrypted; the plaintext key is never persisted.")
                OutlinedTextField(contactName, vm::setContactName, label = { Text("Contact name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(contactPhone, vm::setContactPhone, label = { Text("Contact phone") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = vm::saveContact, modifier = Modifier.fillMaxWidth()) { Text("Save emergency contact") }
            } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (status?.configured == true) "Emergency access configured" else "Emergency access not configured", style = MaterialTheme.typography.titleMedium)
                Text("Create a 24-character recovery key and keep it with a trusted person. A recovery request has a mandatory 72-hour waiting period.")
                Button(onClick = vm::setup, modifier = Modifier.fillMaxWidth()) { Text(if (status?.configured == true) "Regenerate recovery key" else "Create recovery key") }
                if (status?.configured == true) Button(onClick = vm::revoke, modifier = Modifier.fillMaxWidth()) { Text("Revoke emergency access") }
            } } }
            if (key.isNotBlank()) item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Recovery key", style = MaterialTheme.typography.titleMedium); Text(key, style = MaterialTheme.typography.headlineSmall); Text("This key is shown only after generation. Copy/store it securely.") } } }
            if (status?.configured == true) item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Emergency recovery request", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(requestKey, { requestKey = it.uppercase().filter(Char::isLetterOrDigit).take(24) }, label = { Text("24-character recovery key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (status?.pending == true) {
                    if (status?.ready == true) Text("72-hour wait complete. Recovery can be unlocked now.", color = MaterialTheme.colorScheme.primary)
                    else Text("Unlock available in ${hours}h ${minutes}m")
                    Button(onClick = { vm.unlock(requestKey) }, enabled = status?.ready == true && requestKey.length == 24, modifier = Modifier.fillMaxWidth()) { Text("Unlock emergency access") }
                    TextButton(onClick = vm::cancelRequest) { Text("Cancel request") }
                } else {
                    Button(onClick = { vm.request(requestKey) }, enabled = requestKey.length == 24, modifier = Modifier.fillMaxWidth()) { Text("Start 72-hour recovery") }
                }
            } } }
            message?.let { item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(it); TextButton(onClick = vm::clearMessage) { Text("Dismiss") } } } } }
        }
    }
}
