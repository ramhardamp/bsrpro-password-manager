package pro.babasitaram.vault.presentation.root

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository

enum class RootState { Loading, NeedsSetup, Locked, Unlocked }

@HiltViewModel
class RootViewModel @Inject constructor(
    auth: AuthRepository,
    session: SessionKeyStore,
    settingsRepository: SettingsRepository
) : ViewModel() {

    /** Recomputed every time the session locks/unlocks, so "locked" always shows the lock screen. */
    val state: StateFlow<RootState> = session.isUnlocked
        .map { unlocked ->
            when {
                unlocked -> RootState.Unlocked
                auth.vaultExists() -> RootState.Locked
                else -> RootState.NeedsSetup
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RootState.Loading)

    val settings: StateFlow<VaultSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VaultSettings())
}
