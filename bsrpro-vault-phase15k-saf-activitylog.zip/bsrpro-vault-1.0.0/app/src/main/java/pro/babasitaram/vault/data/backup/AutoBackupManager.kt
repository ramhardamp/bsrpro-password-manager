package pro.babasitaram.vault.data.backup

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.nio.file.AtomicMoveNotSupportedException
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.crypto.V3PayloadParser
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.VaultPayload
import pro.babasitaram.vault.core.model.VaultJson
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.data.transfer.ExportFormat
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.BuildExportUseCase
import timber.log.Timber

/**
 * V3 backup to Downloads/BSRPRO_Backups/BSRPRO.Vault. Legacy dated backups are removed only after a new backup is safely written.
 *
 * A V3 file is encrypted with the master password, which only exists in memory while the vault is unlocked.
 * So the daily worker backs up when the vault is unlocked and otherwise does nothing; [runIfDue] is also
 * called whenever the vault is unlocked, so a missed day is caught up at the next unlock.
 */
@Singleton
class AutoBackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settings: SettingsRepository,
    private val session: SessionKeyStore,
    private val buildExport: BuildExportUseCase,
    private val repository: VaultRepository,
    private val folderManager: BackupFolderManager,
    private val activityLogStore: pro.babasitaram.vault.core.security.ActivityLogStore
) {
    internal var clock: () -> Long = { System.currentTimeMillis() }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var debounceJob: Job? = null
    private val pendingPrefs by lazy { context.getSharedPreferences(PENDING_PREFS, Context.MODE_PRIVATE) }

    /** Persist the request first, then coalesce rapid changes into one encrypted V3 write. */
    fun requestBackup() {
        // Persist first, so process death or a lock during the debounce cannot silently drop the request.
        pendingPrefs.edit().putBoolean(KEY_PENDING, true).apply()
        if (!session.isUnlocked.value) return
        debounceJob?.cancel()
        debounceJob = scope.launch {
            delay(DEBOUNCE_MS)
            when (backupNow()) {
                is VaultResult.Success -> pendingPrefs.edit().remove(KEY_PENDING).apply()
                else -> Timber.w("backup remains pending for next unlock/retry")
            }
        }
    }

    suspend fun runPendingOrDue(): Boolean {
        if (!session.isUnlocked.value) return false
        val pending = pendingPrefs.getBoolean(KEY_PENDING, false)
        recoverInterruptedSafBackup()
        val done = if (pending) backupNow() is VaultResult.Success else runIfDue()
        if (done) pendingPrefs.edit().remove(KEY_PENDING).apply()
        return done
    }

    fun hasPendingBackup(): Boolean = pendingPrefs.getBoolean(KEY_PENDING, false)

    /** Locate the current automatic backup. On Android 10+ MediaStore content is copied to a
     * private cache file because a content:// row cannot be represented as a filesystem File.
     * On Android 8-9, check the public Downloads folder first, then this app's legacy app-scoped
     * Downloads location. Permission/provider failures are treated as not found. */
    fun findBackupFile(): File? = BackupFileDiscovery.safelyFind {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            findMediaStoreBackup()
        } else {
            val publicRoot = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val appRoot = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            val candidates = DISCOVERY_FOLDERS.flatMap { folder ->
                buildList {
                    addAll(BackupFileDiscovery.canonicalCandidates(File(publicRoot, folder), FINAL_NAME))
                    if (appRoot != null) addAll(BackupFileDiscovery.canonicalCandidates(File(appRoot, folder), FINAL_NAME))
                }
            }
            BackupFileDiscovery.firstExisting(candidates)?.let { copyToCache(it) }
        }
    }

    private fun copyToCache(source: File): File? {
        if (!source.isFile || source.length() <= 0L) return null
        val destination = File(context.cacheDir, "discovered-${UUID.randomUUID()}.vault")
        return try {
            source.inputStream().use { input ->
                destination.outputStream().use { output -> input.copyTo(output) }
            }
            if (!destination.isFile || destination.length() == 0L) {
                destination.delete()
                null
            } else destination
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            destination.delete()
            throw e
        }
    }

    private fun findMediaStoreBackup(): File? {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        recoverQuarantinedBackup()
        val uri = findMediaStoreBackupUriNewest(FOLDER)
            ?: findMediaStoreBackupUriNewest(EXTENSION_FOLDER)
            ?: return null
        val destination = File(context.cacheDir, "discovered-${UUID.randomUUID()}.vault")
        return try {
            resolver.openInputStream(uri)?.use { input ->
                destination.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            if (!destination.isFile || destination.length() == 0L) {
                destination.delete()
                return null
            }
            destination
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            destination.delete()
            throw e
        }
    }

    private fun findMediaStoreBackupUriNewest(folder: String): android.net.Uri? {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val relative = "${Environment.DIRECTORY_DOWNLOADS}/$folder/"
        val rows = mutableListOf<Pair<String, android.net.Uri>>()
        resolver.query(
            collection,
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
            "${MediaStore.MediaColumns.RELATIVE_PATH}=?",
            arrayOf(relative),
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            while (c.moveToNext()) {
                val name = c.getString(nameCol).orEmpty()
                if (AutoBackupNames.isCanonicalFamily(name, FINAL_NAME)) {
                    rows += name to android.content.ContentUris.withAppendedId(
                        collection, c.getLong(idCol)
                    )
                }
            }
        }
        return rows.firstOrNull { it.first.equals(FINAL_NAME, ignoreCase = true) }?.second
            ?: rows.firstOrNull()?.second
    }

    private fun recoverQuarantinedBackup() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val relative = "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/"
        var exactExists = false
        val quarantine = mutableListOf<android.net.Uri>()
        resolver.query(
            collection,
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
            "${MediaStore.MediaColumns.RELATIVE_PATH}=?",
            arrayOf(relative),
            null
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameCol).orEmpty()
                val row = android.content.ContentUris.withAppendedId(collection, cursor.getLong(idCol))
                if (name.equals(FINAL_NAME, ignoreCase = true)) exactExists = true
                if (AutoBackupNames.isQuarantine(name)) quarantine += row
            }
        }
        if (quarantine.isEmpty()) return
        if (!exactExists) {
            quarantine.firstOrNull()?.let { row ->
                runCatching {
                    resolver.update(row, ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, FINAL_NAME)
                        put(MediaStore.MediaColumns.IS_PENDING, 0)
                    }, null, null)
                }
            }
        }
    }

    fun schedule() {
        val req = PeriodicWorkRequestBuilder<AutoBackupWorker>(1, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiresStorageNotLow(true).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun cancel() {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }

    /** True once a calendar day has passed since the last successful backup. */
    suspend fun isDue(): Boolean {
        val s = settings.current()
        return s.autoBackupEnabled && dayKey(clock()) != dayKey(s.lastAutoBackupAt)
    }

    /** @return true if a backup file was written. */
    suspend fun runIfDue(): Boolean {
        if (!isDue() || !session.isUnlocked.value) return false
        val success = backupNow() is VaultResult.Success
        if (success) pendingPrefs.edit().remove(KEY_PENDING).apply()
        return success
    }

    suspend fun backupNow(): VaultResult<String> {
        if (!session.isUnlocked.value) return VaultResult.Failure(VaultError.VaultLocked)
        val text = when (val r = buildExport(ExportFormat.V3)) {
            is VaultResult.Success -> r.value
            is VaultResult.Failure -> return r
            VaultResult.Loading -> return VaultResult.Loading
        }
        return try {
            val selectedFolder = folderManager.getFolderUri()
            val useSaf = selectedFolder != null && folderManager.hasFolderPermission()
            val where = if (useSaf) {
                writeSafTransactional(selectedFolder!!, text)
            } else {
                withContext(Dispatchers.IO) { write(FINAL_NAME, text) }
            }
            if (!useSaf) verifyPersistedBackup()
            withContext(Dispatchers.IO) { cleanupOldBackups() }
            settings.update { it.copy(lastAutoBackupAt = clock()) }
            activityLogStore.record("backup_created", "destination:selected-or-default")
            Timber.i("auto-backup written and verified")
            VaultResult.Success(where)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Timber.w("auto-backup failed: %s", e.javaClass.simpleName)
            VaultResult.Failure(VaultError.IOError(e))
        }
    }


    fun saveSelectedFolder(uri: Uri) = folderManager.saveFolderPermission(uri)
    fun getSelectedFolderUri(): Uri? = folderManager.getFolderUri()
    fun getSelectedFolderDisplay(): String? = folderManager.getFolderUri()?.lastPathSegment?.substringAfterLast(':')

    /** Transactional SAF publication. The verified ready document is retained until the final
     * canonical document has been read back byte-for-byte and decrypted successfully. */
    private suspend fun writeSafTransactional(treeUri: Uri, text: String): String = withContext(Dispatchers.IO) {
        val folder = DocumentFile.fromTreeUri(context, treeUri) ?: throw java.io.IOException("Selected backup folder unavailable")
        if (!folder.canWrite()) throw java.io.IOException("Selected backup folder is not writable")
        val bytes = text.toByteArray(Charsets.UTF_8)
        val readyName = "$FINAL_NAME.ready.tmp"
        val workName = "$FINAL_NAME.working.tmp"
        val staleReady = folder.findFile(readyName)
        if (staleReady != null) throw java.io.IOException("Recovery file exists; launch recovery before making another backup")
        folder.findFile(workName)?.delete()
        val working = folder.createFile("application/octet-stream", workName)
            ?: throw java.io.IOException("Could not create working backup")
        try {
            context.contentResolver.openOutputStream(working.uri, "w")?.use { it.write(bytes); it.flush() }
                ?: throw java.io.IOException("Could not write working backup")
            val workRead = context.contentResolver.openInputStream(working.uri)?.use { it.readBytes() }
                ?: throw java.io.IOException("Could not read working backup")
            require(MessageDigest.isEqual(sha256(bytes), sha256(workRead))) { "Working backup SHA-256 mismatch" }
            validateV3Payload(workRead.toString(Charsets.UTF_8))
            val ready = folder.createFile("application/octet-stream", readyName)
                ?: throw java.io.IOException("Could not create recovery-ready backup")
            context.contentResolver.openOutputStream(ready.uri, "w")?.use { it.write(workRead); it.flush() }
                ?: throw java.io.IOException("Could not write recovery-ready backup")
            val readyRead = context.contentResolver.openInputStream(ready.uri)?.use { it.readBytes() }
                ?: throw java.io.IOException("Could not read recovery-ready backup")
            require(MessageDigest.isEqual(sha256(workRead), sha256(readyRead))) { "Ready backup SHA-256 mismatch" }
            validateV3Payload(readyRead.toString(Charsets.UTF_8))
            // Keep ready as the recovery source while replacing canonical.
            folder.findFile(FINAL_NAME)?.delete()
            val published = folder.createFile("application/octet-stream", FINAL_NAME)
                ?: throw java.io.IOException("Canonical file creation failed; ready recovery retained")
            try {
                context.contentResolver.openOutputStream(published.uri, "w")?.use { it.write(readyRead); it.flush() }
                    ?: throw java.io.IOException("Canonical write failed; ready recovery retained")
                val finalRead = context.contentResolver.openInputStream(published.uri)?.use { it.readBytes() }
                    ?: throw java.io.IOException("Canonical read-back failed; ready recovery retained")
                require(MessageDigest.isEqual(sha256(readyRead), sha256(finalRead))) { "Canonical SHA-256 mismatch; ready recovery retained" }
                validateV3Payload(finalRead.toString(Charsets.UTF_8))
                ready.delete()
                cleanupSafDuplicates(folder)
                return@withContext published.uri.toString()
            } catch (e: Exception) {
                // Do not delete the ready recovery document on publication failure.
                throw e
            }
        } finally {
            working.delete()
        }
    }

    private suspend fun validateV3Payload(encryptedText: String) {
        val plain = session.withPassword { password -> VaultCrypto.decryptV3(encryptedText, password) }
        val parsed = V3PayloadParser.parse(plain)
        val expectedEntries = repository.entries.value.size
        require(parsed.entries.size == expectedEntries) { "Backup payload entry count mismatch" }
        require(parsed.folders.size == repository.folders.value.size) { "Backup folder count mismatch" }
    }

    suspend fun recoverInterruptedSafBackup() = withContext(Dispatchers.IO) {
        if (!session.isUnlocked.value) return@withContext
        runCatching {
            val uri = folderManager.getFolderUri() ?: return@runCatching
            val folder = DocumentFile.fromTreeUri(context, uri) ?: return@runCatching
            val ready = folder.findFile("$FINAL_NAME.ready.tmp") ?: return@runCatching
            val bytes = context.contentResolver.openInputStream(ready.uri)?.use { it.readBytes() } ?: return@runCatching
            if (bytes.isEmpty()) return@runCatching
            validateV3Payload(bytes.toString(Charsets.UTF_8))
            // Restore canonical from the retained ready copy if absent or incomplete.
            var canonical = folder.findFile(FINAL_NAME)
            val current = canonical?.let { context.contentResolver.openInputStream(it.uri)?.use { stream -> stream.readBytes() } }
            if (current == null || !MessageDigest.isEqual(sha256(bytes), sha256(current))) {
                canonical?.delete()
                canonical = folder.createFile("application/octet-stream", FINAL_NAME) ?: return@runCatching
                context.contentResolver.openOutputStream(canonical.uri, "w")?.use { it.write(bytes); it.flush() }
                val check = context.contentResolver.openInputStream(canonical.uri)?.use { it.readBytes() } ?: return@runCatching
                if (!MessageDigest.isEqual(sha256(bytes), sha256(check))) return@runCatching
            }
            ready.delete()
            folder.findFile("$FINAL_NAME.working.tmp")?.delete()
        }.onFailure { Timber.w(it, "SAF backup recovery deferred") }
    }

    private fun cleanupSafDuplicates(folder: DocumentFile) {
        folder.listFiles().filter { f ->
            val n = f.name.orEmpty()
            Regex("^BSRPRO \(\d+\)\.Vault(?:\..*)?$").matches(n)
        }.forEach { runCatching { it.delete() } }
    }

    private fun sha256(bytes: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(bytes)

    private suspend fun write(name: String, text: String): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val relative = "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/"
            // Preferred path: overwrite the existing BSRPRO.Vault row IN PLACE ("wt" truncates). Renaming a staged row
            // onto an existing name makes MediaStore create "BSRPRO (1).Vault", "(2)" ... — that was the duplicate bug.
            if (overwriteInPlace(resolver, collection, relative, name, text.toByteArray(Charsets.UTF_8))) {
                return "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/$name"
            }
            val stagedName = ".BSRPRO-${UUID.randomUUID()}.pending"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, stagedName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                put(MediaStore.MediaColumns.RELATIVE_PATH, relative)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val staged = resolver.insert(collection, values) ?: throw java.io.IOException("MediaStore insert failed")
            try {
                resolver.openOutputStream(staged, "w")?.use { output ->
                    output.write(text.toByteArray(Charsets.UTF_8))
                    output.flush()
                } ?: throw java.io.IOException("open failed")

                // Verify the pending row before touching the existing canonical backup. This
                // prevents a failed write from destroying the previous valid backup.
                verifyMediaStoreRow(staged)

                // Keep the previous backup recoverable while publishing. MediaStore cannot
                // atomically replace an existing DISPLAY_NAME: quarantine old rows first, publish
                // the exact canonical name, then remove quarantined rows only after read-back.
                val quarantined = quarantineExistingCanonicalRows(resolver, collection, relative, name)
                try {
                    val published = resolver.update(staged, ContentValues().apply {
                        put(MediaStore.MediaColumns.IS_PENDING, 0)
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    }, null, null)
                    if (published <= 0) throw java.io.IOException("backup publish failed")
                } catch (ce: kotlinx.coroutines.CancellationException) {
                    throw ce
                } catch (e: Exception) {
                    runCatching { resolver.delete(staged, null, null) }
                    restoreQuarantinedRows(resolver, quarantined)
                    throw e
                }
                // Old rows are intentionally retained until backupNow() read-backs the published
                // canonical file and cleanupOldBackups() removes them. A crash here therefore does
                // not destroy the last recoverable backup.
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                runCatching { resolver.delete(staged, null, null) }
                throw e
            }
            return "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/$name"
        }
        // Android 8/9: use app-scoped external Downloads; no broad storage permission is requested.
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), FOLDER).apply { mkdirs() }
        val target = File(dir, name)
        val temp = File(dir, ".$name.pending")
        FileOutputStream(temp).use { out ->
            out.write(text.toByteArray(Charsets.UTF_8))
            out.fd.sync()
        }
        try {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
        return target.absolutePath
    }


    /** Finds the app-visible row named exactly [name] in [relative]; newest first. */
    private fun findExactRow(
        resolver: android.content.ContentResolver,
        collection: android.net.Uri,
        relative: String,
        name: String
    ): android.net.Uri? {
        resolver.query(
            collection,
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
            "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.IS_PENDING}=0",
            arrayOf(relative),
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            while (c.moveToNext()) {
                if (c.getString(nameCol).orEmpty().equals(name, ignoreCase = true)) {
                    return android.content.ContentUris.withAppendedId(collection, c.getLong(idCol))
                }
            }
        }
        return null
    }

    /**
     * Truncate-and-write the existing canonical file, then read it back. Returns false (without throwing) when
     * there is nothing to overwrite or the in-place write could not be verified, so the caller falls back to
     * the staged publish path.
     */
    private fun overwriteInPlace(
        resolver: android.content.ContentResolver,
        collection: android.net.Uri,
        relative: String,
        name: String,
        bytes: ByteArray
    ): Boolean {
        val existing = runCatching { findExactRow(resolver, collection, relative, name) }.getOrNull() ?: return false
        return try {
            resolver.openOutputStream(existing, "wt")?.use { out ->
                out.write(bytes)
                out.flush()
            } ?: return false
            val back = resolver.openInputStream(existing)?.use { it.readBytes() }
            val ok = back != null && back.contentEquals(bytes)
            Timber.i("auto-backup in-place overwrite verified=%s", ok)
            ok
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            Timber.w("auto-backup in-place overwrite failed: %s", e.javaClass.simpleName)
            false
        }
    }

    private suspend fun verifyMediaStoreRow(uri: android.net.Uri) {
        val resolver = context.contentResolver
        val persisted = resolver.openInputStream(uri)?.use { input ->
            input.readBytes().toString(Charsets.UTF_8).trim()
        } ?: throw java.io.IOException("Backup staging read failed")
        if (persisted.isEmpty()) throw java.io.IOException("Backup staging file is empty")
        // We only need to prove that the staged bytes are a valid V3 container here.
        // Full payload equality is performed again after publication by verifyPersistedBackup().
        session.withPassword { password ->
            VaultCrypto.decryptV3(persisted, password)
        }
    }

    private data class QuarantinedRow(
        val uri: android.net.Uri,
        val originalName: String
    )

    private fun quarantineExistingCanonicalRows(
        resolver: android.content.ContentResolver,
        collection: android.net.Uri,
        relativePath: String,
        finalName: String
    ): List<QuarantinedRow> {
        val rows = mutableListOf<QuarantinedRow>()
        resolver.query(
            collection,
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
            "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.IS_PENDING}=0",
            arrayOf(relativePath),
            null
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val displayName = cursor.getString(nameCol).orEmpty()
                if (AutoBackupNames.isCanonicalFamily(displayName, finalName)) {
                    rows += QuarantinedRow(
                        android.content.ContentUris.withAppendedId(collection, cursor.getLong(idCol)),
                        displayName
                    )
                }
            }
        }

        val changed = mutableListOf<QuarantinedRow>()
        try {
            rows.forEachIndexed { index, row ->
                val quarantineName = ".bsrpro-old-${UUID.randomUUID()}-$index.vault"
                val updated = resolver.update(
                    row.uri,
                    ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, quarantineName) },
                    null,
                    null
                )
                if (updated <= 0) throw java.io.IOException("could not quarantine existing backup")
                changed += row
            }
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            restoreQuarantinedRows(resolver, changed)
            throw e
        }
        return changed
    }

    private fun restoreQuarantinedRows(
        resolver: android.content.ContentResolver,
        rows: List<QuarantinedRow>
    ) {
        rows.forEach { row ->
            runCatching {
                resolver.update(
                    row.uri,
                    ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, row.originalName) },
                    null,
                    null
                )
            }
        }
    }

    /** Read the newly published backup, decrypt it with the active session password and compare the canonical payload. */
    private suspend fun verifyPersistedBackup() {
        val file = findBackupFile() ?: throw java.io.IOException("Backup read-back file not found")
        try {
            val persisted = withContext(Dispatchers.IO) { file.readText(Charsets.UTF_8).trim() }
            if (persisted.isEmpty()) throw java.io.IOException("Backup read-back file is empty")
            val plaintext = session.withPassword { password -> VaultCrypto.decryptV3(persisted, password) }
            val actual = V3PayloadParser.parse(plaintext)
            val expected = canonical(VaultData(repository.entries.value, repository.folders.value))
            val actualCanonical = VaultJson.encodeToString(
                VaultPayload.serializer(), VaultPayload(entries = actual.entries, folders = actual.folders)
            )
            val expectedDigest = MessageDigest.getInstance("SHA-256").digest(expected.toByteArray(Charsets.UTF_8))
            val actualDigest = MessageDigest.getInstance("SHA-256").digest(actualCanonical.toByteArray(Charsets.UTF_8))
            if (!MessageDigest.isEqual(expectedDigest, actualDigest)) {
                throw java.io.IOException("Backup read-back payload mismatch")
            }
        } finally {
            file.delete()
        }
    }

    private fun canonical(data: VaultData): String {
        val folderIds = data.folders.map { it.id }.toSet()
        val validPackage = Regex("^[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+$")
        val entries = data.entries.map { e ->
            e.copy(
                folderId = if (e.folderId.isNotBlank() && e.folderId !in folderIds) "" else e.folderId,
                appPackage = if (e.appPackage.isNotBlank() && !validPackage.matches(e.appPackage.trim())) "" else e.appPackage
            )
        }
        return VaultJson.encodeToString(
            VaultPayload.serializer(), VaultPayload(entries = entries, folders = data.folders)
        )
    }

    /**
     * Remove previous duplicate rows ("BSRPRO (1).Vault", dated legacy files, quarantine rows) only after the new
     * backup passed read-back verification. Runs for the app folder and the extension folder; in the extension
     * folder only numbered duplicates are removed (the extension's own BSRPRO.Vault is left alone).
     */
    private fun cleanupOldBackups() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            for (folder in DISCOVERY_FOLDERS) {
                val relative = "${Environment.DIRECTORY_DOWNLOADS}/$folder/"
                val keep = findMediaStoreBackupUriNewest(folder)
                val doomed = mutableListOf<android.net.Uri>()
                resolver.query(
                    collection,
                    arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
                    "${MediaStore.MediaColumns.RELATIVE_PATH}=?",
                    arrayOf(relative),
                    null
                )?.use { c ->
                    val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                    val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                    while (c.moveToNext()) {
                        val n = c.getString(nameCol).orEmpty()
                        val uri = android.content.ContentUris.withAppendedId(collection, c.getLong(idCol))
                        if (uri == keep) continue
                        val removable = if (folder == FOLDER) AutoBackupNames.isCanonicalFamily(n, FINAL_NAME) || AutoBackupNames.isQuarantine(n)
                        else AutoBackupNames.isNumberedDuplicate(n, FINAL_NAME)
                        if (removable) doomed += uri
                    }
                }
                var removed = 0
                doomed.forEach { if (runCatching { resolver.delete(it, null, null) }.getOrDefault(0) > 0) removed++ }
                if (doomed.isNotEmpty()) Timber.i("auto-backup cleanup folder=%s removed=%d of %d", folder, removed, doomed.size)
            }
            return
        }
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), FOLDER)
        dir.listFiles()?.filter { it.isFile && (AutoBackupNames.isCanonicalFamily(it.name, FINAL_NAME) && !it.name.equals(FINAL_NAME, true) || AutoBackupNames.isQuarantine(it.name)) }?.forEach { it.delete() }
    }

    private fun dayKey(ms: Long): String = if (ms <= 0) "" else SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ms))

    companion object {
        const val WORK_NAME = "bsrpro_auto_backup"
        const val FOLDER = "BSRPRO_Backups"
        const val EXTENSION_FOLDER = "BSRPRO Vault Password_Backups"
        const val FINAL_NAME = "BSRPRO.Vault"
        private val DISCOVERY_FOLDERS = listOf(FOLDER, EXTENSION_FOLDER)
        const val DEBOUNCE_MS = 2_500L
        private const val PENDING_PREFS = "bsrpro_backup_state"
        private const val KEY_PENDING = "pending_backup_v1"
    }
}

/** Naming/migration rules kept pure so legacy cleanup is unit-testable. */
internal object BackupFileDiscovery {
    fun firstExisting(candidates: List<File>): File? = candidates.firstOrNull { it.isFile && it.name == AutoBackupManager.FINAL_NAME }

    fun canonicalCandidates(dir: File, finalName: String): List<File> {
        if (!dir.isDirectory) return emptyList()
        return dir.listFiles()
            ?.filter { it.isFile && AutoBackupNames.isCanonicalFamily(it.name, finalName) }
            ?.sortedWith(compareByDescending<File> { it.name.equals(finalName, ignoreCase = true) }.thenByDescending { it.lastModified() })
            ?: emptyList()
    }

    fun safelyFind(block: () -> File?): File? = try { block() } catch (_: SecurityException) { null } catch (_: java.io.IOException) { null }
}

internal object AutoBackupNames {
    private val legacy = Regex("vault_[0-9]{8}\\.Vault", RegexOption.IGNORE_CASE)
    fun isLegacyDated(name: String): Boolean = legacy.matches(name)
    fun isNumberedDuplicate(name: String, finalName: String): Boolean {
        val base = Regex.escape(finalName.substringBeforeLast('.'))
        val ext = Regex.escape(finalName.substringAfterLast('.', ""))
        return Regex("^$base \\(\\d+\\)\\.$ext$", RegexOption.IGNORE_CASE).matches(name)
    }
    fun isQuarantine(name: String): Boolean = name.startsWith(".bsrpro-old-", ignoreCase = true) && name.endsWith(".vault", ignoreCase = true)
    fun isCanonicalFamily(name: String, finalName: String): Boolean =
        name.equals(finalName, ignoreCase = true) ||
            isNumberedDuplicate(name, finalName) ||
            isLegacyDated(name)
}

@EntryPoint
@InstallIn(SingletonComponent::class)
interface AutoBackupEntryPoint {
    fun autoBackupManager(): AutoBackupManager
}

class AutoBackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val manager = EntryPointAccessors.fromApplication(applicationContext, AutoBackupEntryPoint::class.java).autoBackupManager()
        manager.runIfDue()          // no-op while the vault is locked; caught up at the next unlock
        return Result.success()
    }
}
