@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.notes

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.presentation.vault.CATEGORIES

@Composable
fun NoteEditorScreen(
    onDone: () -> Unit,
    vm: NoteEditorViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    BackHandler(enabled = !state.saving) { onDone() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.existing == null) "New Note" else "Edit Note", style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(onClick = onDone, enabled = !state.saving) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    Button(onClick = vm::save, enabled = !state.saving && !state.saved) { Text(stringResource(R.string.p15_save)) }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            OutlinedTextField(
                value = state.title,
                onValueChange = vm::setTitle,
                label = { Text(stringResource(R.string.p15_title)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { vm.insertToken("**text**") }) { Text("B") }
                OutlinedButton(onClick = { vm.insertToken("*text*") }) { Text("I") }
                OutlinedButton(onClick = { vm.insertToken("- ") }) { Text("•") }
                OutlinedButton(onClick = { vm.insertToken("`code`") }) { Text("Code") }
                OutlinedButton(onClick = { vm.insertToken("## ") }) { Text("H") }
            }
            OutlinedTextField(
                value = state.content,
                onValueChange = vm::setContent,
                label = { Text("Content") },
                minLines = 10,
                modifier = Modifier.fillMaxWidth().weight(1f)
            )
            Text(stringResource(R.string.p15_category), style = MaterialTheme.typography.labelLarge)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(CATEGORIES) { category ->
                    FilterChip(
                        selected = state.category == category,
                        onClick = { vm.setCategory(category) },
                        label = { Text(category.replaceFirstChar { it.uppercase() }) }
                    )
                }
            }
        }
    }
}
