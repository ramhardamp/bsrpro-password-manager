@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
package pro.babasitaram.vault.presentation.notes

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ListItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.util.CollectMessages

@Composable
fun NotesScreen(
    onBack: () -> Unit = {},
    onAdd: () -> Unit = {},
    onEdit: (String) -> Unit = {},
    onShare: (String) -> Unit = {},
    vm: NotesViewModel = hiltViewModel()
) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    BackHandler { onBack() }
    CollectMessages(vm.messages)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.p15_notes), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onAdd, icon = { Icon(Icons.Default.Add, null) }, text = { Text("New Note") })
        }
    ) { padding ->
        if (entries.isEmpty()) {
            EmptyState("No notes", "Create a secure note with title, content and category.", Modifier.padding(padding).fillMaxWidth())
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(entries, key = { it.id }) { entry ->
                    NoteItem(entry, onOpen = {}, onEdit = { onEdit(entry.id) }, onCopy = { vm.copy(entry.notes) }, onDelete = { vm.delete(entry.id) }, onShare = { onShare(entry.id) })
                }
            }
        }
    }
}

@Composable
private fun NoteItem(
    entry: VaultEntry,
    onOpen: () -> Unit,
    onEdit: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    var view by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().combinedClickable(onClick = { view = true }, onLongClick = { menu = true })) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row {
                Column(Modifier.weight(1f)) {
                    Text(entry.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium)
                    MarkdownPreview(entry.notes.take(240).replace("\n", " "), style = MaterialTheme.typography.bodyMedium)
                }
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
            }
        }
    }
    if (menu) {
        ModalBottomSheet(onDismissRequest = { menu = false }) {
            ListItem(headlineContent = { Text(stringResource(R.string.p15_edit)) }, leadingContent = { Icon(Icons.Default.Edit, null) }, modifier = Modifier.clickable { menu = false; onEdit() })
            ListItem(headlineContent = { Text("Copy note text") }, leadingContent = { Icon(Icons.Default.ContentCopy, null) }, modifier = Modifier.clickable { menu = false; onCopy() })
            ListItem(headlineContent = { Text(stringResource(R.string.p15_share)) }, leadingContent = { Icon(Icons.Default.Share, null) }, modifier = Modifier.clickable { menu = false; onShare() })
            ListItem(headlineContent = { Text(stringResource(R.string.p15_delete)) }, leadingContent = { Icon(Icons.Default.Delete, null) }, modifier = Modifier.clickable { menu = false; confirmDelete = true })
        }
    }
    if (view) {
        AlertDialog(
            onDismissRequest = { view = false },
            title = { Text(entry.title.ifBlank { "Note" }) },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { MarkdownPreview(entry.notes) } },
            confirmButton = { TextButton(onClick = { view = false; onEdit() }) { Text(stringResource(R.string.p15_edit)) } },
            dismissButton = { TextButton(onClick = { view = false }) { Text(stringResource(R.string.p15_close)) } }
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Move note to Bin?") },
            text = { Text("This note will remain recoverable in Bin until retention expires.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Move to Bin") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}


@Composable
private fun MarkdownPreview(value: String, style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.bodyMedium) {
    androidx.compose.material3.Text(
        text = buildAnnotatedString {
            val lines = value.split("\n")
            lines.forEachIndexed { index, raw ->
                val line = raw.trimStart()
                val prefix = when {
                    line.startsWith("## ") -> line.removePrefix("## ")
                    line.startsWith("- ") -> "• " + line.removePrefix("- ")
                    else -> line
                }
                when {
                    raw.startsWith("## ") -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(prefix) }
                    else -> appendInlineMarkdown(prefix)
                }
                if (index < lines.lastIndex) append("\n")
            }
        },
        style = style
    )
}

private fun androidx.compose.ui.text.AnnotatedString.Builder.appendInlineMarkdown(text: String) {
    val regex = Regex("(\\*\\*[^*]+\\*\\*)|(\\*[^*]+\\*)|(`[^`]+`)")
    var cursor = 0
    regex.findAll(text).forEach { match ->
        append(text.substring(cursor, match.range.first))
        val token = match.value
        when {
            token.startsWith("**") -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(token.trim('*')) }
            token.startsWith("*") -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(token.trim('*')) }
            token.startsWith("`") -> withStyle(SpanStyle(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)) { append(token.trim('`')) }
        }
        cursor = match.range.last + 1
    }
    append(text.substring(cursor))
}
