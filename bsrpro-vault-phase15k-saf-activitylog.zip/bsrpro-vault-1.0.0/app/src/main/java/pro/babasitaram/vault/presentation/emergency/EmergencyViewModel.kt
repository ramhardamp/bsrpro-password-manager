package pro.babasitaram.vault.presentation.emergency

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.EmergencyAccessUseCase

@HiltViewModel
class EmergencyViewModel @Inject constructor(
    private val emergency: EmergencyAccessUseCase,
    private val settings: SettingsRepository,
    private val activityLog: ActivityLogStore
) : ViewModel() {
    private val _status = MutableStateFlow<EmergencyAccessUseCase.Status?>(null)
    val status: StateFlow<EmergencyAccessUseCase.Status?> = _status.asStateFlow()
    private val _generatedKey = MutableStateFlow("")
    val generatedKey: StateFlow<String> = _generatedKey.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()
    private val _contactName = MutableStateFlow("")
    val contactName: StateFlow<String> = _contactName.asStateFlow()
    private val _contactPhone = MutableStateFlow("")
    val contactPhone: StateFlow<String> = _contactPhone.asStateFlow()
    private val _now = MutableStateFlow(System.currentTimeMillis())
    val now: StateFlow<Long> = _now.asStateFlow()

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            val s = settings.current()
            _contactName.value = s.emergencyContactName
            _contactPhone.value = s.emergencyContactPhone
            _status.value = emergency.status()
            _now.value = System.currentTimeMillis()
        }
    }

    fun setContactName(v: String) { _contactName.value = v }
    fun setContactPhone(v: String) { _contactPhone.value = v }
    fun saveContact() {
        viewModelScope.launch {
            settings.update { it.copy(emergencyContactName = _contactName.value.trim(), emergencyContactPhone = _contactPhone.value.trim()) }
            _message.value = "Emergency contact saved"
        }
    }

    fun setup() {
        viewModelScope.launch {
            when (val result = emergency.setup()) {
                is VaultResult.Success -> {
                    _generatedKey.value = result.value
                    _message.value = "Emergency key created. Store it securely with your trusted contact."
                    activityLog.record("Emergency setup", "Emergency access configured")
                    _status.value = emergency.status()
                }
                is VaultResult.Failure -> _message.value = result.error.message
                VaultResult.Loading -> Unit
            }
        }
    }

    fun request(key: String) {
        viewModelScope.launch {
            when (val result = emergency.request(key)) {
                is VaultResult.Success -> { _message.value = "Emergency request started. Unlock becomes available after 72 hours."; activityLog.record("Emergency request", "72-hour recovery timer started") }
                is VaultResult.Failure -> _message.value = result.error.message
                VaultResult.Loading -> Unit
            }
            refresh()
        }
    }

    fun unlock(key: String) {
        viewModelScope.launch {
            when (val result = emergency.unlock(key)) {
                is VaultResult.Success -> { _message.value = "Emergency recovery unlocked the vault"; activityLog.record("Emergency unlock", "Emergency recovery completed") }
                is VaultResult.Failure -> _message.value = result.error.message
                VaultResult.Loading -> Unit
            }
            refresh()
        }
    }

    fun cancelRequest() {
        viewModelScope.launch {
            when (val result = emergency.cancel()) {
                is VaultResult.Success -> _message.value = "Emergency request cancelled"
                is VaultResult.Failure -> _message.value = result.error.message
                VaultResult.Loading -> Unit
            }
            refresh()
        }
    }

    fun revoke() {
        viewModelScope.launch {
            when (val result = emergency.revoke()) {
                is VaultResult.Success -> _message.value = "Emergency access revoked"
                is VaultResult.Failure -> _message.value = result.error.message
                VaultResult.Loading -> Unit
            }
            refresh()
        }
    }

    fun clearMessage() { _message.value = null }
}
