package pro.babasitaram.vault.presentation.generator

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.GeneratePasswordUseCase
import pro.babasitaram.vault.domain.usecase.PasswordOptions
import pro.babasitaram.vault.presentation.util.ClipboardActions

enum class GeneratorMode(val label: String) { RANDOM("Random"), PASSPHRASE("Passphrase"), PIN("PIN"), MANUAL("Manual") }

data class GeneratorUiState(
    val mode: GeneratorMode = GeneratorMode.RANDOM,
    val options: PasswordOptions = PasswordOptions(),
    val words: Int = 4,
    val separator: String = "-",
    val pinLength: Int = 6,
    val generated: String = "",
    val manual: String = ""
) {
    val output: String get() = if (mode == GeneratorMode.MANUAL) manual else generated
}

@HiltViewModel
class GeneratorViewModel @Inject constructor(
    private val generator: GeneratePasswordUseCase,
    private val settings: SettingsRepository,
    private val clipboard: ClipboardActions
) : ViewModel() {

    private val _state = MutableStateFlow(GeneratorUiState())
    val state: StateFlow<GeneratorUiState> = _state.asStateFlow()
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    init {
        viewModelScope.launch {
            val s = settings.current()
            _state.update { it.copy(options = it.options.copy(length = s.generatorDefaultLength, keyword = s.generatorKeyword, excludeAmbiguous = s.generatorExcludeSimilar, lower = s.generatorLower, upper = s.generatorUpper, digits = s.generatorDigits, symbols = s.generatorSymbols)) }
            regenerate()
        }
    }

    fun setMode(mode: GeneratorMode) {
        _state.update { it.copy(mode = mode) }
        if (mode != GeneratorMode.MANUAL) regenerate()
    }

    fun setOptions(transform: (PasswordOptions) -> PasswordOptions) {
        val next = transform(_state.value.options)
        // keep at least one character class enabled
        if (!next.lower && !next.upper && !next.digits && !next.symbols) return
        _state.update { it.copy(options = next) }
        regenerate()
    }

    fun setWords(count: Int) {
        _state.update { it.copy(words = count) }
        regenerate()
    }

    fun setPinLength(length: Int) {
        _state.update { it.copy(pinLength = length.coerceIn(4, 6)) }
        regenerate()
    }

    fun setSeparator(sep: String) {
        _state.update { it.copy(separator = sep.take(3)) }
        regenerate()
    }

    fun setManual(text: String) {
        _state.update { it.copy(manual = text) }
    }

    fun regenerate() {
        _state.update { s ->
            when (s.mode) {
                GeneratorMode.RANDOM -> s.copy(generated = generator(s.options))
                GeneratorMode.PASSPHRASE -> s.copy(generated = generator.passphrase(s.words, s.separator.ifEmpty { "-" }))
                GeneratorMode.PIN -> s.copy(generated = generator.pin(s.pinLength))
                GeneratorMode.MANUAL -> s
            }
        }
    }

    fun copy() {
        val text = _state.value.output
        if (text.isEmpty()) return
        viewModelScope.launch { _messages.send(clipboard.copy(text, "Password")) }
    }
}
