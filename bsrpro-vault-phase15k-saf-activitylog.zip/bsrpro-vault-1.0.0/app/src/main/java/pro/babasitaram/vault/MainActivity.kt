package pro.babasitaram.vault

import android.Manifest
import androidx.compose.ui.unit.Density
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import pro.babasitaram.vault.core.model.SettingsCache
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dagger.hilt.android.AndroidEntryPoint
import pro.babasitaram.vault.core.model.ThemeMode
import pro.babasitaram.vault.core.security.ScreenshotGuard
import pro.babasitaram.vault.presentation.lock.LockScreen
import pro.babasitaram.vault.presentation.navigation.VaultNavHost
import pro.babasitaram.vault.presentation.root.RootState
import pro.babasitaram.vault.presentation.root.RootViewModel
import pro.babasitaram.vault.presentation.setup.SetupScreen
import pro.babasitaram.vault.presentation.theme.VaultTheme

@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(pro.babasitaram.vault.core.util.LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ScreenshotGuard.enable(this)
        enableEdgeToEdge()
        requestNotificationPermissionOnce()

        setContent {
            val root: RootViewModel = hiltViewModel()
            val state by root.state.collectAsStateWithLifecycle()
            val settings by root.settings.collectAsStateWithLifecycle()
            val cachedTheme = remember {
                ThemeMode.entries.firstOrNull { it.name == SettingsCache.getTheme(this@MainActivity) }
                    ?: ThemeMode.SYSTEM
            }
            val activeTheme = if (state == RootState.Loading) cachedTheme else settings.theme
            val dark = when (activeTheme) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }
            // FLAG_SECURE is on from onCreate (secure by default); the user setting may lift it live.
            LaunchedEffect(settings.allowScreenshots) {
                if (settings.allowScreenshots) ScreenshotGuard.disable(this@MainActivity)
                else ScreenshotGuard.enable(this@MainActivity)
            }
            LaunchedEffect(settings.hideSensitiveContentInRecents) {
                if (Build.VERSION.SDK_INT >= 33) {
                    setRecentsScreenshotEnabled(!settings.hideSensitiveContentInRecents)
                }
            }

            val layoutDirection = if (
                resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
            ) {
                LayoutDirection.Rtl
            } else {
                LayoutDirection.Ltr
            }

            val baseDensity = LocalDensity.current
            val appDensity = Density(baseDensity.density, baseDensity.fontScale * (settings.fontScalePercent / 100f))

            CompositionLocalProvider(
                LocalLayoutDirection provides layoutDirection,
                LocalDensity provides appDensity
            ) {
                VaultTheme(darkTheme = dark) {
                    Surface(Modifier.fillMaxSize()) {
                        when (state) {
                            RootState.Loading -> pro.babasitaram.vault.presentation.root.StartupSplash()
                            RootState.NeedsSetup -> SetupScreen()
                            RootState.Locked -> LockScreen()
                            RootState.Unlocked -> VaultNavHost()
                        }
                    }
                }
            }
        }
    }

    // Android 13+: needed for the autofill save-password notification.
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private fun requestNotificationPermissionOnce() {
        if (
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
