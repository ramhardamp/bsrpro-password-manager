package pro.babasitaram.vault.presentation.navigation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.core.util.isHiddenVault
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.presentation.files.hasFileMetadata

data class DrawerCounts(
    val vault: Int = 0,
    val totp: Int = 0,
    val healthIssues: Int = 0,
    val notes: Int = 0,
    val files: Int = 0,
    val mobiles: Int = 0,
    val bin: Int = 0,
    val sharing: Int = 0,
    val emergency: Int = 0
) {
    /** Badge number for a drawer route; 0 means "hide the badge". */
    fun forRoute(route: String): Int = when (route) {
        Routes.LIST -> vault
        Routes.TOTP -> totp
        Routes.HEALTH -> healthIssues
        Routes.NOTES -> notes
        Routes.FILES -> files
        Routes.MOBILES -> mobiles
        Routes.BIN -> bin
        Routes.SHARING -> sharing
        Routes.EMERGENCY -> emergency
        else -> 0
    }
}

/** Same feature filters as each screen's own ViewModel, computed once for the drawer badges. */
object DrawerCountsCalc {
    fun compute(entries: List<VaultEntry>, trashed: List<VaultEntry>, now: Long = System.currentTimeMillis()): DrawerCounts {
        val live = entries.filter { it.deletedAt == 0L && !it.isFolderMarker }
        val ageCutoff = now - 90L * 24L * 60L * 60L * 1000L
        val reused = live.filter { it.password.isNotBlank() }.groupBy { it.password }.values.filter { it.size > 1 }.flatten().map { it.id }
        val weak = live.filter { it.password.isNotBlank() && PasswordStrength.score(it.password) <= 2 }.map { it.id }
        val old = live.filter {
            it.password.isNotBlank() && it.updatedAt in 1 until ageCutoff && it.recordType.equals("login", true)
        }.map { it.id }
        val dupes = live.mapNotNull { e ->
            val d = UrlUtils.domainOf(e.url)
            if (e.username.isBlank() || d.isBlank()) null else e.id to "${d.lowercase()}|${e.username.lowercase()}"
        }.groupBy({ it.second }, { it.first }).values.filter { it.size > 1 }.flatten()
        return DrawerCounts(
            vault = live.count { !it.isNote && !it.isHiddenVault && it.recordType.lowercase() !in setOf("note", "totp", "mobile") },
            totp = live.count { it.totp.isNotBlank() },
            healthIssues = (reused + weak + old + dupes).toSet().size,
            notes = live.count { it.isNote || it.recordType.equals("note", true) },
            files = live.count { it.hasFileMetadata() },
            mobiles = live.count { it.mobile.isNotBlank() || it.phone.isNotBlank() || it.recordType.equals("mobile", true) },
            bin = trashed.size
        )
    }
}

@HiltViewModel
class DrawerCountsViewModel @Inject constructor(
    repository: VaultRepository,
    shareRecords: pro.babasitaram.vault.core.security.ShareRecordStore,
    settings: pro.babasitaram.vault.domain.repository.SettingsRepository
) : ViewModel() {
    // computed off the main thread; StateFlow only re-emits when the numbers actually change
    val counts: StateFlow<DrawerCounts> = combine(
        repository.entries, repository.trashedEntries, shareRecords.records, settings.settings
    ) { e, t, shares, cfg ->
        val now = System.currentTimeMillis()
        DrawerCountsCalc.compute(e, t, now).copy(
            sharing = shares.count { it.isActive(now) },
            // 1 = an emergency-access request is pending / active and needs attention
            emergency = if (cfg.emergencyActive || cfg.emergencyRequestTime > 0L) 1 else 0
        )
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DrawerCounts())
}
