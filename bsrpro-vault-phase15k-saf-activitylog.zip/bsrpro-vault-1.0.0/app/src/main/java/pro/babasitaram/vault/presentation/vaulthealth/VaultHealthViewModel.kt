package pro.babasitaram.vault.presentation.vaulthealth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.domain.repository.VaultRepository

data class VaultHealthState(
    val score: Int = 100,
    val total: Int = 0,
    val weakPasswords: List<VaultEntry> = emptyList(),
    val reusedPasswords: List<VaultEntry> = emptyList(),
    val duplicateLogins: List<VaultEntry> = emptyList(),
    val missingUsernames: List<VaultEntry> = emptyList(),
    val oldPasswords: List<VaultEntry> = emptyList()
)

@HiltViewModel
class VaultHealthViewModel @Inject constructor(
    repository: VaultRepository,
    private val breachChecker: pro.babasitaram.vault.core.security.PwnedPasswordChecker
) : ViewModel() {
    private val _breach = MutableStateFlow<Map<String, String>>(emptyMap())
    val breach: StateFlow<Map<String, String>> = _breach.asStateFlow()

    val state: StateFlow<VaultHealthState> = repository.entries
        .map { values ->
            val entries = values.filter { it.deletedAt == 0L }
            val ageCutoff = System.currentTimeMillis() - 90L * 24L * 60L * 60L * 1000L
            val passwordGroups = entries.filter { it.password.isNotBlank() }.groupBy { it.password }
            val reused = passwordGroups.values.filter { it.size > 1 }.flatten().distinctBy { it.id }
            val loginGroups = entries.mapNotNull { entry ->
                val domain = UrlUtils.domainOf(entry.url)
                if (entry.username.isBlank() || domain.isBlank()) {
                    null
                } else {
                    entry to "${domain.lowercase()}|${entry.username.lowercase()}"
                }
            }.groupBy({ it.second }, { it.first })
            val duplicate = loginGroups.values.filter { it.size > 1 }.flatten().distinctBy { it.id }
            val weak = entries.filter {
                it.password.isNotBlank() && PasswordStrength.score(it.password) <= 2
            }
            val old = entries.filter {
                it.password.isNotBlank() &&
                    it.updatedAt > 0L &&
                    it.updatedAt < ageCutoff &&
                    it.recordType.equals("login", true)
            }
            val missingUsernames = entries.filter {
                it.username.isBlank() && it.recordType.equals("login", true)
            }

            val penalty =
                minOf(40, weak.size * 8) +
                    minOf(30, reused.size * 6) +
                    minOf(15, duplicate.size * 3) +
                    minOf(10, old.size * 2) +
                    minOf(5, missingUsernames.size)

            VaultHealthState(
                score = (100 - penalty).coerceIn(0, 100),
                total = entries.size,
                weakPasswords = weak,
                reusedPasswords = reused,
                duplicateLogins = duplicate,
                missingUsernames = missingUsernames,
                oldPasswords = old
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VaultHealthState())
    fun checkBreach(entry: VaultEntry) {
        viewModelScope.launch {
            if (entry.password.isBlank()) return@launch
            _breach.value = _breach.value + (entry.id to "Checking…")
            val chars = entry.password.toCharArray()
            val result = breachChecker.check(chars)
            _breach.value = _breach.value + (
                entry.id to when {
                    result.isSuccess -> {
                        val count = result.getOrNull() ?: 0
                        if (count > 0) "Found in breach corpus: $count occurrences" else "Not found in checked breach corpus"
                    }
                    else -> "Breach check unavailable"
                }
            )
        }
    }

}
