package pro.babasitaram.vault.presentation.mobiles

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.DeleteEntryUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions

@HiltViewModel
class MobilesViewModel @Inject constructor(
    repository: VaultRepository,
    private val deleteEntry: DeleteEntryUseCase,
    private val clipboard: ClipboardActions
) : ViewModel() {
    val entries: StateFlow<List<VaultEntry>> = repository.entries
        .map { values -> values.filter { it.deletedAt == 0L && (it.mobile.isNotBlank() || it.phone.isNotBlank() || it.recordType.equals("mobile", true)) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()
    fun copy(number: String) { viewModelScope.launch { _messages.send(clipboard.copy(number, "Mobile number")) } }
    fun delete(id: String) { viewModelScope.launch { deleteEntry(id); _messages.send("Moved to Bin") } }
}
