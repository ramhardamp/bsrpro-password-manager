package pro.babasitaram.vault.presentation.vault

import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.isHiddenVault
import pro.babasitaram.vault.core.security.AuthResult
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.core.security.BiometricAuthenticator
import pro.babasitaram.vault.core.security.BiometricAvailability
import pro.babasitaram.vault.core.util.EntrySearch
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.LockVaultUseCase
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions

import androidx.compose.foundation.layout.*

enum class ListFilter(val label: String) { ALL("All"), STRONG("Strong"), WEAK("Weak"), STARRED("Starred") }
enum class SortMode(val label: String) { NAME("Name"), UPDATED("Recently updated"), USED("Recently used"), STRENGTH("Strength") }

val CATEGORIES = listOf("work", "personal", "banking", "social", "other")

data class VaultListUiState(
    val entries: List<VaultEntry> = emptyList(),
    val totalCount: Int = 0,
    val query: String = "",
    val category: String? = null,
    val folderId: String? = null,
    val filter: ListFilter = ListFilter.ALL,
    val sort: SortMode = SortMode.NAME,
    val grouped: Boolean = false,
    val folders: List<Folder> = emptyList(),
    val biometricEnabled: Boolean = false,
    val showCategories: Boolean = true
)

fun VaultEntry.strengthBucket(): String = strength.ifBlank { PasswordStrength.bucket(password) }

@OptIn(FlowPreview::class)
@HiltViewModel
class VaultListViewModel @Inject constructor(
    private val repository: VaultRepository,
    private val settings: SettingsRepository,
    private val auth: AuthRepository,
    private val session: SessionKeyStore,
    private val biometric: BiometricAuthenticator,
    private val lockVault: LockVaultUseCase,
    private val clipboard: ClipboardActions,
    private val saveEntry: SaveEntryUseCase,
    private val activityLog: ActivityLogStore
) : ViewModel() {

    private val query = MutableStateFlow("")
    private val category = MutableStateFlow<String?>(null)
    private val folderId = MutableStateFlow<String?>(null)
    private val filter = MutableStateFlow(ListFilter.ALL)
    private val sort = MutableStateFlow(SortMode.NAME)
    private val grouped = MutableStateFlow(false)
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    private val debouncedQuery = query.debounce { if (it.isEmpty()) 0L else 200L }

    private data class Controls(
        val query: String,
        val category: String?,
        val folderId: String?,
        val filter: ListFilter,
        val sort: SortMode
    )

    // kotlinx.coroutines only has typed combine() overloads up to 5 flows, so inputs are grouped.
    private val controls: Flow<Controls> = combine(query, category, folderId, filter, sort) { q, c, fId, f, sortMode ->
        Controls(q, c, fId, f, sortMode)
    }

    private val visible: Flow<List<VaultEntry>> = combine(
        repository.entries,
        debouncedQuery,
        controls
    ) { entries, debounced, ctl ->
        val base = entries.filter { e ->
            // Vault shows passwords / logins / cards / identities only; TOTP, Notes and Mobiles have their own screens
            !e.isNote && !e.isFolderMarker && !e.isHiddenVault && e.recordType.lowercase() !in SEPARATE_TYPES &&
            (ctl.category == null || e.category.equals(ctl.category, ignoreCase = true)) &&
                (ctl.folderId == null || e.folderId == ctl.folderId) &&
                when (ctl.filter) {
                    ListFilter.ALL -> true
                    ListFilter.STRONG -> e.strengthBucket() == "strong"
                    ListFilter.WEAK -> e.strengthBucket() == "weak"
                    ListFilter.STARRED -> e.starred
                }
        }
        val searched = if (debounced.isBlank()) base else EntrySearch.filter(base, debounced)
        when (ctl.sort) {
            SortMode.NAME -> searched.sortedBy { it.title.lowercase() }
            SortMode.UPDATED -> searched.sortedByDescending { it.updatedAt }
            SortMode.USED -> searched.sortedByDescending { it.lastUsedAt }
            SortMode.STRENGTH -> searched.sortedByDescending { PasswordStrength.score(it.password) }
        }
    }

    private val display: Flow<Triple<Boolean, Boolean, Boolean>> = combine(grouped, settings.settings) { g, cfg ->
        Triple(g, cfg.biometricEnabled, cfg.showCategoryChips)
    }

    val state: StateFlow<VaultListUiState> = combine(
        visible,
        repository.entries,
        repository.folders,
        controls,
        display
    ) { shown, all, folders, ctl, disp ->
        VaultListUiState(
            entries = shown,
            totalCount = all.size,
            query = ctl.query,
            category = ctl.category,
            folderId = ctl.folderId,
            filter = ctl.filter,
            sort = ctl.sort,
            grouped = disp.first,
            folders = folders,
            biometricEnabled = disp.second,
            showCategories = disp.third
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VaultListUiState())

    fun setQuery(value: String) { query.value = value }
    fun setCategory(value: String?) { category.value = if (category.value == value) null else value }
    fun setFolder(value: String?) { folderId.value = if (folderId.value == value) null else value }
    fun setFilter(value: ListFilter) { filter.value = value }
    fun setSort(value: SortMode) { sort.value = value }
    fun toggleGrouped() { grouped.value = !grouped.value }

    fun createFolder(name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val existing = repository.folders.value.firstOrNull { it.name.equals(clean, ignoreCase = true) }
            if (existing != null) {
                _messages.send("Folder already exists")
                return@launch
            }
            val folder = Folder(
                id = "folder-$now-${clean.hashCode().toUInt().toString(16)}",
                name = clean,
                createdAt = now,
                updatedAt = now
            )
            when (val result = repository.upsertFolder(folder)) {
                is pro.babasitaram.vault.core.util.VaultResult.Success -> _messages.send("Folder created")
                is pro.babasitaram.vault.core.util.VaultResult.Failure -> _messages.send(result.error.message ?: "Could not create folder")
                pro.babasitaram.vault.core.util.VaultResult.Loading -> Unit
            }
        }
    }

    fun removeFolder(folder: Folder) {
        viewModelScope.launch {
            when (val result = repository.deleteFolder(folder.id)) {
                is pro.babasitaram.vault.core.util.VaultResult.Success -> _messages.send("Folder removed; entries were kept")
                is pro.babasitaram.vault.core.util.VaultResult.Failure -> _messages.send(result.error.message ?: "Could not remove folder")
                pro.babasitaram.vault.core.util.VaultResult.Loading -> Unit
            }
        }
    }

    fun copyPassword(entry: VaultEntry) = viewModelScope.launch { activityLog.record("Copy password", "Vault entry field copied"); _messages.send(clipboard.copy(entry.password, "Password")) }
    fun copyUsername(entry: VaultEntry) = viewModelScope.launch { activityLog.record("Copy username", "Vault entry field copied"); _messages.send(clipboard.copy(entry.username, "Username")) }
    fun copyTotp(entry: VaultEntry) = viewModelScope.launch { activityLog.record("Copy TOTP", "Authenticator code copied"); _messages.send(clipboard.copy(entry.totp, "TOTP")) }

    fun delete(entry: VaultEntry) {
        viewModelScope.launch {
            try {
                repository.softDelete(entry.id)
                activityLog.record("Move to Bin", "Vault entry moved to trash")
                _messages.send("Moved to Bin")
            } catch (e: VaultError) {
                _messages.send(e.message ?: "Could not move entry to Bin")
            }
        }
    }

    fun toggleStar(entry: VaultEntry) {
        viewModelScope.launch {
            saveEntry(entry.copy(starred = !entry.starred), existing = entry)
            activityLog.record(if (entry.starred) "Remove favorite" else "Add favorite", "Vault entry favorite changed")
            _messages.send(if (entry.starred) "Removed from favorites" else "Added to favorites")
        }
    }

    fun lock() = viewModelScope.launch { lockVault() }

    fun toggleBiometric(activity: FragmentActivity) {
        viewModelScope.launch {
            if (settings.current().biometricEnabled) {
                auth.clearBiometricCredential()
                settings.update { it.copy(biometricEnabled = false) }
                _messages.send("Biometric unlock disabled")
                return@launch
            }
            if (biometric.availability() != BiometricAvailability.Available) {
                _messages.send("Set up a fingerprint or screen lock in Android settings first")
                return@launch
            }
            biometric.authenticate(activity, "Enable biometric unlock", "Confirm it's you").collect { result ->
                if (result is AuthResult.Success) {
                    session.withPassword { auth.saveBiometricCredential(it) }
                    settings.update { it.copy(biometricEnabled = true) }
                    _messages.send("Biometric unlock enabled")
                }
            }
        }
    }
}


private val SEPARATE_TYPES = setOf("note", "totp", "mobile")
