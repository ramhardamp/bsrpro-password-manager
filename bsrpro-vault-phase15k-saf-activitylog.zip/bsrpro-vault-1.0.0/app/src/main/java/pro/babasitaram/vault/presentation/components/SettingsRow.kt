package pro.babasitaram.vault.presentation.components
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.*
@Composable fun SettingsRow(icon: String, title: String, subtitle: String = "", onClick: () -> Unit = {}) { Row(Modifier.fillMaxWidth().clickable(onClick=onClick).padding(vertical=10.dp), horizontalArrangement=Arrangement.spacedBy(12.dp)) { IconContainer(icon); Column(Modifier.weight(1f)) { Text(title); if(subtitle.isNotBlank()) Text(subtitle, style=MaterialTheme.typography.bodySmall) }; Text("›") } }
