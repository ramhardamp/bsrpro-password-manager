package pro.babasitaram.vault.presentation.contacts

import android.content.Context
import android.provider.ContactsContract
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.model.CustomField
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.IdGenerator
import pro.babasitaram.vault.data.backup.AutoBackupManager
import pro.babasitaram.vault.domain.repository.VaultRepository

data class ContactItem(val id: Long, val name: String, val phones: List<String>, val duplicate: Boolean) {
    val primary: String get() = phones.firstOrNull().orEmpty()
}

data class ContactsUiState(
    val loading: Boolean = false,
    val loaded: Boolean = false,
    val items: List<ContactItem> = emptyList(),
    val selected: Set<Long> = emptySet(),
    val query: String = "",
    val importing: Boolean = false,
    val error: String? = null
)

/** Pure helpers (unit-testable). */
object ContactsLogic {
    fun normalize(raw: String): String = raw.filter { it.isDigit() || it == '+' }
    fun key(raw: String): String = raw.filter { it.isDigit() }.takeLast(10)

    fun toEntry(c: ContactItem, now: Long): VaultEntry = VaultEntry(
        id = IdGenerator.newId(now),
        title = c.name.ifBlank { c.primary },
        mobile = c.primary,
        phone = c.primary,
        recordType = "mobile",
        category = "personal",
        customFields = c.phones.drop(1).mapIndexed { i, p -> CustomField("phone${i + 2}", p) },
        createdAt = now,
        updatedAt = now
    )
}

@HiltViewModel
class ContactsImportViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: VaultRepository,
    private val autoBackup: AutoBackupManager
) : ViewModel() {

    private val _state = MutableStateFlow(ContactsUiState())
    val state: StateFlow<ContactsUiState> = _state.asStateFlow()
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()
    val finished = Channel<Unit>(Channel.CONFLATED)

    fun setQuery(q: String) = _state.update { it.copy(query = q) }

    /** Call only after READ_CONTACTS has been granted. Reads on the IO dispatcher. */
    fun load() {
        if (_state.value.loading) return
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            try {
                val existing = repository.entries.value
                    .flatMap { listOf(it.mobile, it.phone) }
                    .map(ContactsLogic::key).filter { it.isNotEmpty() }.toSet()
                val items = withContext(Dispatchers.IO) { readContacts(existing) }
                _state.update { it.copy(loading = false, loaded = true, items = items, selected = emptySet()) }
            } catch (e: SecurityException) {
                _state.update { it.copy(loading = false, loaded = false, error = "Contacts permission is missing.") }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, loaded = false, error = "Could not read contacts.") }
            }
        }
    }

    private fun readContacts(existingKeys: Set<String>): List<ContactItem> {
        val names = LinkedHashMap<Long, String>()
        val phones = LinkedHashMap<Long, MutableList<String>>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection, null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val nameCol = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numCol = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val number = ContactsLogic.normalize(c.getString(numCol).orEmpty())
                if (number.isEmpty()) continue
                names.getOrPut(id) { c.getString(nameCol).orEmpty() }
                val list = phones.getOrPut(id) { ArrayList() }
                if (list.none { ContactsLogic.key(it) == ContactsLogic.key(number) }) list.add(number)
            }
        }
        return names.map { (id, name) ->
            val p = phones[id].orEmpty()
            ContactItem(id, name, p, duplicate = p.isNotEmpty() && ContactsLogic.key(p.first()) in existingKeys)
        }.filter { it.phones.isNotEmpty() }
    }

    fun toggle(id: Long) = _state.update { s ->
        s.copy(selected = if (id in s.selected) s.selected - id else s.selected + id)
    }

    /** Selects every contact that matches the search and is not already in the vault. */
    fun selectAll() = _state.update { s ->
        s.copy(selected = s.selected + visible(s).filter { !it.duplicate }.map { it.id })
    }

    fun deselectAll() = _state.update { it.copy(selected = emptySet()) }

    fun visible(s: ContactsUiState): List<ContactItem> {
        val q = s.query.trim()
        if (q.isEmpty()) return s.items
        return s.items.filter { it.name.contains(q, true) || it.phones.any { p -> p.contains(q) } }
    }

    fun importSelected() {
        val s = _state.value
        val chosen = s.items.filter { it.id in s.selected }
        if (chosen.isEmpty()) return
        viewModelScope.launch {
            _state.update { it.copy(importing = true) }
            try {
                val (dups, fresh) = chosen.partition { it.duplicate }
                val now = System.currentTimeMillis()
                val entries = fresh.map { ContactsLogic.toEntry(it, now) }
                if (entries.isNotEmpty()) {
                    repository.upsertAll(entries)
                    autoBackup.requestBackup()
                }
                _messages.send(
                    "Imported ${entries.size} contact${if (entries.size == 1) "" else "s"}" +
                        if (dups.isNotEmpty()) " · skipped ${dups.size} already saved" else ""
                )
                _state.update { it.copy(importing = false, selected = emptySet()) }
                if (entries.isNotEmpty()) finished.send(Unit)
                else load()
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                _state.update { it.copy(importing = false) }
                _messages.send("Import failed. Please try again.")
            }
        }
    }
}
