package pro.babasitaram.vault.presentation.components
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.*
@Composable fun EmptyState(title: String, message: String) { Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally) { Text(title, style=MaterialTheme.typography.titleMedium); Text(message, style=MaterialTheme.typography.bodyMedium) } }
