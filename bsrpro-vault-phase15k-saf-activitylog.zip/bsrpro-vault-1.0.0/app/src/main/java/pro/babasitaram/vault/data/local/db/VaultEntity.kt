package pro.babasitaram.vault.data.local.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultEntry

@Entity(
    tableName = "entry_metadata",
    indices = [
        androidx.room.Index("url"),
        androidx.room.Index("username"),
        androidx.room.Index("category"),
        androidx.room.Index("record_type"),
        androidx.room.Index("app_package")
    ]
)
data class EntryMetadataEntity(
    @PrimaryKey val id: String,
    val title: String,
    val url: String,
    val username: String,
    val category: String,
    val starred: Boolean,
    @ColumnInfo(name = "updated_at") val updatedAt: Long,
    @ColumnInfo(name = "last_used_at") val lastUsedAt: Long,
    @ColumnInfo(name = "folder_id") val folderId: String,
    @ColumnInfo(name = "record_type") val recordType: String,
    @ColumnInfo(name = "app_package") val appPackage: String
)

@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey val id: String,
    val name: String
)

@Entity(tableName = "recent_searches")
data class RecentSearchEntity(
    @PrimaryKey val query: String,
    @ColumnInfo(name = "searched_at") val searchedAt: Long
)

fun VaultEntry.toMetadata() = EntryMetadataEntity(
    id = id, title = title, url = url, username = username, category = category, starred = starred,
    updatedAt = updatedAt, lastUsedAt = lastUsedAt, folderId = folderId, recordType = recordType,
    appPackage = appPackage
)

fun Folder.toEntity() = FolderEntity(id = id, name = name)
