package pro.babasitaram.vault.core.security

import pro.babasitaram.vault.core.util.VaultError

data class LockoutState(val failedAttempts: Int = 0, val lockedUntilMs: Long = 0L)

interface LockoutStore {
    suspend fun load(): LockoutState
    suspend fun save(state: LockoutState)
}

/** 5 wrong master-password attempts → 30 s lockout. State is persisted so restarting the app does not reset it. */
class RateLimiter(
    private val store: LockoutStore,
    private val clock: () -> Long = System::currentTimeMillis,
    private val maxAttempts: Int = 5,
    private val lockoutMs: Long = 30_000L,
    /** Optional live policy (attempts, lockout ms) read from Settings; null = use the constructor defaults. */
    private val policy: (suspend () -> Pair<Int, Long>)? = null,
    private val activityLogStore: ActivityLogStore? = null
) {
    @Volatile private var activeMax: Int = maxAttempts
    @Volatile private var activeLockoutMs: Long = lockoutMs

    private suspend fun refreshPolicy() {
        val p = policy?.let { runCatching { it() }.getOrNull() } ?: return
        activeMax = p.first.coerceIn(3, 20)
        activeLockoutMs = p.second.coerceIn(10_000L, 3_600_000L)
    }

    suspend fun check() {
        refreshPolicy()
        val s = store.load()
        val remaining = s.lockedUntilMs - clock()
        if (remaining > 0) throw VaultError.RateLimited(remaining)
    }

    suspend fun recordFailure(): LockoutState {
        refreshPolicy()
        val s = store.load()
        val failed = s.failedAttempts + 1
        val next = if (failed >= activeMax) LockoutState(0, clock() + activeLockoutMs) else LockoutState(failed, 0)
        store.save(next)
        if (next.lockedUntilMs > clock()) activityLogStore?.record("lockout_triggered", "attempts:$failed")
        return next
    }

    suspend fun recordSuccess() = store.save(LockoutState())

    suspend fun state(): LockoutState { refreshPolicy(); return store.load() }

    fun remainingAttempts(state: LockoutState): Int =
        if (state.lockedUntilMs > clock()) 0 else (activeMax - state.failedAttempts).coerceAtLeast(0)
}
