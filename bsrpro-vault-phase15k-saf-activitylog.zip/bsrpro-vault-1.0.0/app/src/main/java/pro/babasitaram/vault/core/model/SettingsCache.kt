package pro.babasitaram.vault.core.model

import android.content.Context

/** Small synchronous appearance cache used before the first Activity frame. */
object SettingsCache {
    private const val PREFS = "bsrpro_cache"
    private const val KEY_THEME = "theme"

    fun getTheme(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_THEME, ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name

    fun setTheme(context: Context, theme: ThemeMode) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_THEME, theme.name).apply()
    }
}
