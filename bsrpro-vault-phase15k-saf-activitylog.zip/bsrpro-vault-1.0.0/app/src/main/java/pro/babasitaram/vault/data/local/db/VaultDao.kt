package pro.babasitaram.vault.data.local.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow
import androidx.compose.foundation.lazy.*

@Dao
abstract class VaultDao {
    @Query("SELECT * FROM entry_metadata ORDER BY title COLLATE NOCASE")
    abstract fun observeMetadata(): Flow<List<EntryMetadataEntity>>

    @Query("SELECT * FROM entry_metadata WHERE category = :category COLLATE NOCASE ORDER BY title COLLATE NOCASE")
    abstract suspend fun byCategory(category: String): List<EntryMetadataEntity>

    @Query("SELECT * FROM entry_metadata WHERE starred = 1 ORDER BY title COLLATE NOCASE")
    abstract suspend fun starred(): List<EntryMetadataEntity>

    /** Used by autofill: match by domain fragment or by Android package. */
    @Query(
        "SELECT * FROM entry_metadata WHERE (app_package != '' AND app_package = :pkg) " +
            "OR (:host != '' AND url LIKE '%' || :host || '%') ORDER BY last_used_at DESC"
    )
    abstract suspend fun findForAutofill(host: String, pkg: String): List<EntryMetadataEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun upsertMetadata(items: List<EntryMetadataEntity>)

    @Query("DELETE FROM entry_metadata WHERE id = :id")
    abstract suspend fun deleteMetadata(id: String)

    @Query("DELETE FROM entry_metadata")
    abstract suspend fun clearMetadata()

    @Query("SELECT * FROM folders ORDER BY name COLLATE NOCASE")
    abstract fun observeFolders(): Flow<List<FolderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun upsertFolders(items: List<FolderEntity>)

    @Query("DELETE FROM folders")
    abstract suspend fun clearFolders()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertRecent(item: RecentSearchEntity)

    @Query("SELECT * FROM recent_searches ORDER BY searched_at DESC LIMIT :limit")
    abstract suspend fun recent(limit: Int): List<RecentSearchEntity>

    @Query("DELETE FROM recent_searches")
    abstract suspend fun clearRecents()

    @Transaction
    open suspend fun replaceAll(metadata: List<EntryMetadataEntity>, folders: List<FolderEntity>) {
        clearMetadata()
        clearFolders()
        upsertMetadata(metadata)
        upsertFolders(folders)
    }

    @Transaction
    open suspend fun wipe() {
        clearMetadata()
        clearFolders()
        clearRecents()
    }
}
