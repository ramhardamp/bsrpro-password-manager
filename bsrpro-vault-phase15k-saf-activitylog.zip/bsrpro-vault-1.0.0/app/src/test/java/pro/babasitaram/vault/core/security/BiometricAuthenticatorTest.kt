package pro.babasitaram.vault.core.security

import androidx.biometric.BiometricPrompt
import app.cash.turbine.test
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class BiometricAuthenticatorTest {

    private suspend fun withCallback(
        block: suspend app.cash.turbine.ReceiveTurbine<AuthResult>.(BiometricPrompt.AuthenticationCallback) -> Unit
    ) {
        val captured = CompletableDeferred<BiometricPrompt.AuthenticationCallback>()
        authCallbackFlow<Unit>(start = { captured.complete(it) }, cancel = { }).test {
            block(captured.await())
        }
    }

    @Test
    fun `user dismissing the prompt yields Cancelled`() = runTest {
        withCallback { cb ->
            cb.onAuthenticationError(BiometricPrompt.ERROR_USER_CANCELED, "dismissed")
            assertEquals(AuthResult.Cancelled, awaitItem())
            awaitComplete()
        }
    }

    @Test
    fun `negative button yields Cancelled`() = runTest {
        withCallback { cb ->
            cb.onAuthenticationError(BiometricPrompt.ERROR_NEGATIVE_BUTTON, "cancel")
            assertEquals(AuthResult.Cancelled, awaitItem())
            awaitComplete()
        }
    }

    @Test
    fun `lockout yields Error with code`() = runTest {
        withCallback { cb ->
            cb.onAuthenticationError(BiometricPrompt.ERROR_LOCKOUT, "locked")
            val item = awaitItem()
            assertTrue(item is AuthResult.Error && item.code == BiometricPrompt.ERROR_LOCKOUT)
            awaitComplete()
        }
    }

    @Test
    fun `rejected attempt yields Failed and the flow stays open`() = runTest {
        withCallback { cb ->
            cb.onAuthenticationFailed()
            assertEquals(AuthResult.Failed, awaitItem())
            cb.onAuthenticationError(BiometricPrompt.ERROR_USER_CANCELED, "x")
            assertEquals(AuthResult.Cancelled, awaitItem())
            awaitComplete()
        }
    }

    @Test
    fun `success yields Success and completes`() = runTest {
        withCallback { cb ->
            val result = mockk<BiometricPrompt.AuthenticationResult> { every { cryptoObject } returns null }
            cb.onAuthenticationSucceeded(result)
            assertEquals(AuthResult.Success(null), awaitItem())
            awaitComplete()
        }
    }
}
