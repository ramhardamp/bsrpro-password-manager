package pro.babasitaram.vault.data.backup

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class AutoBackupNamesTest {
    @Test
    fun canonicalFamilyMatches_exact_and_numbered_and_legacy() {
        assertTrue(AutoBackupNames.isCanonicalFamily("BSRPRO.Vault", "BSRPRO.Vault"))
        (1..7).forEach { n ->
            assertTrue(AutoBackupNames.isCanonicalFamily("BSRPRO ($n).Vault", "BSRPRO.Vault"))
        }
        assertTrue(AutoBackupNames.isCanonicalFamily("vault_20261003.Vault", "BSRPRO.Vault"))
        assertFalse(AutoBackupNames.isCanonicalFamily("notes.Vault", "BSRPRO.Vault"))
    }

    @Test
    fun ten_successive_media_names_leave_only_one_final_name_after_cleanup_selection() {
        val names = buildList {
            add("BSRPRO.Vault")
            repeat(9) { add("BSRPRO (${it + 1}).Vault") }
        }
        val canonical = names.filter { AutoBackupNames.isCanonicalFamily(it, "BSRPRO.Vault") }
        assertEquals(10, canonical.size)
        assertEquals("BSRPRO.Vault", canonical.first())
    }
}
