package pro.babasitaram.vault.core.security

import io.mockk.coVerify
import io.mockk.mockk
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.domain.usecase.LockVaultUseCase
import pro.babasitaram.vault.testing.FakeSettings

@OptIn(ExperimentalCoroutinesApi::class)
class AutoLockControllerTest {
    private val lock = mockk<LockVaultUseCase>(relaxed = true)

    private fun unlockedSession() = SessionKeyStore().also { it.unlock("Str0ng!Passw0rd".toCharArray()) }

    @Test
    fun `locks after the configured time in background`() = runTest {
        val c = AutoLockController(FakeSettings(VaultSettings(autoLockSeconds = 60)), unlockedSession(), lock, backgroundScope)
        c.onBackgrounded()
        advanceTimeBy(59_000); runCurrent()
        coVerify(exactly = 0) { lock.invoke() }
        advanceTimeBy(2_000); runCurrent()
        coVerify(exactly = 1) { lock.invoke() }
    }

    @Test
    fun `returning to the app in time cancels the lock`() = runTest {
        var t = 0L
        val c = AutoLockController(FakeSettings(VaultSettings(autoLockSeconds = 60)), unlockedSession(), lock, backgroundScope)
        c.clock = { t }
        c.onBackgrounded()
        advanceTimeBy(30_000); runCurrent()
        t = 30_000
        c.onForegrounded()
        advanceTimeBy(120_000); runCurrent()
        coVerify(exactly = 0) { lock.invoke() }
    }

    @Test
    fun `returning after the timeout locks even if the timer never fired`() = runTest {
        var t = 0L
        val c = AutoLockController(FakeSettings(VaultSettings(autoLockSeconds = 60)), unlockedSession(), lock, backgroundScope)
        c.clock = { t }
        c.onBackgrounded()
        t = 120_000          // process was frozen: virtual time did not advance, wall clock did
        c.onForegrounded()
        runCurrent()
        coVerify(exactly = 1) { lock.invoke() }
    }

    @Test
    fun `zero seconds locks immediately`() = runTest {
        val c = AutoLockController(FakeSettings(VaultSettings(autoLockSeconds = 0)), unlockedSession(), lock, backgroundScope)
        c.onBackgrounded()
        runCurrent()
        coVerify(exactly = 1) { lock.invoke() }
    }

    @Test
    fun `does nothing when lock on background is off`() = runTest {
        val c = AutoLockController(FakeSettings(VaultSettings(lockOnBackground = false)), unlockedSession(), lock, backgroundScope)
        c.onBackgrounded()
        advanceTimeBy(600_000); runCurrent()
        coVerify(exactly = 0) { lock.invoke() }
    }

    @Test
    fun `does nothing while already locked`() = runTest {
        val c = AutoLockController(FakeSettings(), SessionKeyStore(), lock, backgroundScope)
        c.onBackgrounded()
        advanceTimeBy(600_000); runCurrent()
        coVerify(exactly = 0) { lock.invoke() }
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class AutoLockNeverTest {
    @Test
    fun `never means the vault is not locked when going to the background`() = runTest {
        val lock = mockk<LockVaultUseCase>(relaxed = true)
        val session = SessionKeyStore().also { it.unlock("Str0ng!Passw0rd".toCharArray()) }
        val c = AutoLockController(FakeSettings(VaultSettings(autoLockSeconds = VaultSettings.AUTO_LOCK_NEVER)), session, lock, backgroundScope)
        var t = 1L
        c.clock = { t }
        c.onBackgrounded()
        advanceTimeBy(3_600_000); runCurrent()
        t = 7_200_000
        c.onForegrounded(); runCurrent()
        coVerify(exactly = 0) { lock.invoke() }
    }
}
