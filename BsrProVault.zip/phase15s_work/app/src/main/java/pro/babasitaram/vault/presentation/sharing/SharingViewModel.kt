package pro.babasitaram.vault.presentation.sharing

import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.AuthResult
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.core.security.BiometricAuthenticator
import pro.babasitaram.vault.core.security.SecureShareManager
import pro.babasitaram.vault.data.local.preferences.SensitiveActionPinStore
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.presentation.util.launchCatching

@HiltViewModel
class SharingViewModel @Inject constructor(
    repository: VaultRepository,
    private val pinStore: SensitiveActionPinStore,
    private val biometric: BiometricAuthenticator,
    private val settings: SettingsRepository,
    private val activityLog: ActivityLogStore,
    private val clipboard: pro.babasitaram.vault.presentation.util.ClipboardActions,
    private val shareRecords: pro.babasitaram.vault.core.security.ShareRecordStore
) : ViewModel() {

    val shares = shareRecords.records
    init { shareRecords.cleanup() }
    fun cleanupShares() = shareRecords.cleanup()
    fun revokeShare(id: String) { shareRecords.revoke(id); activityLog.record("Share link revoked", "A secure share was revoked") }
    fun revokeAllShares() { shareRecords.revokeAll(); activityLog.record("Share links revoked", "All secure shares revoked") }
    fun clearRevokedShares() = shareRecords.clearRevoked()
    fun clearAllShares() = shareRecords.clearAll()
    fun clearExpiredShares() = shareRecords.clearExpired()


    /** Copies a secret through the vault clipboard manager (sensitive flag + auto-clear). */
    fun copySecret(text: String, label: String) {
        launchCatching { clipboard.copy(text, label) }
    }

    val entries: StateFlow<List<VaultEntry>> = repository.entries
        .map { list -> list.filter { it.deletedAt == 0L && !it.isFolderMarker } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    suspend fun createLink(
        entry: VaultEntry,
        options: SecureShareManager.ShareOptions = SecureShareManager.ShareOptions()
    ): String {
        val link = SecureShareManager.create(entry, options)
        shareRecords.add(entry.id, entry.title.ifBlank { "Entry" }, options.normalized().ttlMs)
        activityLog.record("Create secure share", "Encrypted link created")
        return link
    }

    suspend fun isPinConfigured(): Boolean = pinStore.isConfigured()

    suspend fun verifyPin(pin: String): Boolean =
        pinStore.verify(pin.filter(Char::isDigit).take(6).toCharArray())

    suspend fun biometricAvailable(): Boolean =
        settings.current().biometricEnabled &&
            biometric.availability() == pro.babasitaram.vault.core.security.BiometricAvailability.Available

    suspend fun authenticateBiometric(activity: FragmentActivity): Boolean {
        var success = false
        biometric.authenticate(
            activity,
            "Authorize secure sharing",
            "Confirm it's you before sharing a vault entry"
        ).collect { result ->
            if (result is AuthResult.Success) success = true
        }
        return success
    }
}
