package pro.babasitaram.vault.presentation.vaulthealth

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable

@Stable
data class VaultHealthState(
    val score: Int = 100,
    val total: Int = 0,
    val weakPasswords: List<VaultEntry> = emptyList(),
    val reusedPasswords: List<VaultEntry> = emptyList(),
    val duplicateLogins: List<VaultEntry> = emptyList(),
    val missingUsernames: List<VaultEntry> = emptyList(),
    val oldPasswords: List<VaultEntry> = emptyList(),
    val uniqueIssueCount: Int = 0
)

@HiltViewModel
class VaultHealthViewModel @Inject constructor(
    repository: VaultRepository,
    private val breachChecker: pro.babasitaram.vault.core.security.PwnedPasswordChecker,
    @ApplicationContext private val context: Context
) : ViewModel() {
    private val _breach = MutableStateFlow<Map<String, String>>(emptyMap())
    val breach: StateFlow<Map<String, String>> = _breach.asStateFlow()

    val state: StateFlow<VaultHealthState> = repository.entries
        .map { values ->
            val a = VaultHealthCalculator.calculate(values, System.currentTimeMillis())
            VaultHealthState(
                score = a.score,
                total = a.total,
                weakPasswords = a.weakPasswords,
                reusedPasswords = a.reusedPasswords,
                duplicateLogins = a.duplicateLogins,
                missingUsernames = a.missingUsernames,
                oldPasswords = a.oldPasswords,
                uniqueIssueCount = a.uniqueIssueCount
            )
        }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VaultHealthState())
    fun checkBreach(entry: VaultEntry) {
        launchCatching {
            if (entry.password.isBlank()) return@launch
            _breach.value = _breach.value + (entry.id to context.getString(pro.babasitaram.vault.R.string.health_checking))
            val chars = entry.password.toCharArray()
            val result = breachChecker.check(chars)
            _breach.value = _breach.value + (
                entry.id to when {
                    result.isSuccess -> {
                        val count = result.getOrNull() ?: 0
                        if (count > 0) context.getString(pro.babasitaram.vault.R.string.health_breach_found, count)
                        else context.getString(pro.babasitaram.vault.R.string.health_breach_not_found)
                    }
                    else -> context.getString(pro.babasitaram.vault.R.string.health_breach_unavailable)
                }
            )
        }
    }

}
