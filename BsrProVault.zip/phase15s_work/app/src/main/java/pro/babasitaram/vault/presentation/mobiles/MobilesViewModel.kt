// file: app/src/main/java/pro/babasitaram/vault/presentation/mobiles/MobilesViewModel.kt
package pro.babasitaram.vault.presentation.mobiles

import android.content.Context
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import androidx.lifecycle.ViewModel
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.isHiddenVault
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions
import pro.babasitaram.vault.presentation.util.launchCatching

@HiltViewModel
class MobilesViewModel @Inject constructor(
    private val repository: VaultRepository,
    private val saveEntry: SaveEntryUseCase,
    private val clipboard: ClipboardActions,
    @ApplicationContext private val context: Context
) : ViewModel() {
    val entries: StateFlow<List<VaultEntry>> = repository.entries
        .map { values ->
            values.filter {
                it.deletedAt == 0L &&
                    !it.isFolderMarker &&
                    !it.isHiddenVault &&
                    (it.mobile.isNotBlank() || it.phone.isNotBlank())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _favoritesOnly = MutableStateFlow(false)
    val favoritesOnly: StateFlow<Boolean> = _favoritesOnly

    val visibleEntries: StateFlow<List<VaultEntry>> = combine(entries, favoritesOnly) { list, onlyFavorites ->
        if (onlyFavorites) list.filter { it.starred } else list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val selectableIds: StateFlow<Set<String>> = visibleEntries
        .map { it.map { entry -> entry.id }.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    private val _selectedIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedIds: StateFlow<Set<String>> = _selectedIds

    private val _selectionMode = MutableStateFlow(false)
    val selectionMode: StateFlow<Boolean> = _selectionMode

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    fun beginSelection(id: String) {
        _selectionMode.value = true
        _selectedIds.update { it + id }
    }

    fun toggleSelection(id: String) {
        if (!_selectionMode.value) beginSelection(id) else {
            _selectedIds.update { current ->
                if (id in current) current - id else current + id
            }
        }
    }

    fun toggleSelectAll() {
        val ids = selectableIds.value
        if (ids.isEmpty()) return
        _selectedIds.value = if (_selectedIds.value.containsAll(ids)) emptySet() else ids
        _selectionMode.value = true
    }

    fun exitSelection() {
        _selectedIds.value = emptySet()
        _selectionMode.value = false
    }

    fun toggleFavoritesOnly() {
        _favoritesOnly.update { !it }
        exitSelection()
    }

    fun toggleFavorite(id: String) {
        val entry = repository.entry(id) ?: return
        launchCatching {
            runCatching { saveEntry(entry.copy(starred = !entry.starred), existing = entry) }
                .onSuccess {
                    _messages.send(
                        context.getString(
                            if (entry.starred) R.string.vault_removed_favorite else R.string.vault_added_favorite
                        )
                    )
                }
                .onFailure { _messages.send(it.message ?: context.getString(R.string.selection_favorite_done, 1)) }
        }
    }

    fun copy(number: String) {
        launchCatching {
            _messages.send(clipboard.copy(number, context.getString(R.string.p15_mobile_number)))
        }
    }

    fun delete(id: String) {
        launchCatching {
            runCatching { repository.softDelete(id) }
                .onSuccess { _messages.send(context.getString(R.string.mobiles_move_bin)) }
                .onFailure { _messages.send(it.message ?: context.getString(R.string.mobiles_move_bin)) }
        }
    }

    fun deleteSelected() {
        val ids = selectedIds.value.toList()
        if (ids.isEmpty()) return
        launchCatching {
            var failed = false
            for (id in ids) {
                runCatching { repository.softDelete(id) }
                    .onFailure { failed = true }
            }
            exitSelection()
            _messages.send(
                if (failed) context.getString(R.string.selection_delete_failed)
                else context.getString(R.string.selection_deleted_to_bin, ids.size)
            )
        }
    }

    fun favoriteSelected() {
        val selected = selectedIds.value
        if (selected.isEmpty()) return
        launchCatching {
            val current = visibleEntries.value.filter { it.id in selected }
            for (entry in current) {
                runCatching { saveEntry(entry.copy(starred = !entry.starred), existing = entry) }
            }
            exitSelection()
            _messages.send(context.getString(R.string.selection_favorite_done, current.size))
        }
    }
}
