package pro.babasitaram.vault.presentation.hidden

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import javax.inject.Named
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.core.util.HiddenVault
import pro.babasitaram.vault.core.util.isHiddenVault
import pro.babasitaram.vault.data.local.preferences.SensitiveActionPinStore
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable

enum class HiddenStage { LOADING, SETUP, LOCKED, OPEN }

@Stable
data class HiddenUiState(
    val stage: HiddenStage = HiddenStage.LOADING,
    val error: String? = null,
    val lockedForMs: Long = 0L,
    val message: String? = null
)

@HiltViewModel
class HiddenVaultViewModel @Inject constructor(
    private val repository: VaultRepository,
    @Named("hiddenPin") private val pinStore: SensitiveActionPinStore,
    private val saveEntry: SaveEntryUseCase,
    private val activityLog: ActivityLogStore
) : ViewModel() {

    private val _state = MutableStateFlow(HiddenUiState())
    val state: StateFlow<HiddenUiState> = _state.asStateFlow()

    /** Entries only become visible once the PIN has been accepted in this screen session. */
    val entries: StateFlow<List<VaultEntry>> = repository.entries
        .map { all -> all.filter { it.deletedAt == 0L && it.isHiddenVault }.sortedBy { it.title.lowercase() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private var failures = 0
    private var lockedUntil = 0L

    init {
        launchCatching {
            _state.update { it.copy(stage = if (pinStore.isConfigured()) HiddenStage.LOCKED else HiddenStage.SETUP) }
        }
    }

    fun setupPin(pin: String, confirm: String) {
        val clean = pin.filter(Char::isDigit)
        when {
            clean.length !in 4..6 -> _state.update { it.copy(error = "PIN must be 4 to 6 digits") }
            clean != confirm.filter(Char::isDigit) -> _state.update { it.copy(error = "PINs do not match") }
            else -> launchCatching {
                pinStore.save(clean.toCharArray())
                activityLog.record("Hidden vault PIN set", "Hidden vault PIN configured")
                _state.update { it.copy(stage = HiddenStage.OPEN, error = null, message = "Hidden vault PIN saved") }
            }
        }
    }

    /** 5 wrong PINs → 30 s wait (in memory; the vault itself is already behind the master password). */
    fun unlock(pin: String) {
        val now = System.currentTimeMillis()
        if (now < lockedUntil) {
            _state.update { it.copy(error = "Too many attempts. Try again in ${((lockedUntil - now) / 1000) + 1}s", lockedForMs = lockedUntil - now) }
            return
        }
        launchCatching {
            if (pinStore.verify(pin.filter(Char::isDigit).take(6).toCharArray())) {
                failures = 0
                _state.update { it.copy(stage = HiddenStage.OPEN, error = null) }
            } else {
                failures++
                if (failures >= 5) {
                    failures = 0
                    lockedUntil = System.currentTimeMillis() + 30_000L
                    _state.update { it.copy(error = "Too many attempts. Try again in 30s", lockedForMs = 30_000L) }
                } else {
                    _state.update { it.copy(error = "Wrong PIN (${5 - failures} attempts left)") }
                }
            }
        }
    }

    fun lock() = _state.update { it.copy(stage = HiddenStage.LOCKED, error = null, message = null) }

    fun unhide(entry: VaultEntry) {
        launchCatching {
            val updated = entry.copy(tags = entry.tags.filterNot { it.equals(HiddenVault.TAG, ignoreCase = true) })
            saveEntry(updated, entry)
            _state.update { it.copy(message = "“${entry.title.ifBlank { "Entry" }}” moved back to the Vault") }
        }
    }

    fun changePin(newPin: String) {
        val clean = newPin.filter(Char::isDigit)
        if (clean.length !in 4..6) { _state.update { it.copy(error = "PIN must be 4 to 6 digits") }; return }
        launchCatching {
            pinStore.save(clean.toCharArray())
            activityLog.record("Hidden vault PIN changed", "Hidden vault PIN updated")
            _state.update { it.copy(error = null, message = "PIN changed") }
        }
    }

    /** Removing the PIN is only allowed when nothing is hidden, so entries can never become unreachable. */
    fun removePin() {
        if (entries.value.isNotEmpty()) {
            _state.update { it.copy(error = "Move all hidden entries back to the Vault first") }
            return
        }
        launchCatching {
            pinStore.clear()
            activityLog.record("Hidden vault PIN removed", "Hidden vault PIN removed")
            _state.update { it.copy(stage = HiddenStage.SETUP, error = null, message = "PIN removed") }
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null, error = null) }
}
